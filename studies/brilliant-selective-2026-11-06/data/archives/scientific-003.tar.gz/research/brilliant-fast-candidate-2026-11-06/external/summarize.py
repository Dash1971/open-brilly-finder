"""Frozen external-account comparison; no fitting or parameter selection."""
import json,csv,collections,hashlib
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent;STUDY=ROOT.parent
names=['production','pr285','candidate'];mat=lambda:{'TP':0,'FN':0,'FP':0,'TN':0}
counts={n:mat() for n in names};novel={n:mat() for n in names};seen=set();moves=[];changes=[];states=[];initials=searches=0
receipt=json.loads((STUDY/'SAMPLING-RECEIPT.json').read_text());pos=set(receipt['actual_eligible_fit_position_keys']);pos.update(x['position_key'] for x in json.loads((STUDY/'OLD-848.json').read_text()))
freeze=json.loads((STUDY/'fit/MODEL-FREEZE.json').read_text());expected=freeze['model_sha256'];model=STUDY/'fit/forest-candidate.json';assert hashlib.sha256(model.read_bytes()).hexdigest()==expected
excluded_aliases=0;game_counts={};partial_errors=[]
for i in range(8):
 folder=ROOT/f'assessment-{i}'
 if not folder.exists():continue
 state=folder/'STATE.json';progress=folder/'PROGRESS.json';s=json.loads(state.read_text()) if state.exists() else json.loads(progress.read_text()) if progress.exists() else {};states.append({'batch':i,**s})
 if s.get('failure'):partial_errors.append({'batch':i,'failure':s['failure']})
 for path in folder.glob('*.json'):
  if not path.stem.isdigit():continue
  try:d=json.loads(path.read_text())
  except json.JSONDecodeError:continue
  assert d['complete'];gid=d['game_id'];assert gid not in seen;seen.add(gid);initials+=len(d['initial']);searches+=d['fresh_engine_searches'];gc={n:mat() for n in names}
  f=json.loads((folder/'FREEZE.json').read_text())['configuration'];assert f['candidateModelSHA']==expected
  assert d['profile']=={'depth':12,'movetime':500};assert all(v['confirmation_cost']<=6 for v in d['variants'].values())
  for row in d['move_outcomes']:
   if not row['scored_player']:continue
   assert row['mover'].lower()=='magnuscarlsen';truth=row['gallery_positive'];alias=row['position_key'] in pos;excluded_aliases+=alias;out={'game_id':gid,**row,'train_position_overlap':alias}
   for n in names:
    award=row[n]=='!!';which='TP' if truth and award else 'FN' if truth else 'FP' if award else 'TN';counts[n][which]+=1;gc[n][which]+=1
    if not alias:novel[n][which]+=1
   moves.append(out)
   if any((row[n]=='!!')!=(row['production']=='!!') for n in names):changes.append(out)
  game_counts[gid]=gc
for table in [counts,novel]:
 for m in table.values():
  p=m['TP']+m['FN'];n=m['FP']+m['TN'];m['brilliant_count']=p;m['nonbrilliant_count']=n;m['brilliant_recognition_percent']=100*m['TP']/p if p else None;m['false_positive_rate_percent']=100*m['FP']/n if n else None
complete=len(seen)==312 and len(states)==8 and all(s.get('complete') for s in states)
if complete:
 assert len(moves)==12379 and all(m['brilliant_count']==362 and m['nonbrilliant_count']==12017 for m in counts.values())
 assert initials==24939
assert not partial_errors,partial_errors
comparison={}
for ref in ['production','pr285']:
 gained=[r for r in moves if r['gallery_positive'] and r['candidate']=='!!' and r[ref]!='!!'];lost=[r for r in moves if r['gallery_positive'] and r['candidate']!='!!' and r[ref]=='!!']
 added=[r for r in moves if not r['gallery_positive'] and r['candidate']=='!!' and r[ref]!='!!'];removed=[r for r in moves if not r['gallery_positive'] and r['candidate']!='!!' and r[ref]=='!!']
 comparison[ref]={'genuine_gained':len(gained),'genuine_lost':len(lost),'false_positives_added':len(added),'false_positives_removed':len(removed)}
pass_primary=complete and counts['candidate']['TP']>max(counts[x]['TP'] for x in ['production','pr285']) and counts['candidate']['FP']<=min(counts[x]['FP'] for x in ['production','pr285'])
report={'complete':complete,'at':datetime.now(timezone.utc).isoformat(),'games_processed':len(seen),'total_games':312,'own_moves_checked':len(moves),'counts':counts,'novel_position_counts':novel,'scored_moves_excluded_from_novel_subset':excluded_aliases,'candidate_model_sha256':expected,'candidate_fit_count':1,'test_account':'MagnusCarlsen','opponents_excluded':True,'game_overlap_with_training':0,'comparison_to_baselines':comparison,'prespecified_primary_acceptance_passed':bool(pass_primary),'initial_position_reviews_shared':initials,'fresh_engine_searches':searches,'worker_failures':partial_errors,'workers':states,'notes':['Gallery absence is the agreed negative reference in these reviewed gallery games.','Primary comparison uses all fresh Magnus moves; novel-position diagnostic removes training-before-position aliases identically for all models.','All models share each game initial SF19 Fast search evidence and only exact ordered confirmation groups.','Model artifact was frozen before external scoring. No refit or cutoff tuning allowed.']}
(ROOT/'PROGRESS-SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n')
if complete:
 (ROOT/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');(ROOT/'GAME-COUNTS.json').write_text(json.dumps(game_counts,indent=2)+'\n')
 for name,rr in [('all-magnus-move-outcomes',moves),('changed-brilliant-awards',changes),('candidate-false-positives',[r for r in moves if not r['gallery_positive'] and r['candidate']=='!!']),('candidate-missed-brilliants',[r for r in moves if r['gallery_positive'] and r['candidate']!='!!'])]:
  fields=['game_id','ply','san','uci','mover','gallery_positive','production','pr285','candidate','train_position_overlap','fen_before','fen_after']
  with (ROOT/f'{name}.csv').open('w') as f:
   w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rr)
print(json.dumps({k:v for k,v in report.items() if k not in {'workers','notes','novel_position_counts'}},indent=2))
