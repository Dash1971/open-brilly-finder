// Training-only export parity; vector/tree loop copied literally from the unchanged native adapter.
import {readFileSync,writeFileSync} from 'node:fs';
import model from './candidate-native/ui/analyse/src/noSweatBrilliantForestModel.json';
const root=new URL('./',import.meta.url),fixture=JSON.parse(readFileSync(new URL('TRAINING-EXPORT-PARITY-INPUT.json',root),'utf8'));
const output=[];
for(const row of fixture.cases)for(const which of ['current','previous']){
 const features=row.windows[which],scores:any={current:0,previous:0};
    const vector = model.features.map(name =>
      name.endsWith('__missing') ? Number(features[name.slice(0, -9)] === null) : features[name],
    );
    if (vector.some(x => x === undefined)) throw new Error('Frozen forest predictor missing');
    if (vector.some(x => typeof x === 'number' && !Number.isFinite(x)))
      throw new Error('Nonfinite forest predictor');
    let total = 0;
    for (const tree of model.trees) {
      let node = tree;
      while (node.kind === 'split') {
        const v = vector[node.feature_index!];
        node = v === null || Number(v) <= node.threshold! ? node.left! : node.right!;
      }
      total += node.raw_p!;
    }
    scores[which] = total / model.trees.length;
 output.push({key:row.key,window:which,score:scores[which]});
}
writeFileSync(new URL('TRAINING-EXPORT-PARITY-NATIVE.json',root),JSON.stringify(output)+'\n');console.log(JSON.stringify({training_cases:fixture.cases.length,windows:output.length,external_predictions:0,engine_calls:0}));
