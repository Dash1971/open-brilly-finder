"""Thirteen serial official monthly PGN requests for the frozen external account."""
import datetime
import hashlib
import json
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[2]
DEST = ROOT / 'raw-pgn'
DEST.mkdir(exist_ok=True)
months = ['2025-11', '2025-12'] + [f'2026-{month:02}' for month in range(1, 12)]
receipts = []
for month in months:
    path = DEST / f'magnuscarlsen-{month}.pgn'
    url = f'https://api.chess.com/pub/player/magnuscarlsen/games/{month.replace("-", "/")}/pgn'
    source = 'existing_task_archive' if path.exists() else 'download'
    if not path.exists():
        request = urllib.request.Request(url, headers={'User-Agent': 'MuteChessResearch-PGN-collection/1.0'})
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                data = response.read()
        except Exception as exc:
            (ROOT / 'ARCHIVES-ERROR.json').write_text(json.dumps({'month': month, 'url': url,
                'error': str(exc), 'completed_months': len(receipts)}, indent=2) + '\n')
            raise
        if data and not data.lstrip().startswith(b'[Event '):
            raise RuntimeError(f'Unexpected official monthly PGN content: {url}')
        path.write_bytes(data)
    data = path.read_bytes()
    if data and not data.lstrip().startswith(b'[Event '):
        raise RuntimeError(f'Unexpected cached monthly PGN content: {path}')
    receipts.append({'account': 'MagnusCarlsen', 'month': month, 'source': source, 'url': url,
                     'path': str(path.relative_to(WORKSPACE)), 'bytes': len(data),
                     'sha256': hashlib.sha256(data).hexdigest(),
                     'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    (ROOT / 'ARCHIVES.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps({'month': month, 'bytes': len(data), 'source': source}), flush=True)
(ROOT / 'ARCHIVES-COMPLETE.json').write_text(json.dumps({'complete': True, 'account': 'MagnusCarlsen',
    'files': len(receipts), 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
