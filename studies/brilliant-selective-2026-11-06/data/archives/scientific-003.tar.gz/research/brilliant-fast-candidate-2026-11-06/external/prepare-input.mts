// Source identity preparation only. No classifier, engine or model is invoked.
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {parsePgn,startingPosition} from 'chessops/pgn';
import {makeFen} from 'chessops/fen';
import {parseSan,makeSan} from 'chessops/san';
import {standardUci,position} from './native/ui/analyse/src/noSweatCore.ts';
const root=new URL('./',import.meta.url),old=new URL('../../brilliant-gallery-native-fast-2026-11-06/INPUT.json',root);
const sha=(data:any)=>createHash('sha256').update(data).digest('hex');
const need=(ok:any,message:string)=>{if(!ok)throw Error(message)};
const pgnBytes=readFileSync(new URL('magnus-last-12-months-chesscom-brilliants.pgn',root));
const labelBytes=readFileSync(new URL('brilliant-moves.json',root)),labels=JSON.parse(labelBytes.toString());
const overlapBytes=readFileSync(new URL('TEST-OVERLAP.json',root)),overlap=JSON.parse(overlapBytes.toString());
const oldBytes=readFileSync(old),training=JSON.parse(oldBytes.toString()),trainingIDs=training.games.map((g:any)=>g.game_id).sort(),trainingSet=new Set(trainingIDs);
need(trainingIDs.length===3161&&trainingSet.size===3161,'Wrong training exclusion set');
const byGame=new Map<string,any[]>();for(const row of labels){const rs=byGame.get(row.game_id)??[];rs.push(row);byGame.set(row.game_id,rs)}
const canonical=(fen:string)=>makeFen(position(fen).toSetup());
const games:any[]=[],excluded:any[]=[],seen=new Set<string>();
for(const game of parsePgn(pgnBytes.toString())){
 const id=game.headers.get('Link')?.match(/\/(\d+)$/)?.[1];need(id&&!seen.has(id)&&byGame.has(id!),'Unexpected/duplicate source game');seen.add(id!);
 // Construct nodes explicitly so no imported annotations, comments, evals or glyphs survive.
 const pos=startingPosition(game.headers).unwrap(),nodes:any[]=[{ply:0,fen:makeFen(pos.toSetup())}];
 for(const node of game.moves.mainline()){
  const move=parseSan(pos,node.san);need(move,'Illegal source SAN');const san=makeSan(pos,move!),uci=standardUci(pos,move!);pos.play(move!);
  nodes.push({ply:nodes.length,fen:makeFen(pos.toSetup()),uci,san});
 }
 const targets=byGame.get(id!)!;
 for(const row of targets){need(nodes[row.ply]?.uci===row.uci&&nodes[row.ply]?.san===row.san&&canonical(nodes[row.ply-1].fen)===canonical(row.fen_before)&&canonical(nodes[row.ply].fen)===canonical(row.fen_after),'Target move/board mismatch '+id+':'+row.ply);
  const mover=position(nodes[row.ply-1].fen).turn==='white'?game.headers.get('White'):game.headers.get('Black');need(mover?.toLowerCase()==='magnuscarlsen','Wrong target mover')}
 const record={game_id:id,white:game.headers.get('White'),black:game.headers.get('Black'),date:game.headers.get('Date'),nodes,targets};
 if(trainingSet.has(id!))excluded.push({game_id:id,brilliants:targets.length,moves:nodes.length-1,reason:'training_game_id_overlap'});else games.push(record);
}
games.sort((a,b)=>a.game_id.localeCompare(b.game_id));
need(seen.size===313&&labels.length===364&&games.length===312&&excluded.length===1&&excluded[0].game_id==='158576248417','External game exclusion counts changed');
need(JSON.stringify(games.map(g=>g.game_id).sort())===JSON.stringify([...overlap.fresh_external_game_ids].sort()),'Fresh ID list differs from validated overlap receipt');
const count=(gs:any[])=>{let own=0,all=0,positive=0;for(const g of gs){all+=g.nodes.length-1;positive+=g.targets.length;for(let ply=1;ply<g.nodes.length;ply++){const mover=position(g.nodes[ply-1].fen).turn==='white'?g.white:g.black;if(mover.toLowerCase()==='magnuscarlsen')own++}}return {games:gs.length,gallery_brilliants:positive,own_moves:own,gallery_absent_own_moves:own-positive,all_game_moves:all}};
const counts=count(games);need(counts.gallery_brilliants===362&&counts.own_moves===12379&&counts.gallery_absent_own_moves===12017&&counts.all_game_moves===24627,'Fresh corpus move counts changed');
const common={assessment_only:true,account:'MagnusCarlsen',scope:'Fresh gallery-represented external games; labels score completed decisions only. No classifier nodes contain PGN glyphs/comments/evals.',
 training_game_ids:trainingIDs,training_source_sha256:sha(oldBytes),excluded_training_overlap:excluded,
 sources:{pgn_sha256:sha(pgnBytes),gallery_labels_sha256:sha(labelBytes),overlap_receipt_sha256:sha(overlapBytes)},all_external_counts:counts};
writeFileSync(new URL('INPUT.json',root),JSON.stringify({...common,games})+'\n');
// Eight fixed whole-game batches, longest games first, assigned to the least loaded batch.
const bins=Array.from({length:8},(_,batch)=>({batch,moves:0,games:[]as any[]}));
for(const game of [...games].sort((a,b)=>(b.nodes.length-a.nodes.length)||a.game_id.localeCompare(b.game_id))){const bin=[...bins].sort((a,b)=>(a.moves-b.moves)||(a.batch-b.batch))[0];bin.games.push(game);bin.moves+=game.nodes.length-1}
const assignment=[];
for(const bin of bins){bin.games.sort((a,b)=>a.game_id.localeCompare(b.game_id));const bytes=JSON.stringify({...common,batch:bin.batch,expected_counts:count(bin.games),games:bin.games})+'\n';writeFileSync(new URL(`INPUT-${bin.batch}.json`,root),bytes);
 assignment.push({batch:bin.batch,suggested_host:bin.batch<4?'Air':bin.batch<6?'Mini':'Pro',counts:count(bin.games),input_sha256:sha(bytes),game_ids:bin.games.map(g=>g.game_id)})}
writeFileSync(new URL('INPUT-ASSIGNMENTS.json',root),JSON.stringify({scope:'Fixed whole-game preparation only; no worker launch',counts,assignments:assignment},null,2)+'\n');
console.log(JSON.stringify({counts,excluded,training_exclusion_game_ids:trainingIDs.length,initial_position_count:counts.all_game_moves+counts.games}));
