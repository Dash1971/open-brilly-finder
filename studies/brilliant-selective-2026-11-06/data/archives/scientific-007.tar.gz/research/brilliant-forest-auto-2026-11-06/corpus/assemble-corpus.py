"""One study's raw development corpus and full replay master; no engines or fitting."""
import collections
import hashlib
import json
import resource
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[2]
BASE = WORK / 'research/brilliant-fast-candidate-2026-11-06'
FIVE = WORK / 'research/brilliant-gallery-native-fast-2026-11-06'
PRIOR = WORK / 'research/brilliant-forest-training-search-2026-11-06/replay'
INC = WORK / 'research/brilliant-forest-increment-2026-11-06/replay'
EXT = BASE / 'external'
last_pressure = 0


def guard():
    global last_pressure
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform != 'darwin':
        rss *= 1024
    if rss > 768 * 1024**2:
        raise RuntimeError('768MiB corpus-preparation RSS cap')
    if time.monotonic() - last_pressure > 2:
        last_pressure = time.monotonic()
        if sys.platform == 'darwin':
            level = subprocess.check_output(['/usr/sbin/sysctl', '-n', 'kern.memorystatus_vm_pressure_level'], text=True).strip()
            if level == '4':
                raise RuntimeError('Critical system memory pressure')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    guard()
    with path.open('rb') as stream:
        h = hashlib.file_digest(stream, 'sha256').hexdigest()
    return h


def receipt(path):
    return {'path': str(path.resolve()), 'sha256': sha(path), 'bytes': path.stat().st_size}


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, separators=(',', ':')) + '\n')


guard()
old_path = BASE / 'TRAINING.json'
old = read(old_path)
assert len(old['cases']) == 5692
assert sum(bool(r['old_training_member']) for r in old['cases']) == 848
shutil.copy2(old_path, ROOT / 'OLD-5692-UNCHANGED.json')
assert sha(old_path) == sha(ROOT / 'OLD-5692-UNCHANGED.json')
magnus = []
feature_checks = []
for path in sorted([*(ROOT / 'magnus-games').glob('*.json'), *(ROOT / 'magnus-overlap-game').glob('*.json')]):
    saved = read(path)
    assert saved['complete'] and all(saved['source_checks'].values())
    magnus.extend(saved['rows'])
    feature_checks.append({'game_id': saved['game_id'], 'file': receipt(path), 'source_result_path': saved['original_result_path'], 'source_result_sha256': saved['original_result_sha256'], 'source_checks': saved['source_checks']})
assert len(feature_checks) == 313 and len(magnus) == 601
assert sum(r['truth'] for r in magnus) == 364
rows = old['cases'] + magnus
assert len({r['key'] for r in rows}) == len(rows) == 6293
assert not {'tjxdTRho', 'bJPg3bse'} & {r['game_id'] for r in rows}
canonical = collections.defaultdict(list)
for row in rows:
    pk = ' '.join(row['fen_before'].split()[:4])
    canonical[pk + ' ' + row['uci']].append(row)
quarantine = []
for ck, rs in canonical.items():
    if len({r['truth'] for r in rs}) > 1:
        quarantine.append({'canonical_before_and_uci': ck, 'keys': [r['key'] for r in rs], 'truths': [r['truth'] for r in rs], 'includes_magnus': any(r.get('source_cohort') == 'magnus_development' for r in rs), 'reason': 'Contradictory labels for identical before-position and played move; preserve rows but exclude this alias group from fitting.'})
quarantine_keys = sorted({k for q in quarantine for k in q['keys']})
sources = {'old_training': receipt(old_path), 'magnus_feature_input': receipt(ROOT / 'MAGNUS-FEATURE-INPUT.json'), 'magnus_overlap_feature_input': receipt(ROOT / 'MAGNUS-OVERLAP-FEATURE-INPUT.json'), 'magnus_extraction_state': receipt(ROOT / 'MAGNUS-EXTRACTION-STATE.json'), 'magnus_overlap_extraction_state': receipt(ROOT / 'MAGNUS-OVERLAP-EXTRACTION-STATE.json'), 'five_account_gallery': receipt(WORK / 'research/five-account-gallery-pgn-2026-11-06/brilliant-moves.json'), 'magnus_gallery': receipt(EXT / 'brilliant-moves.json')}
write('CANONICAL-LABEL-QUARANTINE.json', {'groups': quarantine, 'quarantined_keys': quarantine_keys, 'rows_preserved': True})
write('MAGNUS-RAW-CASES.json', {'predictors': old['predictors'], 'cases': magnus, 'source_checks': feature_checks})
write('RAW-CORPUS.json', {'scope': 'All observed rows are development data. No independent holdout. User examples are never training. Old 5692 rows and original848 are retained unchanged; quarantine applies through the separate index.', 'predictors': old['predictors'], 'cases': rows, 'original5692_preserved_prefix': True, 'original848_present': 848, 'quarantine_keys': quarantine_keys, 'canonical_label_quarantine_file': str(ROOT / 'CANONICAL-LABEL-QUARANTINE.json'), 'sources': sources})
assert read(ROOT / 'RAW-CORPUS.json')['cases'][:5692] == old['cases']
print(json.dumps({'raw_corpus_ready': True, 'rows': len(rows), 'positives': sum(r['truth'] for r in rows), 'negatives': sum(not r['truth'] for r in rows), 'old848': 848, 'canonical_conflict_groups': len(quarantine), 'canonical_conflict_keys': len(quarantine_keys)}), flush=True)

# Prepare source/result maps without importing prediction fields into the corpus.
five_input_path = FIVE / 'INPUT.json'
five_games = read(five_input_path)['games']
magnus_games = read(EXT / 'INPUT.json')['games']
users = read(PRIOR / 'USER-GAMES.json')['games']
assert len(five_games) == 3161 and len(magnus_games) == 312 and len(users) == 2
all_ids = {g['game_id'] for g in five_games + magnus_games + users}
assert len(all_ids) == 3475
locations = {r['game_id']: FIVE / r['result'] for r in read(FIVE / 'RESULT-LOCATIONS.json')}
paired_locations = {}
for i in range(8):
    for path in (FIVE / f'paired/paired-{i}').glob('*.json'):
        if path.stem in all_ids:
            assert path.stem not in paired_locations
            paired_locations[path.stem] = path
assert len(paired_locations) == 3161
external_locations = {}
for i in range(8):
    for path in (EXT / f'assessment-{i}').glob('*.json'):
        if path.stem in all_ids:
            external_locations[path.stem] = path
assert len(external_locations) == 312


def frozen_replays(directory, expected_model):
    found = {}
    for batch in range(6):
        folder = directory / f'results-{batch}'
        freeze_path = folder / 'FREEZE.json'
        freeze = read(freeze_path)['configuration']
        assert freeze['candidate_model_sha256'] == expected_model and freeze['candidate_cutoff'] == 0.8
        fr = receipt(freeze_path)
        for path in folder.glob('*.json'):
            if path.stem not in all_ids:
                continue
            data = read(path)
            assert data['complete'] and data['game_id'] == path.stem
            assert data['freeze_sha256'] == hashlib.sha256(json.dumps(freeze, separators=(',', ':')).encode()).hexdigest()
            assert path.stem not in found
            found[path.stem] = {'result_path': str(path.resolve()), 'result_sha256': sha(path), 'freeze_path': fr['path'], 'freeze_sha256': fr['sha256'], 'candidate_model_sha256': expected_model, 'candidate_cutoff': 0.8, 'available_variants': list(data['variants']), 'initial_sha256': data['initial_sha256']}
    assert len(found) == 857
    return found


replays8a = frozen_replays(PRIOR, '8a299c942bf71ce2f88df18377210778579f280c07dcc72f9c23c862386453d2')
replays502 = frozen_replays(INC, '502008557853c5c624acf87c7e2bc20d86a0f8941fb33c212ea4cefb92654d7a')
assert replays8a.keys() == replays502.keys()
conflicts_path = BASE / 'CONFLICT-KEYS.json'
conflicts = set(read(conflicts_path))
assert len(conflicts) == 55
overlap_game = read(ROOT / 'MAGNUS-OVERLAP-FEATURE-INPUT.json')['games'][0]
assert overlap_game['game_id'] == '158576248417' and len(overlap_game['targets']) == 2
master = []
stats = collections.defaultdict(collections.Counter)
for cohort, source_games, accounts in [('five_account_development', five_games, {'nelsi', 'knvb', 'hansen', 'gothamchess', 'hikaru'}), ('magnus_development', magnus_games, {'magnuscarlsen'}), ('user_examples', users, set())]:
    for original in source_games:
        guard()
        game = dict(original)
        gid = game['game_id']
        game_accounts = set(accounts)
        if gid == overlap_game['game_id']:
            assert cohort == 'five_account_development'
            game['source_targets'] = original['targets']
            game['targets'] = sorted(original['targets'] + overlap_game['targets'], key=lambda r: r['ply'])
            game['added_gallery_labels_from_account'] = 'MagnusCarlsen'
            game['added_gallery_label_source'] = receipt(EXT / 'brilliant-moves.json')
            game_accounts.add('magnuscarlsen')
        game.update(cohort=cohort, scored_accounts=sorted(game_accounts), scored_plies=[], scoring_exclusions=[], cached_replays=[])
        positive = {r['ply'] for r in game['targets']}
        assert len(positive) == len(game['targets'])
        for ply in range(1, len(game['nodes'])):
            mover = game['white'] if game['nodes'][ply - 1]['fen'].split()[1] == 'w' else game['black']
            key = f'{gid}:{ply}'
            if mover.lower() not in game_accounts:
                continue
            stats[cohort]['own_moves_before_conflict_exclusion'] += 1
            stats[cohort]['gallery_positives_before_conflict_exclusion'] += ply in positive
            if key in conflicts:
                game['scoring_exclusions'].append({'key': key, 'ply': ply, 'reason': 'known_conflicting_saved_reference_labels'})
                stats[cohort]['known_conflict_own_moves_excluded'] += 1
                stats[cohort]['known_conflict_gallery_positives_excluded'] += ply in positive
            else:
                game['scored_plies'].append(ply)
                stats[cohort]['scored_moves'] += 1
                stats[cohort]['scored_gallery_positives'] += ply in positive
                stats[cohort]['scored_gallery_absent_own_moves'] += ply not in positive
        if cohort == 'five_account_development':
            path = locations[gid]
            game.update(original_result_path=str(path.resolve()), original_result_sha256=sha(path), paired_result_path=str(paired_locations[gid].resolve()), paired_result_sha256=sha(paired_locations[gid]), source_input_path=str(five_input_path))
        elif cohort == 'magnus_development':
            path = external_locations[gid]
            game.update(original_result_path=str(path.resolve()), original_result_sha256=sha(path), source_input_path=str(EXT / 'INPUT.json'))
        else:
            assert not game['targets'] and not game['scored_plies']
            # The completed prior replay supplies Legal's fresh initial evidence too.
            previous = replays8a[gid]
            game.update(original_result_path=previous['result_path'], original_result_sha256=previous['result_sha256'], requires_fresh_initial_evidence=False)
        for name, mapping in [('forest_8a', replays8a), ('forest_502', replays502)]:
            if gid in mapping:
                game['cached_replays'].append(dict(mapping[gid], reference_name=name))
        game['has_prior_8a_502_replay'] = gid in replays8a
        stats[cohort]['games'] += 1
        stats[cohort]['all_game_moves'] += len(game['nodes']) - 1
        stats[cohort]['all_gallery_target_labels'] += len(game['targets'])
        stats[cohort]['games_with_prior_8a_502_replays'] += gid in replays8a
        master.append(game)
        if len(master) % 500 == 0:
            print(json.dumps({'replay_master_games_prepared': len(master), 'total': 3475}), flush=True)
assert len(master) == 3475
assert stats['five_account_development']['own_moves_before_conflict_exclusion'] == 137705
assert stats['five_account_development']['all_gallery_target_labels'] == 3525
assert stats['magnus_development']['own_moves_before_conflict_exclusion'] == 12379
assert stats['magnus_development']['all_gallery_target_labels'] == 362
assert sum(g['has_prior_8a_502_replay'] for g in master) == 857
write('REPLAY-MASTER.json', {'scope': 'All observed five-account/Magnus games are development replay data. User examples are diagnostic only and never training/scored. No new engine analysis or collection during preparation.', 'games': master, 'cohort_counts': stats, 'known_conflict_keys': sorted(conflicts), 'known_conflict_key_receipt': receipt(conflicts_path), 'training_canonical_quarantine_index': str(ROOT / 'CANONICAL-LABEL-QUARANTINE.json'), 'scoring_policy': 'Only the relevant studied account own moves within each covered-gallery cohort are labeled. Gallery presence positive, own-move absence negative; known55 conflicts excluded. Opponents receive no negative labels. No other monthly raw games are included. Canonical training conflicts are separately preserved for root dedup/fold audit.', 'sources': {'five_account_input': receipt(five_input_path), 'magnus_input': receipt(EXT / 'INPUT.json'), 'user_games': receipt(PRIOR / 'USER-GAMES.json')}})
summary = {'raw_corpus': {'old_rows_preserved_unchanged': 5692, 'original848_preserved': 848, 'magnus_rows': len(magnus), 'magnus_positives': 364, 'magnus_eligible_negative_offers': 237, 'total_rows': len(rows), 'positive_rows': sum(r['truth'] for r in rows), 'negative_rows': sum(not r['truth'] for r in rows), 'canonical_conflict_groups': len(quarantine), 'canonical_conflict_keys': len(quarantine_keys), 'canonical_conflict_groups_including_magnus': sum(q['includes_magnus'] for q in quarantine)}, 'replay': {'games': len(master), 'prior_8a_502_cached_games': 857, 'without_prior_8a_502_replay': 3475 - 857, 'magnus_overlap_game_merged_once': '158576248417', 'magnus_overlap_added_labels': 2, 'magnus_overlap_added_own_moves': 52, 'cohorts': stats}, 'outputs': [receipt(ROOT / n) for n in ['RAW-CORPUS.json', 'MAGNUS-RAW-CASES.json', 'CANONICAL-LABEL-QUARANTINE.json', 'REPLAY-MASTER.json']], 'no_engines_no_fitting': True}
write('PREPARATION-SUMMARY.json', summary)
print(json.dumps(summary, indent=2), flush=True)
