// Bounded development-corpus preparation from saved SF19 Fast evidence only. No engine or fitting.
import {readFileSync,writeFileSync,existsSync,mkdirSync}from'node:fs';
import{createHash}from'node:crypto';
import{execFileSync}from'node:child_process';
import * as c from'../native-reference/ui/analyse/src/noSweatClassify.ts';
import{evaluateBrilliantForest}from'../native-reference/ui/analyse/src/noSweatBrilliantForest.ts';
import{position,terminalScore}from'../native-reference/ui/analyse/src/noSweatCore.ts';
const root=new URL('./',import.meta.url),sha=(b:any)=>createHash('sha256').update(b).digest('hex'),hash=(o:any)=>sha(JSON.stringify(o)),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b);
const need=(v:any,m:string)=>{if(!v)throw Error(m)},order=JSON.parse(readFileSync(new URL('FEATURE-ORDER.json',root),'utf8')),names:string[]=order.base_features;
need(names.length===75&&order.production_vector_features.length===150,'Wrong feature order');
const inputBytes=readFileSync(new URL('MAGNUS-FEATURE-INPUT.json',root)),input=JSON.parse(inputBytes.toString()),games=input.games;
need(games.length===312&&new Set(games.map((g:any)=>g.game_id)).size===312,'Wrong Magnus development input');
const pinsBytes=readFileSync(new URL('MAGNUS-EXTRACTION-PINS.json',root)),pins=JSON.parse(pinsBytes.toString());
for(const[path,expected]of Object.entries(pins.files))need(sha(readFileSync(new URL(path,root)))===expected,'Extraction source/input pin changed: '+path);
const freeze={input_sha256:sha(inputBytes),pins_sha256:sha(pinsBytes),source_sha256:sha(readFileSync(new URL('extract-magnus.mts',root))),bundle_sha256:sha(readFileSync(new URL(import.meta.url))),scope:'development_corpus_only',native_model_sha256:'44704ac06378d3f671a4eed959e21959f759c0437c71af1f9119d1081293c0b7'};
const freezeSHA=hash(freeze),dir=new URL('magnus-games/',root);mkdirSync(dir,{recursive:true});writeFileSync(new URL('MAGNUS-EXTRACTION-FREEZE.json',root),JSON.stringify(freeze,null,2)+'\n');
const started=Date.now();let gameStarted=Date.now(),pressureAt=0;
const guard=()=>{need(Date.now()-started<=1200000&&Date.now()-gameStarted<=240000&&process.memoryUsage().rss<=768*1024**2,'20-minute/4-minute-game/768MiB cap');if(Date.now()-pressureAt>2000){pressureAt=Date.now();if(process.platform==='darwin')need(execFileSync('/usr/sbin/sysctl',['-n','kern.memorystatus_vm_pressure_level'],{encoding:'utf8'}).trim()!=='4','Critical memory pressure');else need(Number(readFileSync('/proc/meminfo','utf8').match(/^MemAvailable:\s+(\d+)/m)?.[1])>=524288,'Low available memory')}};
const quality=(r:any)=>({...r,quality:'mobile-maia-full-review-v2:12:500'});
const cheap=(b:any,a:any,w:'current'|'previous',color:any,offer:boolean)=>{const before=b[w],after=w==='previous'&&a.terminal?a.current:a[w];return !!(offer&&before?.lines?.length>1&&after?.lines?.length&&c.winChance(c.normalized(before.lines[0],color))-c.winChance(c.normalized(after.lines[0],color))<=5&&c.normalized(after.lines[0],color)>=-100)};
const features=(f:any)=>{need(same(Object.keys(f).sort(),[...names].sort()),'Native feature key mismatch');const out:any={};for(const n of names){const v=f[n];need(v===null||typeof v==='boolean'||typeof v==='number'&&Number.isFinite(v),'Invalid native feature '+n);out[n]=v}return out};
let done=0,failure:any;const totals:any={games:0,own_moves:0,opponent_moves:0,rows:0,positives:0,eligible_negative_offers:0,raw_offer_false_skips:0,neither_window_eligible_skips:0,physical_unknown_rows:0};
const add=(counts:any)=>{for(const k of Object.keys(totals))totals[k]+=counts[k]??0};
try{for(const game of games){
 const output=new URL(game.game_id+'.json',dir),gameSHA=hash(game);
 if(existsSync(output)){const prior=JSON.parse(readFileSync(output,'utf8'));need(prior.complete&&prior.freeze_sha256===freezeSHA&&prior.input_game_sha256===gameSHA,'Existing feature checkpoint requires inspection');add(prior.counts);done++;continue}
 gameStarted=Date.now();guard();const bytes=readFileSync(game.original_result_path);need(sha(bytes)===game.original_result_sha256,'Magnus result receipt mismatch');const original=JSON.parse(bytes.toString());
 need(original.complete&&original.game_id===game.game_id&&same(original.profile,{depth:12,movetime:500})&&original.initial.length===game.nodes.length,'Wrong saved Magnus initial evidence');
 need(original.initial_sha256===hash(original.initial)&&original.initial_searches.length===game.nodes.length,'Magnus initial hash/search count mismatch');
 for(let i=0;i<game.nodes.length;i++){const s=original.initial_searches[i],node=game.nodes[i];need(node.ply===i&&s.fen===node.fen&&s.depth===12&&s.time===500&&same(s.review,original.initial[i]),'Saved Magnus node/search identity mismatch');const terminal=terminalScore(node.fen);if(terminal)need(original.initial[i].terminal,'Missing terminal marker')}
 need(same(original.targets,game.targets),'Magnus target labels changed');for(const t of game.targets)need(t.game_id===game.game_id&&game.nodes[t.ply].uci===t.uci&&game.nodes[t.ply].san===t.san,'Magnus target identity mismatch');
 const positive=new Set<number>(game.targets.map((t:any)=>t.ply)),awards=new Map<number,string>(original.variants.production.outcomes),rows:any[]=[],materialCache=new Map<string,number>(),offerCache=new Map<string,boolean>();
 const counts:any={games:1,own_moves:0,opponent_moves:0,rows:0,positives:0,eligible_negative_offers:0,raw_offer_false_skips:0,neither_window_eligible_skips:0,physical_unknown_rows:0};
 const material=(fen:string)=>{guard();if(!materialCache.has(fen))materialCache.set(fen,c.naiveMaterial(fen));guard();return materialCache.get(fen)!},rawOffer=(b:string,a:string)=>{const k=b+'\n'+a;if(!offerCache.has(k))offerCache.set(k,c.hasPieceOffer(b,a));return offerCache.get(k)!};
 for(let ply=1;ply<game.nodes.length;ply++){
  guard();const before=game.nodes[ply-1].fen,after=game.nodes[ply].fen,pos=position(before),mover=pos.turn==='white'?game.white:game.black;
  if(mover.toLowerCase()!=='magnuscarlsen'){counts.opponent_moves++;need(!positive.has(ply),'Gallery target belongs to opponent');continue}
  counts.own_moves++;const truth=positive.has(ply),offer=rawOffer(before,after);if(!truth&&!offer){counts.raw_offer_false_skips++;continue}
  const cw=cheap(original.initial[ply-1],original.initial[ply],'current',pos.turn,offer),pw=cheap(original.initial[ply-1],original.initial[ply],'previous',pos.turn,offer);
  if(!truth&&!cw&&!pw){counts.neither_window_eligible_skips++;continue}
  const begin=Math.max(0,ply-2),f=evaluateBrilliantForest({positions:game.nodes.slice(begin,ply+1).map((n:any)=>n.fen),reviews:original.initial.slice(begin,ply+1).map(quality),move:game.nodes[ply].uci},{rawOffer,ecMaterial:material,isSacrifice:(b,a)=>c.isSacrifice(b,a,material),matingAcceptance:c.hasMatingAcceptance,checkedContinuation:c.continuedOfferWhileInCheck,phaseRelevant:c.convertedMaterialOrEndgame,normalized:c.normalized,winChance:c.winChance});guard();
  need(f.windows.current.eligible===cw&&f.windows.previous.eligible===pw,'Cheap/native eligibility mismatch');const current=features(f.windows.current.features),previous=features(f.windows.previous.features),roles:string[]=order.offered_role_bit_order;
  rows.push({key:game.game_id+':'+ply,game_id:game.game_id,ply,truth,old_training_member:false,original_production_false_award:awards.get(ply)==='!!'&&!truth,fen_before:before,position_key:before.split(/\s+/).slice(0,4).join(' '),mover,san:game.nodes[ply].san,uci:game.nodes[ply].uci,
   windows:{current:{features:current,eligible:cw},previous:{features:previous,eligible:pw}},confidence_sufficient:f.confidenceSufficient,physical_unknown:f.diagnostics.physicalUnknown,physical_nodes:f.diagnostics.physicalNodes,
   descriptors:{offered_role_bitmask:roles.reduce((mask,r,i)=>mask|(current['offered_role_'+r]?1<<i:0),0),moved_role:roles.find(r=>current['moved_role_'+r])??null,capture:current.move_capture,after_mapped_score:current.after_mapped_score,eval_bin:current.after_mapped_score===null?null:Math.floor(Number(current.after_mapped_score)/200),physical_debt3_min:current.physical_debt3_min},
   cheap_screen:{raw_offer:offer,current_eligible:cw,previous_eligible:pw},source_cohort:'magnus_development',source_result_path:game.original_result_path,source_result_sha256:game.original_result_sha256,source_initial_sha256:original.initial_sha256,label_basis:'Complete covered Magnus gallery: explicit Brilliant presence; own-move absence negative. No opponent or missing-NAG inference.'});
  counts.rows++;if(truth)counts.positives++;else counts.eligible_negative_offers++;if(f.diagnostics.physicalUnknown)counts.physical_unknown_rows++;
 }
 need(counts.positives===game.targets.length,'Magnus positives lost');writeFileSync(output,JSON.stringify({complete:true,game_id:game.game_id,freeze_sha256:freezeSHA,input_game_sha256:gameSHA,original_result_path:game.original_result_path,original_result_sha256:game.original_result_sha256,source_checks:{all_initial_search_nodes_matched:true,all_target_move_identities_matched:true},counts,rows})+'\n');add(counts);done++;
 writeFileSync(new URL('MAGNUS-EXTRACTION-PROGRESS.json',root),JSON.stringify({done,total:games.length,counts:totals,rss:process.memoryUsage().rss,elapsed_ms:Date.now()-started})+'\n');if(done%25===0||done===games.length)console.log(JSON.stringify({done,total:games.length,counts:totals,seconds:Math.round((Date.now()-started)/1000)}));
}need(totals.positives===362&&totals.own_moves===12379,'Magnus corpus totals changed')}catch(e){failure=String(e);console.error(failure)}
writeFileSync(new URL('MAGNUS-EXTRACTION-STATE.json',root),JSON.stringify({complete:!failure&&done===games.length,failure,done,counts:totals,elapsed_ms:Date.now()-started},null,2)+'\n');process.exit(failure?1:0);
