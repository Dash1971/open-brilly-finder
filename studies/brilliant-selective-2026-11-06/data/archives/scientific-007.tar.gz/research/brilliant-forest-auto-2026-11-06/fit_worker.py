"""Fixed study worker. Modes scout/extend/models, four disjoint worker parts."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import ast,hashlib,json,math,resource,signal,subprocess,sys,time
from pathlib import Path
import numpy as np
import sklearn
from sklearn.tree import DecisionTreeClassifier
from threadpoolctl import threadpool_limits
threadpool_limits(1)
P=Path(__file__).resolve().parent;START=time.monotonic();LAST=0.
phase=sys.argv[1];part=int(sys.argv[2]);assert phase in ['scout','extend','models'] and part in range(4)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(f,d):f.write_text(json.dumps(d,separators=(',',':'),allow_nan=False)+'\n')
def guard():
 global LAST
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
 if time.monotonic()-START>=1200 or rss>=768*1024**2 or (P/'STOP').exists():raise RuntimeError('Study1200s/768MiB/STOPcap; noautomaticretry')
 if time.monotonic()-LAST>2:
  LAST=time.monotonic()
  if int(subprocess.run(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level'],capture_output=True,text=True,check=True).stdout)==4:raise RuntimeError('Criticalmemorypressure')
def alarm(*_):raise RuntimeError('1200secondcap')
signal.signal(signal.SIGALRM,alarm);signal.alarm(1200)
pins=json.loads((P/'CODE-PINS.json').read_text());assert sha(P/'MANIFEST.json')==pins['MANIFEST.json']
manifest=json.loads((P/'MANIFEST.json').read_text());assert sklearn.__version__==manifest['versions']['sklearn']
assert sha(P/'DATA.npz')==manifest['data_sha256'] and sha(P/'CASES.json')==manifest['cases_sha256']
assert sha(Path(__file__))==json.loads((P/'CODE-PINS.json').read_text())['fit_worker.py']
a=np.load(P/'DATA.npz');X=a['X'];X32=np.nan_to_num(X,nan=-1e9).astype(np.float32);truth=a['truth'];eligible=a['eligible'];gates=a['gates'];cg=a['groups'];folds=a['folds'];names=json.loads((P/'CASES.json').read_text())['features']
y=np.repeat(truth,2);ids=np.repeat(np.arange(len(truth)),2);wg=np.repeat(cg,2);counts=np.bincount(ids[eligible],minlength=len(truth));nGroups=int(cg.max())+1
K=P.parent/'brilliants-training-overnight-2026-11-03/adapter/capacity-tree.py'
assert sha(K)==pins['capacity-tree.py']
node=next(n for n in ast.parse(K.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='Tree');exec(compile(ast.Module(body=[node],type_ignores=[]),str(K),'exec'),globals());OldTree=Tree
def unique_cases(ix):
 z=ids[ix];return int(1+np.count_nonzero(z[1:]!=z[:-1])) if len(z) else 0
def compact(t):
 if t['kind']=='leaf':return dict(kind='leaf',raw_p=t['raw_p'],distinct_moves=t['distinct_moves'])
 return dict(kind='split',feature_index=t['feature_index'],threshold=t['threshold'],left=compact(t['left']),right=compact(t['right']))
def export_compiled(est,ix,mult,minleaf):
 tr=est.tree_
 def leaf(rows):
  w=mult[wg[rows]];return dict(kind='leaf',raw_p=float(np.dot(w,y[rows])/w.sum()),distinct_moves=unique_cases(rows))
 def build(n,rows):
  guard()
  if tr.children_left[n]<0:return leaf(rows)
  f=int(tr.feature[n]);threshold=float(tr.threshold[n]);assert threshold>-1e9 and math.isfinite(threshold)
  z=X[rows,f];left=np.isnan(z)|(z<=threshold);l,r=rows[left],rows[~left]
  if unique_cases(l)<minleaf or unique_cases(r)<minleaf:return leaf(rows)
  return dict(kind='split',feature_index=f,threshold=threshold,left=build(int(tr.children_left[n]),l),right=build(int(tr.children_right[n]),r))
 return build(0,ix)
def predict(t,rows,out):
 if t['kind']=='leaf':out[rows]=t['raw_p'];return
 z=X[rows,t['feature_index']];left=np.isnan(z)|(z<=t['threshold']);predict(t['left'],rows[left],out);predict(t['right'],rows[~left],out)
def train_tree(config,fold,number,training):
 guard();codes=np.unique(cg[training]);rng=np.random.default_rng(np.random.SeedSequence([20261106,31,fold,number,0]));draw=rng.choice(codes,size=max(1,int(round(len(codes)*config['fraction']))),replace=True);mult=np.bincount(draw,minlength=nGroups)
 mask=np.zeros(len(truth),bool);mask[training]=True;ix=np.flatnonzero(eligible&np.repeat(mask,2)&(mult[wg]>0));assert unique_cases(ix)>=config['minleaf']
 weights=np.where(y,1.,config['cost'])/np.maximum(1,counts[ids]);splitrng=np.random.default_rng(np.random.SeedSequence([20261106,31,fold,number,1]))
 if config['kind']=='custom':
  expanded=np.repeat(ix,mult[wg[ix]]);return compact(OldTree(X,y,ids,weights,names,wg,splitrng,config['depth'],config['minleaf'],config['mtry']).fit(expanded))
 est=DecisionTreeClassifier(criterion=config['criterion'],splitter=config['splitter'],max_depth=config['depth'],max_features=config['mtry'],min_samples_leaf=config['row_min'],min_samples_split=2,max_leaf_nodes=config['max_leaves'],random_state=int(splitrng.integers(0,2**31-1)))
 est.fit(X32[ix],y[ix],sample_weight=weights[ix]*mult[wg[ix]])
 return export_compiled(est,ix,mult,config['minleaf'])
def mmetrics(scores,cutoff):
 pred=(scores>=cutoff).all(axis=1)&gates
 return dict(TP=int((pred&truth).sum()),FP=int((pred&~truth).sum()),FN=int((~pred&truth).sum()),TN=int((~pred&~truth).sum()))
def run_oof(config,end,start=0):
 rid=config['id'];dest=P/phase/rid;assert not dest.exists();dest.mkdir(parents=True)
 previous=json.loads((P/'scout'/rid/'receipt.json').read_text()) if start else None
 if start:assert sha(P/'scout'/rid/'scores.npy')==previous['scores_sha256']
 scores=np.zeros((len(truth),2)) if start==0 else np.load(P/'scout'/rid/'scores.npy')*start
 tree_hashes={}
 for fold in range(3):
  training=np.flatnonzero(folds!=fold);test=np.flatnonzero(folds==fold);testrows=np.ravel(np.column_stack([2*test,2*test+1]));assert not set(cg[training])&set(cg[test]);models=[];hh=[]
  for number in range(start,end):
   tree=train_tree(config,fold,number,training);raw=np.empty(len(y));predict(tree,testrows,raw);scores[test]+=raw[testrows].reshape(-1,2);hh.append(hashlib.sha256(json.dumps(tree,separators=(',',':')).encode()).hexdigest())
   if config['kind']=='custom':models.append(tree)
  tree_hashes[str(fold)]=(previous['tree_hashes'][str(fold)]+hh) if previous else hh
  if models:write(dest/f'fold-{fold}.json',dict(features=names,trees=models))
 scores/=end;assert np.isfinite(scores).all();np.save(dest/'scores.npy',scores)
 points=[dict(recipe=rid,trees=end,cutoff=float(c),**mmetrics(scores,c)) for c in manifest['cutoffs']]
 write(dest/'points.json',points);write(dest/'receipt.json',dict(recipe=config,trees=end,start=start,scores_sha256=sha(dest/'scores.npy'),tree_hashes=tree_hashes,seconds=time.monotonic()-START,raw_model='float64rerouted/postpruned/rawbootstrapwindowmean'))
 print(json.dumps(dict(phase=phase,part=part,recipe=rid,done=True,seconds=round(time.monotonic()-START,1))),flush=True)
def fit_models(job):
 config=job['config'];rid=config['id'];end=job['trees'];dest=P/'models'/rid;assert not dest.exists();dest.mkdir(parents=True)
 sourcephase='scout' if config['kind']=='custom' else 'extend';receipt=json.loads((P/sourcephase/rid/'receipt.json').read_text())
 for fold in range(3):
  target=dest/f'fold-{fold}.json'
  if config['kind']=='custom':target.write_bytes((P/'scout'/rid/f'fold-{fold}.json').read_bytes());continue
  training=np.flatnonzero(folds!=fold);trees=[train_tree(config,fold,n,training) for n in range(end)]
  hashes=[hashlib.sha256(json.dumps(t,separators=(',',':')).encode()).hexdigest() for t in trees];assert hashes==receipt['tree_hashes'][str(fold)],'Foldreproductionchanged'
  write(target,dict(features=names,trees=trees))
 trees=[train_tree(config,3,n,np.arange(len(truth))) for n in range(end)];write(dest/'fullfit.json',dict(features=names,trees=trees))
 write(dest/'FREEZE.json',dict(recipe=config,trees=end,folds={str(f):sha(dest/f'fold-{f}.json') for f in range(3)},fullfit=sha(dest/'fullfit.json'),data_sha256=manifest['data_sha256'],training_cases=len(truth),status='frozen_before_native_replay'))
 print(json.dumps(dict(phase=phase,part=part,model=rid,done=True,seconds=round(time.monotonic()-START,1))),flush=True)
try:
 guard()
 if phase=='scout':
  jobs=manifest['recipes']+manifest['references']
  for i,c in enumerate(jobs):
   if i%4==part:run_oof(c,64 if c['kind']=='custom' else 32)
 elif phase=='extend':
  plan=json.loads((P/'PROMOTE.json').read_text())
  for i,c in enumerate(plan['recipes']):
   if i%4==part:run_oof(c,128,32)
 else:
  plan=json.loads((P/'FINALISTS.json').read_text())
  for i,j in enumerate(plan['model_jobs']):
   if i%4==part:fit_models(j)
 write(P/f'{phase}-worker-{part}.json',dict(complete=True,seconds=time.monotonic()-START,peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,sklearn=sklearn.__version__))
except BaseException as e:
 write(P/f'{phase}-worker-{part}.json',dict(complete=False,error=str(e),no_automatic_retry=True));raise
finally:signal.alarm(0)
