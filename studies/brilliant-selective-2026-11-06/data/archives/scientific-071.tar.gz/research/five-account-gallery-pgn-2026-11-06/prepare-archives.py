"""Bounded public PGN archive preparation for the four requested accounts."""
import datetime
import hashlib
import json
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
destination = ROOT / 'raw-pgn'
destination.mkdir(exist_ok=True)
cached = {}
for p in (WORK / 'research').glob('**/original-pgn/*.pgn'):
    if p.stat().st_size:
        cached.setdefault(p.name.lower(), p)
months = ['2025-11', '2025-12'] + [f'2026-{m:02}' for m in range(1, 12)]
receipts = []
for account in ['knvb', 'hansen', 'gothamchess', 'hikaru']:
    for month in months:
        filename = f'{account}-{month}.pgn'
        path = destination / filename
        source = 'download'
        if month != '2026-11' and filename in cached:
            path = cached[filename]
            source = 'existing_archive'
        elif not path.exists():
            url = f'https://api.chess.com/pub/player/{account}/games/{month.replace("-", "/")}/pgn'
            req = urllib.request.Request(url, headers={'User-Agent': 'MuteChessResearch-PGN-collection/1.0'})
            with urllib.request.urlopen(req, timeout=30) as response:
                data = response.read()
            if data and not data.lstrip().startswith(b'[Event '):
                raise RuntimeError(f'Unexpected archive content: {url}')
            path.write_bytes(data)
        receipts.append({'account': account, 'month': month, 'source': source,
                         'path': str(path.relative_to(WORK)), 'bytes': path.stat().st_size,
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        (ROOT / 'ARCHIVES.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps({'account': account, 'months': 13,
                      'downloaded': sum(r['source'] == 'download' for r in receipts if r['account'] == account)}), flush=True)
(ROOT / 'ARCHIVES-COMPLETE.json').write_text(json.dumps({'complete': True, 'files': len(receipts),
    'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
