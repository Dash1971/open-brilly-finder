"""Bounded seven-account source-gallery PGN merge; no model annotations or analysis."""
import collections
import csv
import hashlib
import io
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, '<temporary-dependencies>/brilly-research-deps')
import chess
import chess.pgn

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
FIVE = WORK / 'research/five-account-gallery-pgn-2026-11-06'
MAGNUS = WORK / 'research/brilliant-fast-candidate-2026-11-06/external'
WITTY_SOURCE = WORK / 'research/brilliant-fresh-witty-2026-11-06'
SOURCES = [
    ('five_accounts', FIVE, 'five-accounts-last-12-months-chesscom-brilliants.pgn'),
    ('MagnusCarlsen', MAGNUS, 'magnus-last-12-months-chesscom-brilliants.pgn'),
    ('Witty_Alien', ROOT / 'witty', 'witty-alien-last-12-months-chesscom-brilliants.pgn'),
]
DEST = ROOT / 'seven-accounts-last-12-months-chesscom-brilliants.pgn'
started = time.monotonic()


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def receipt(path):
    return {'file': str(path.relative_to(WORK)), 'sha256': digest(path.read_bytes()), 'bytes': path.stat().st_size}


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def parse(raw):
    game = chess.pgn.read_game(io.StringIO(raw))
    need(game is not None and not game.errors, 'PGN parse error')
    need(all(len(n.variations) <= 1 for n in [game, *game.mainline()]), 'Unexpected variation')
    return game


def serialized(game):
    return game.accept(chess.pgn.StringExporter(headers=True, variations=False, comments=True))


def clocks(text):
    return re.findall(r'\[%clk [^\]]+\]', text)


def placement(classes):
    pieces = {}
    for cls in classes:
        p = re.findall(r'\b([wb][pnbrqk])\b', cls)
        xy = re.findall(r'\bsquare-([1-8])([1-8])\b', cls)
        need(len(p) == len(xy) == 1 and 'piece' in cls.split(), 'Invalid saved piece class')
        square = chess.square(int(xy[0][0]) - 1, int(xy[0][1]) - 1)
        need(square not in pieces, 'Overlapping saved pieces')
        pieces[square] = chess.Piece.from_symbol(p[0][1].upper() if p[0][0] == 'w' else p[0][1])
    board = chess.Board.empty()
    board.set_piece_map(pieces)
    return board.board_fen()


def annotation(row):
    return (f'Chess.com gallery: Brilliant (!!). Account: {row["account"]}. '
            f'Category: {row["category"]}. Captured: {row["captured_at"]}. '
            f'Source: {row["source_link"]}')


source_receipts, source_summaries, raw_receipts = [], {}, {}
labels, labels_at, source_label_groups = [], collections.defaultdict(list), {}
gallery_maps = {}
accounts = {}
for source_name, folder, pgn_name in SOURCES:
    summary = read(folder / 'EXPORT-SUMMARY.json')
    source_summaries[source_name] = summary
    for name in [pgn_name, 'brilliant-moves.json']:
        path = folder / name
        actual = receipt(path)
        expected = next(r for r in summary['outputs'] if r['file'] == actual['file'])
        need(actual == expected, f'Input export receipt changed: {path}')
        source_receipts.append(actual)
    source_receipts.append(receipt(folder / 'EXPORT-SUMMARY.json'))
    for raw in summary['source_files']:
        path = WORK / raw['file']
        need(receipt(path) == raw, f'Original monthly source changed: {path}')
        raw_receipts[raw['file']] = raw
    rows = read(folder / 'brilliant-moves.json')
    need(len(rows) == summary['labels'], 'Source label count mismatch')
    grouped = collections.defaultdict(list)
    for old in rows:
        row = dict(old)
        row['label_source_export'] = str((folder / 'brilliant-moves.json').relative_to(WORK))
        row['label_source_export_sha256'] = receipt(folder / 'brilliant-moves.json')['sha256'] if not grouped else source_receipts[-2]['sha256']
        # Use the exact previously checked JSON receipt, independent of source row order.
        row['label_source_export_sha256'] = next(r['sha256'] for r in source_receipts if r['file'] == row['label_source_export'])
        labels.append(row)
        labels_at[(row['game_id'], row['ply'])].append(row)
        grouped[row['game_id']].append(row)
    source_label_groups[source_name] = grouped
    for account, stats in summary['accounts'].items():
        accounts[account] = dict(stats)
        if account != 'Witty_Alien':
            path = (WORK / 'research/nelsi-gallery-pgn-2026-11-06/gallery.json' if account == 'nelsi' else MAGNUS / 'MagnusCarlsen/gallery.json' if account == 'MagnusCarlsen' else FIVE / account / 'gallery.json')
            gallery = read(path)
            gallery_maps[account] = {(r['game_id'], r['ply']): r for r in gallery['entries']}
            source_receipts.append(receipt(path))

need(len(labels) == 8298 and len(accounts) == 7, 'Wrong seven-account label count')
need(len({(r['account'], r['game_id'], r['ply']) for r in labels}) == 8298, 'Duplicate source labels')
need(len(labels_at) == 8298, 'Different account labels collide on one mover/ply')
annotation_index = {(r['account'], r['game_id'], r['ply']): r for r in labels}
evidence_counts = collections.Counter()
board_views = arrow_views = 0
input_game_records = []
bank, overlaps, source_totals = {}, [], {}


def verify(game, rows, inspect_evidence):
    global board_views, arrow_views
    gid = game.headers['Link'].rsplit('/', 1)[1]
    by_ply = collections.defaultdict(list)
    for row in rows:
        by_ply[row['ply']].append(row)
    board, seen = game.board(), set()
    for ply, node in enumerate(game.mainline(), 1):
        before, san, uci = board.fen(), board.san(node.move), node.move.uci()
        mover = game.headers['White' if board.turn == chess.WHITE else 'Black']
        board.push(node.move)
        targets = by_ply.get(ply, [])
        need(node.nags == ({3} if targets else set()), f'Unexpected/missing annotation {gid}:{ply}')
        for row in targets:
            need(mover.lower() == row['account'].lower(), f'Wrong label mover {gid}:{ply}')
            need((before, board.fen(), san, uci) == (row['fen_before'], row['fen_after'], row['san'], row['uci']), f'Label identity changed {gid}:{ply}')
            need(annotation(row) in node.comment, f'Category/source comment missing {gid}:{ply}')
            seen.add((row['account'], gid, ply))
            if not inspect_evidence:
                continue
            if row['account'] == 'Witty_Alien':
                captures = row['evidence_captures']
            else:
                capture = gallery_maps[row['account']][(gid, ply)]
                need(capture['game_item'] == row['game_item'] and set(c for c in capture['categories'] if c != 'Brilliant Moves') == set(row['source_categories']), 'Prior category/card provenance mismatch')
                captures = [capture]
            has_board, has_arrow = False, False
            for capture in captures:
                if capture.get('pieces'):
                    need(capture.get('brilliant_icon') is True and placement(capture['pieces']) == board.board_fen(), f'Saved board mismatch {gid}:{ply}')
                    has_board = True
                    board_views += 1
                if capture.get('arrows'):
                    for arrow in capture['arrows']:
                        need(re.fullmatch(r'[a-h][1-8][a-h][1-8][qrbn]?', arrow) and arrow[:4] == uci[:4], f'Saved arrow mismatch {gid}:{ply}')
                    has_arrow = True
                    arrow_views += 1
            need(row['board_verified'] == has_board, 'Evidence grade/board flag mismatch')
            grade = ('rendered_board_and_arrow_exact' if has_board and has_arrow else 'rendered_board_exact' if has_board else 'gallery_link_uuid_ply_mover_legal_pgn_arrow_exact' if has_arrow else 'gallery_link_uuid_ply_mover_legal_pgn')
            row['evidence_grade'] = grade
            row['arrows_verified'] = has_arrow
            evidence_counts[grade] += 1
    need(len(seen) == len(rows), f'Label outside complete game {gid}')
    return seen, len(list(game.mainline()))


for source_name, folder, pgn_name in SOURCES:
    grouped = source_label_groups[source_name]
    games_seen, moves_seen = set(), 0
    for block in re.split(r'(?=^\[Event )', (folder / pgn_name).read_text(), flags=re.M):
        if not block.strip():
            continue
        game = parse(block)
        gid = game.headers['Link'].rsplit('/', 1)[1]
        need(gid in grouped and gid not in games_seen, 'Unexpected/duplicate input game')
        games_seen.add(gid)
        _, n = verify(game, grouped[gid], True)
        moves_seen += n
        normalized = serialized(game)
        if gid in bank:
            old = parse(bank[gid]['text'])
            old_nodes, new_nodes = list(old.mainline()), list(game.mainline())
            need(old.board().fen() == game.board().fen() and [n.move.uci() for n in old_nodes] == [n.move.uci() for n in new_nodes], 'Shared game move conflict')
            need(clocks(bank[gid]['text']) == clocks(normalized), 'Shared game clock-token conflict')
            for header in ['Link', 'White', 'Black', 'Result', 'TimeControl']:
                need(old.headers.get(header) == game.headers.get(header), 'Shared game critical-header conflict: ' + header)
            old_rows = bank[gid]['rows']
            for ply, (a, b) in enumerate(zip(old_nodes, new_nodes), 1):
                plain_a, plain_b = a.comment, b.comment
                for row in old_rows:
                    if row['ply'] == ply:
                        plain_a = plain_a.replace(annotation(row), '').strip()
                for row in grouped[gid]:
                    if row['ply'] == ply:
                        plain_b = plain_b.replace(annotation(row), '').strip()
                need(plain_a == plain_b and a.starting_comment == b.starting_comment, f'Shared original comment conflict {gid}:{ply}')
            for row in grouped[gid]:
                node = old_nodes[row['ply'] - 1]
                if annotation(row) not in node.comment:
                    node.comment = (node.comment + ' ' + annotation(row)).strip()
                node.nags.add(3)
            header_differences = {k: {'existing': old.headers.get(k), 'additional_source': game.headers.get(k)} for k in set(old.headers) | set(game.headers) if old.headers.get(k) != game.headers.get(k) and k not in {'Annotator', 'BrilliantAccounts', 'BrilliantCount', 'BrilliantCaptured'}}
            bank[gid]['rows'] += grouped[gid]
            old.headers['BrilliantAccounts'] = '; '.join(sorted({r['account'] for r in bank[gid]['rows']}))
            old.headers['BrilliantCount'] = str(len(bank[gid]['rows']))
            bank[gid]['text'] = serialized(old)
            bank[gid]['sources'].append(source_name)
            overlaps.append({'game_id': gid, 'sources': list(bank[gid]['sources']), 'accounts': sorted({r['account'] for r in bank[gid]['rows']}), 'labels_preserved': len(bank[gid]['rows']), 'moves': n, 'clock_tokens_deduplicated': len(clocks(normalized)), 'noncritical_header_differences_existing_preserved': header_differences})
        else:
            bank[gid] = {'text': normalized, 'rows': grouped[gid], 'sources': [source_name], 'sort': (game.headers.get('UTCDate', game.headers.get('Date', '')), game.headers.get('UTCTime', ''), game.headers['Link'])}
    need(games_seen == set(grouped), 'Incomplete source game scan')
    need(len(games_seen) == source_summaries[source_name]['games'] and moves_seen == source_summaries[source_name]['roundtrip_original_move_checks'], 'Source counts changed')
    source_totals[source_name] = {'games': len(games_seen), 'labels': sum(len(rs) for rs in grouped.values()), 'moves': moves_seen}
    print(json.dumps({'source_verified': source_name, **source_totals[source_name]}), flush=True)

need(len(bank) == 7019 and len(overlaps) == 1 and overlaps[0]['game_id'] == '158576248417', 'Unexpected seven-account deduplication counts')
with DEST.open('w') as stream:
    for gid, item in sorted(bank.items(), key=lambda pair: pair[1]['sort']):
        stream.write(item['text'] + '\n\n')

# Exhaustive final reread: every game, move, comment, header, clock and Brilliant label.
seen_labels, games_seen, moves_checked, clocks_checked = set(), set(), 0, 0
with DEST.open() as stream:
    while (game := chess.pgn.read_game(stream)) is not None:
        need(not game.errors, 'Combined output PGN parse error')
        gid = game.headers['Link'].rsplit('/', 1)[1]
        need(gid in bank and gid not in games_seen, 'Combined duplicate/unexpected game')
        games_seen.add(gid)
        current = serialized(game)
        need(current == bank[gid]['text'], 'Combined roundtrip moved/changed original data')
        need(clocks(current) == clocks(bank[gid]['text']), 'Combined raw clock token changed')
        checked, n = verify(game, bank[gid]['rows'], False)
        seen_labels.update(checked)
        moves_checked += n
        clocks_checked += len(clocks(current))
need(len(games_seen) == 7019 and seen_labels == set(annotation_index), 'Incomplete final label/game roundtrip')
labels.sort(key=lambda r: (r['date'], r['game_id'], r['ply'], r['account']))
write('brilliant-moves.json', labels)
fields = ['account', 'game_id', 'ply', 'san', 'uci', 'category', 'source_categories', 'evidence_grade', 'board_verified', 'arrows_verified', 'fen_before', 'fen_after']
fields += sorted(set().union(*(r.keys() for r in labels)) - set(fields))
with (ROOT / 'brilliant-moves.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in labels:
        writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})
for account, stats in accounts.items():
    rs = [r for r in labels if r['account'] == account]
    need(len(rs) == stats['labels'], 'Per-account labels lost')
    stats['categories'] = dict(collections.Counter(r['category'] for r in rs))
    stats['evidence_grades'] = dict(collections.Counter(r['evidence_grade'] for r in rs))
    stats['games'] = len({r['game_id'] for r in rs})

manifest = {'complete': True, 'scope': 'Seven complete Chess.com time=365 Brilliant galleries captured 2026-11-06; full games represented by those galleries. All labels are copied Chess.com source labels, never model awards. Unlabeled moves are unknown.',
 'accounts': accounts, 'games': len(bank), 'labels': len(labels), 'unique_annotated_plies': len(labels_at), 'input_game_records': sum(r['games'] for r in source_totals.values()),
 'deduplicated_shared_games': overlaps, 'source_counts': source_totals, 'evidence_grades': dict(evidence_counts), 'available_board_views_checked': board_views, 'available_arrow_views_checked': arrow_views,
 'roundtrip_game_checks': len(games_seen), 'roundtrip_annotation_checks': len(seen_labels), 'roundtrip_move_checks': moves_checked, 'exact_clock_tokens_preserved': clocks_checked,
 'source_export_files': source_receipts, 'original_monthly_source_files': list(raw_receipts.values()),
 'outputs': [receipt(DEST), receipt(ROOT / 'brilliant-moves.json'), receipt(ROOT / 'brilliant-moves.csv'), receipt(ROOT / 'witty/witty-alien-last-12-months-chesscom-brilliants.pgn')],
 'date_min': min(r['date'] for r in labels), 'date_max': max(r['date'] for r in labels), 'label_capture_date': '2026-11-06',
 'limitations': ['Chess.com gallery labels are source observations, not independent objective move judgments.', 'Witty has 1308 exact rendered-board labels; 3103 have explicit gallery link/UUID/ply/mover/legal-PGN evidence and no fabricated rendered-board claim.', 'Witty named sacrifice categories were not captured in its complete metadata; its 4411 labels retain Uncategorized rather than inferred categories.', 'The inherited five-account time=365 gallery includes PGN game-start dates as early as 2025-11-05; existing source labels were retained without changing the gallery window semantics.'],
 'no_engines_no_fitting_no_model_awards': True, 'elapsed_seconds': round(time.monotonic() - started, 3), 'merge_script': receipt(Path(__file__).resolve())}
write('MANIFEST.json', manifest)
write('SOURCE-COUNTS.json', {'accounts': accounts, 'source_counts': source_totals, 'deduplicated_shared_games': overlaps})
print(json.dumps({k: manifest[k] for k in ['games', 'labels', 'unique_annotated_plies', 'input_game_records', 'deduplicated_shared_games', 'evidence_grades', 'available_board_views_checked', 'available_arrow_views_checked', 'roundtrip_game_checks', 'roundtrip_annotation_checks', 'roundtrip_move_checks', 'exact_clock_tokens_preserved', 'outputs', 'elapsed_seconds']}, indent=2), flush=True)
