#!/bin/zsh
set -eu
study_dir=${0:A:h}
rsync -az -e 'ssh -o BatchMode=yes -o ConnectTimeout=6 -o ServerAliveInterval=10 -o ServerAliveCountMax=2' macmininew:/tmp/mute-gallery-fast-2026-11-06/candidate/external/assessment-4/ "$study_dir/assessment-4/" &
copy4=$!
rsync -az -e 'ssh -o BatchMode=yes -o ConnectTimeout=6 -o ServerAliveInterval=10 -o ServerAliveCountMax=2' macmininew:/tmp/mute-gallery-fast-2026-11-06/candidate/external/assessment-5/ "$study_dir/assessment-5/" &
copy5=$!
rsync -az -e 'ssh -o BatchMode=yes -o ConnectTimeout=6 -o ServerAliveInterval=10 -o ServerAliveCountMax=2' openclaw-mac:/tmp/mute-gallery-fast-2026-11-06/candidate/external/assessment-6/ "$study_dir/assessment-6/" &
copy6=$!
rsync -az -e 'ssh -o BatchMode=yes -o ConnectTimeout=6 -o ServerAliveInterval=10 -o ServerAliveCountMax=2' openclaw-mac:/tmp/mute-gallery-fast-2026-11-06/candidate/external/assessment-7/ "$study_dir/assessment-7/" &
copy7=$!
wait $copy4
wait $copy5
wait $copy6
wait $copy7
python3 "$study_dir/summarize.py"
