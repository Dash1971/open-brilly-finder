"""Bounded replay recount: preserved pause plus three fixed remaining segments.

Incomplete downloads produce PROGRESS-SUMMARY.json. Final RESULTS.json and CSVs
require every frozen game exactly once and successful remaining-job receipts.
"""
import collections
import csv
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD_MODEL = '44704ac06378d3f671a4eed959e21959f759c0437c71af1f9119d1081293c0b7'
REFERENCES = ['reference_a', 'reference_b', 'production', 'pr285']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def object_sha(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def optional_read(path):
    try:
        return read(path)
    except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError):
        return None


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def metrics(counter):
    c = {k: int(counter[k]) for k in ['TP', 'FN', 'FP', 'TN']}
    positives, negatives = c['TP'] + c['FN'], c['FP'] + c['TN']
    return dict(**c, positives=positives, negatives=negatives,
                brilliant_recognition_percent=100*c['TP']/positives if positives else None,
                false_positive_percent=100*c['FP']/negatives if negatives else None)


def main():
    pins = read(ROOT/'BUILD-PINS.json')
    for path, digest in pins['files'].items():
        assert sha(ROOT/path) == digest, 'Build pin changed: ' + path
    pin_path = ROOT/'FINALISTS-PIN.json'
    plan = read(pin_path)
    specs = (plan.get('refs') or plan['references']) + plan['finalists']
    names = ['production', 'pr285'] + [s['id'] for s in specs]
    finalists = [s['id'] for s in plan['finalists']]
    assert len(set(names)) == len(names)
    inputs = []
    expected_ids = set()
    expected_counts = collections.Counter()
    expected_exclusions = []
    for batch in range(7):
        path = ROOT/f'INPUT-{batch}.json'
        assert sha(path) == pins['inputs'][str(batch)]
        inp = read(path)
        inputs.append(inp)
        for game in inp['games']:
            gid = game['game_id']
            assert gid not in expected_ids, 'Duplicate expected game: ' + gid
            expected_ids.add(gid)
            fold = 'fullfit' if batch == 6 else str(batch//2)
            assert str(game['model_fold']) == fold
            scored = game['scored_plies']
            assert len(scored) == len(set(scored))
            assert all(isinstance(p, int) and 0 < p < len(game['nodes']) for p in scored)
            labels = {t['ply'] for t in game['targets']}
            expected_counts['games'] += 1
            expected_counts['all_moves'] += len(game['nodes']) - 1
            if batch == 6:
                assert not scored and game['cohort'] == 'user_examples'
            else:
                expected_counts['own_moves'] += len(scored)
                expected_counts['positives'] += len(set(scored) & labels)
            for exclusion in game.get('scoring_exclusions', []):
                assert exclusion['ply'] not in scored
                expected_exclusions.append(dict(game_id=gid, **exclusion))
    expected_counts['negatives'] = expected_counts['own_moves'] - expected_counts['positives']
    assert expected_counts['games'] == 3475
    assert (expected_counts['own_moves'], expected_counts['positives'], expected_counts['negatives']) == (150045, 3857, 146188)

    # Original INPUTs remain the only cohort definition. The stopped worker
    # STATEs are not completion receipts; their preserved per-game hashes are.
    study = ROOT.parent
    continuation_path = study/'CONTINUATION-PLAN.json'
    continuation = read(continuation_path)
    completed_path, pause_path = study/'COMPLETED-GAMES.json', study/'PAUSE-CHECKPOINT.json'
    completed, pause = read(completed_path), read(pause_path)
    if 'completed_manifest_sha256' in continuation:
        assert sha(completed_path) == continuation['completed_manifest_sha256']
    if 'pause_checkpoint_sha256' in continuation:
        assert sha(pause_path) == continuation['pause_checkpoint_sha256']
    assert pause['completed_games'] == 1319 and pause['remaining_games'] == 2156
    assert pause['total_games'] == len(expected_ids)
    master = {g['game_id']: (batch, g) for batch, inp in enumerate(inputs) for g in inp['games']}
    jobs, assigned, source_roots = [], set(), []
    pause_batches = {row['batch']: row for row in pause['batches']}
    for batch, inp in enumerate(inputs):
        receipt = pause_batches[batch]
        assert receipt['input_sha256'] == pins['inputs'][str(batch)]
        assert sha(ROOT/f'results-{batch}/FREEZE.json') == receipt['freeze_sha256']
        saved = completed[str(batch)]
        assert len(saved) == receipt['completed']
        keys = {row['game_id']: row['sha256'] for row in saved}
        assert len(keys) == len(saved) and not assigned.intersection(keys)
        actual = {p.stem for p in (ROOT/f'results-{batch}').glob('*.json') if p.stem in expected_ids}
        assert actual == set(keys), 'Original paused result partition changed'
        for gid, digest in keys.items():
            assert master[gid][0] == batch
            assert sha(ROOT/f'results-{batch}/{gid}.json') == digest
        assigned.update(keys)
        jobs.append(dict(root=ROOT, batch=batch, pins=pins, games=[g for g in inp['games'] if g['game_id'] in keys],
                         original_total=len(inp['games']), paused=True, preserved_hashes=keys))
    assert len(assigned) == 1319
    segments = continuation['segments']
    assert len(segments) == 3
    for segment in segments:
        value = segment['root'] if isinstance(segment, dict) else segment
        segment_root = Path(value)
        if not segment_root.is_absolute():
            segment_root = study/segment_root
        segment_root = segment_root.resolve()
        assert segment_root.parent == study.resolve() and segment_root.name in ['replay-cont-1', 'replay-cont-2', 'replay-cont-3']
        assert segment_root not in source_roots
        source_roots.append(segment_root)
        segment_pins = read(segment_root/'BUILD-PINS.json')
        assert sha(segment_root/'BUILD-PINS.json') == segment['build_pins_sha256']
        declared_batches = {row['batch']: row for row in segment['batches']}
        assert segment_pins['files'] == pins['files'], 'Continuation runtime/model pins differ'
        for path, digest in segment_pins['files'].items():
            assert sha(segment_root/path) == digest, 'Continuation build changed: ' + path
        assert sha(segment_root/'FINALISTS-PIN.json') == sha(pin_path)
        for batch in range(7):
            input_path = segment_root/f'INPUT-{batch}.json'
            assert sha(input_path) == segment_pins['inputs'][str(batch)]
            game_list = read(input_path)['games']
            assert sha(input_path) == declared_batches[batch]['input_sha256']
            assert len(game_list) == declared_batches[batch]['games']
            assert len(game_list) <= 200
            for game in game_list:
                gid = game['game_id']
                assert gid in master and gid not in assigned, 'Duplicate/unknown continuation game: ' + gid
                assert master[gid][0] == batch and game == master[gid][1], 'Continuation game/mask changed'
                assigned.add(gid)
            if game_list:
                jobs.append(dict(root=segment_root, batch=batch, pins=segment_pins, games=game_list,
                                 original_total=len(game_list), paused=False, preserved_hashes={}))
    assert assigned == expected_ids, 'Continuation partitions do not cover the original cohort exactly'

    def empty_models():
        return {name: collections.Counter() for name in names}
    aggregate = empty_models()
    by_fold = collections.defaultdict(empty_models)
    by_account = collections.defaultdict(empty_models)
    by_cohort = collections.defaultdict(empty_models)
    paired = collections.defaultdict(collections.Counter)
    seen, missing, partial, owners, states = set(), [], [], [], []
    games_by_fold, games_by_cohort = collections.Counter(), collections.Counter()
    checked = collections.Counter()
    csv_fields = ['cohort', 'fold', 'account', 'game_id', 'ply', 'san', 'uci', 'truth'] + names
    false_fields = csv_fields[:8] + ['finalist', 'comparison_reference', 'reference_award', 'new_false_award']
    all_path, false_path = ROOT/'all-scored-moves.csv.tmp', ROOT/'new-false-awards.csv.tmp'
    with all_path.open('w', newline='') as all_file, false_path.open('w', newline='') as false_file:
        all_writer = csv.DictWriter(all_file, fieldnames=csv_fields)
        false_writer = csv.DictWriter(false_file, fieldnames=false_fields)
        all_writer.writeheader()
        false_writer.writeheader()
        for job in jobs:
            batch, source_root, source_pins = job['batch'], job['root'], job['pins']
            game_list = job['games']
            dest = source_root/f'results-{batch}'
            state = optional_read(dest/'STATE.json')
            states.append(dict(root=source_root.name, batch=batch, preserved_paused_partition=job['paused'],
                complete_for_partition=job['paused'] or bool(state and state.get('complete') and not state.get('failure')),
                state=state))
            if state and state.get('complete'):
                assert not state.get('failure') and state['done'] == state['total'] == job['original_total']
            saved_freeze = optional_read(dest/'FREEZE.json')
            if not saved_freeze:
                missing.extend(g['game_id'] for g in game_list)
                continue
            freeze = saved_freeze['configuration']
            fold = 'fullfit' if batch == 6 else str(batch//2)
            assert freeze['batch'] == batch and freeze['model_fold'] == fold
            assert freeze['owner_diagnostic'] == (batch == 6)
            assert freeze['inputSHA'] == source_pins['inputs'][str(batch)]
            assert freeze['buildPinsSHA'] == sha(source_root/'BUILD-PINS.json')
            assert freeze['workerSourceSHA'] == sha(source_root/'worker.mts')
            assert freeze['finalists_pin_sha256'] == sha(pin_path)
            bundle = 'fullfit' if batch == 6 else 'fold' + fold
            assert freeze['entrySourceSHA'] == sha(source_root/f'bundles/{bundle}/worker.mts')
            assert freeze['bundleSHA'] == sha(source_root/f'bundles/{bundle}/worker.mjs')
            assert freeze['variant_names'] == names
            models = {n: dict(model_sha256=OLD_MODEL, cutoff=5/6) for n in ['production', 'pr285']}
            for spec in specs:
                chosen = spec['fullfit'] if batch == 6 else spec['folds'][fold]
                models[spec['id']] = dict(model_sha256=chosen['model_sha256'], cutoff=spec['cutoff'], model_fold=fold)
            assert freeze['variant_models'] == models
            freeze_hash = object_sha(freeze)
            batch_searches = batch_done = 0
            for game in game_list:
                gid = game['game_id']
                path = dest/(gid+'.json')
                d = optional_read(path)
                if not d or not d.get('complete'):
                    (partial if path.exists() else missing).append(gid)
                    continue
                assert gid not in seen and d['game_id'] == gid
                assert d['input_game_sha256'] == object_sha(game) and d['freeze_sha256'] == freeze_hash
                assert d['profile'] == {'depth': 12, 'movetime': 500}
                assert d['model_fold'] == fold and d['owner_diagnostic'] == (batch == 6)
                assert d['scoring_enabled'] == (batch != 6)
                assert d['variant_models'] == models and set(d['variants']) == set(names)
                assert d['scored_plies'] == ([] if batch == 6 else game['scored_plies'])
                assert d['scoring_exclusions'] == game.get('scoring_exclusions', [])
                assert d['targets'] == game['targets'] and d['cohort'] == game['cohort']
                assert len(d['initial']) == len(game['nodes']) and not d['initial_searches']
                seen.add(gid)
                batch_done += 1
                games_by_fold[fold] += 1
                games_by_cohort[game['cohort']] += 1
                checked['games'] += 1
                checked['all_moves'] += len(game['nodes']) - 1
                checked['fresh_engine_searches'] += d['fresh_engine_searches']
                batch_searches += d['fresh_engine_searches']
                maps = {n: dict(d['variants'][n]['outcomes']) for n in names}
                for name in names:
                    variant = d['variants'][name]
                    assert variant['model'] == models[name]
                    family = 'production' if name in ['production', 'pr285'] else 'fold_trained'
                    assert variant['classification_cache_id'] == object_sha(dict(cache_family=family,
                        model_sha256=models[name]['model_sha256'], cutoff=models[name]['cutoff']))
                    assert variant['confirmation_cost'] <= 6
                    assert variant['confirmation_cost'] == sum(len(q['fens']) for q in variant['confirmation_requests'])
                    assert len([v for v in variant['decisions'] if not v['confirmation']]) == len(game['nodes'])-1
                    checked['variant_budget_checks'] += 1
                scored, labels = set(game['scored_plies']), {t['ply'] for t in game['targets']}
                assert len(d['move_outcomes']) == len(game['nodes'])-1
                for ply, move in enumerate(d['move_outcomes'], 1):
                    assert move['ply'] == ply and move['uci'] == game['nodes'][ply]['uci'] and move['san'] == game['nodes'][ply]['san']
                    assert move['fen_before'] == game['nodes'][ply-1]['fen'] and move['fen_after'] == game['nodes'][ply]['fen']
                    mover = game['white'] if game['nodes'][ply-1]['fen'].split()[1] == 'w' else game['black']
                    assert move['mover'] == mover and move['gallery_positive'] == (ply in labels)
                    assert move['scored_player'] == (batch != 6 and ply in scored)
                    for name in names:
                        assert move[name] == maps[name].get(ply)
                    if batch == 6 or ply not in scored:
                        continue
                    account, truth = mover.lower(), ply in labels
                    assert account in game['scored_accounts']
                    predicted = {name: maps[name].get(ply) == '!!' for name in names}
                    row = dict(cohort=game['cohort'], fold=fold, account=account, game_id=gid,
                               ply=ply, san=move['san'], uci=move['uci'], truth=truth, **predicted)
                    all_writer.writerow(row)
                    checked['own_moves'] += 1
                    checked['positives'] += truth
                    for name, award in predicted.items():
                        key = 'TP' if truth and award else 'FN' if truth else 'FP' if award else 'TN'
                        for bucket in [aggregate, by_fold[fold], by_account[account], by_cohort[game['cohort']]]:
                            bucket[name][key] += 1
                    for finalist in finalists:
                        for reference in REFERENCES:
                            pair = paired[(finalist, reference)]
                            if predicted[finalist] and not predicted[reference]:
                                pair['genuine_gained' if truth else 'false_awards_added'] += 1
                            if predicted[reference] and not predicted[finalist]:
                                pair['genuine_lost' if truth else 'false_awards_removed'] += 1
                            if not truth and predicted[finalist] and not predicted[reference]:
                                false_writer.writerow({**{k: row[k] for k in csv_fields[:8]}, 'finalist': finalist,
                                    'comparison_reference': reference, 'reference_award': False, 'new_false_award': True})
                for target in game.get('expected_user_moves', []):
                    assert batch == 6 and not scored
                    ply = target['ply']
                    owners.append(dict(game_id=gid, target=target,
                        final_symbols={n: maps[n].get(ply) for n in names},
                        classifications={n: next(v['result'] for v in reversed(d['variants'][n]['decisions']) if v['ply'] == ply) for n in names},
                        scope='Full-fit owner diagnostic; excluded from every benchmark count'))
            if state and state.get('complete') and batch_done == job['original_total']:
                assert batch_searches == state['searches']

    missing = sorted(expected_ids - seen - set(partial))
    complete = seen == expected_ids and all(s['complete_for_partition'] for s in states)
    if complete:
        assert checked['own_moves'] == expected_counts['own_moves'] and checked['positives'] == expected_counts['positives']
        assert checked['all_moves'] == expected_counts['all_moves'] and len(owners) == 2
    summarized = lambda models: {name: metrics(c) for name, c in models.items()}
    comparisons = {}
    for finalist in finalists:
        comparisons[finalist] = {}
        for reference in REFERENCES:
            c = paired[(finalist, reference)]
            tp, fp = aggregate[finalist]['TP']-aggregate[reference]['TP'], aggregate[finalist]['FP']-aggregate[reference]['FP']
            comparisons[finalist][reference] = dict(**{k:int(c[k]) for k in ['genuine_gained','genuine_lost','false_awards_added','false_awards_removed']},
                net_TP=tp, net_FP=fp, net_additional_TP_per_net_additional_FP=tp/fp if fp > 0 else None,
                reference_scope='same-fold development CV' if reference.startswith('reference_') else 'fixed full-fit production, descriptive training-overlap bias')
    result = dict(complete=complete, at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        games_done=len(seen), games_expected=len(expected_ids), missing_games=missing, partial_json_games=partial,
        expected_counts=dict(expected_counts), checked_counts=dict(checked), workers=states,
        games_by_fold=dict(games_by_fold), games_by_cohort=dict(games_by_cohort),
        aggregate=summarized(aggregate), per_fold={k:summarized(v) for k,v in sorted(by_fold.items())},
        per_account={k:summarized(v) for k,v in sorted(by_account.items())},
        per_cohort={k:summarized(v) for k,v in sorted(by_cohort.items())}, paired_changes=comparisons,
        owner_examples=owners, primary_exclusions=expected_exclusions, models=plan,
        continuation=dict(original_preserved_games=1319, remaining_games=2156,
                          roots=[p.name for p in source_roots], full_master_cohort_preserved=True),
        source_hashes=dict(build_pins=sha(ROOT/'BUILD-PINS.json'), finalists_pin=sha(pin_path),
            continuation_plan=sha(continuation_path), completed_manifest=sha(completed_path),
            pause_checkpoint=sha(pause_path), summarizer=sha(Path(__file__))),
        limitations=['Recipes and cutoffs selected on OOF labels: native OOF replay remains selection-biased development CV, not independent validation.',
            'Reference A/B and finalists use the same held-out game folds; fixed production/PR285 weights have training overlap and are descriptive only.',
            'False-positive percentages use all scored own non-Brilliant moves in gallery-represented games, not selected feature controls.',
            'Owner games use full-fit models and are excluded from fold/account/aggregate metrics.',
            'No automatic winner or numeric owner-acceptance threshold is inferred from TP/FP tradeoffs.'])
    if complete:
        all_path.replace(ROOT/'all-scored-moves.csv')
        false_path.replace(ROOT/'new-false-awards.csv')
        write(ROOT/'RESULTS.json', result)
    else:
        all_path.unlink(missing_ok=True)
        false_path.unlink(missing_ok=True)
        write(ROOT/'PROGRESS-SUMMARY.json', result)
    print(json.dumps(dict(complete=complete, games_done=len(seen), games_expected=len(expected_ids),
        own_moves=checked['own_moves'], positives=checked['positives'], aggregate=result['aggregate'],
        owner_symbols=[dict(game_id=x['game_id'], symbols=x['final_symbols']) for x in owners]), indent=2))


if __name__ == '__main__':
    main()
