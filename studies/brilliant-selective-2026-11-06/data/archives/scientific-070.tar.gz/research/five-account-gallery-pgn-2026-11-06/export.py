"""Bounded five-account gallery export; copies observed labels without analysis.

Run only after all four new COMPLETE receipts exist. run([...], publish=False)
performs the same source and board checks for completed subsets without exporting.
"""
import collections
import csv
import hashlib
import io
import json
import re
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, '<temporary-dependencies>/brilly-research-deps')
import chess
import chess.pgn

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
NELSI = WORKSPACE / 'research/nelsi-gallery-pgn-2026-11-06'
ACCOUNTS = ('nelsi', 'KNVB', 'hansen', 'GothamChess', 'Hikaru')
PGN_NAME = 'five-accounts-last-12-months-chesscom-brilliants.pgn'


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def receipt(path):
    data = path.read_bytes()
    return {'file': str(path.relative_to(WORKSPACE)),
            'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def displayed_count(value):
    # The pilot saved the site's explicit empty-gallery message verbatim.
    if value == 'Their brilliant moves will appear here':
        return 0
    return int(value)


def load_gallery(account):
    folder = NELSI if account == 'nelsi' else ROOT / account
    complete_path = folder / ('FINAL-REPORT.json' if account == 'nelsi' else 'COMPLETE.json')
    require(complete_path.is_file(), f'{account}: missing completion receipt')
    complete = json.loads(complete_path.read_text())
    path = folder / 'gallery.json'
    gallery = json.loads(path.read_text())
    require(gallery['account'].lower() == account.lower(), f'{account}: gallery account')
    require(complete['account'].lower() == account.lower(), f'{account}: receipt account')
    entries = gallery['entries']
    count = int(gallery['all_types_displayed_count'])
    require(len(entries) == count, f'{account}: entry/displayed count mismatch')
    require(len({(r['game_id'], r['ply']) for r in entries}) == count,
            f'{account}: duplicate game/ply')
    if account == 'nelsi':
        require(all(complete[k] == count for k in
                    ('gallery_displayed', 'brilliants', 'board_matches', 'roundtrip_annotation_checks')),
                'nelsi: incomplete pilot receipt')
        require(complete['unmatched'] == 0, 'nelsi: unmatched pilot entries')
        require(receipt(path)['sha256'] == complete['gallery_sha256'], 'nelsi: gallery hash changed')
    else:
        require(all(complete[k] == count for k in ('entries', 'boards', 'displayed')),
                f'{account}: incomplete receipt')
        require(complete['categories'] == gallery['category_counts'],
                f'{account}: category receipt mismatch')
    category_counts = {c: displayed_count(v['displayed_count'])
                       for c, v in gallery['category_counts'].items()}
    actual = collections.Counter(c for r in entries for c in r['categories'] if c != 'Brilliant Moves')
    require(dict(actual) == {c: n for c, n in category_counts.items() if n and c != 'Brilliant Moves'},
            f'{account}: source category counts mismatch: {actual} / {category_counts}')
    require(category_counts['Brilliant Moves'] == count, f'{account}: all-types count mismatch')
    for row in entries:
        gid, ply = row['game_id'], row['ply']
        require(isinstance(gid, str) and gid.isdigit() and isinstance(ply, int) and ply > 0,
                f'{account}: invalid game/ply')
        item_uuid, suffix = row['game_item'].rsplit('-', 1)
        require(str(uuid.UUID(item_uuid)) == item_uuid.lower() and int(suffix) == ply,
                f'{account}/{gid}/{ply}: data-game-item UUID/ply mismatch')
        require(row['account'].lower() == account.lower(), f'{account}: row account')
        require(row['brilliant_icon'] is True and bool(row['pieces']),
                f'{account}/{gid}/{ply}: missing rendered Brilliant label/board')
        require(len(row['categories']) == len(set(row['categories'])),
                f'{account}/{gid}/{ply}: repeated category')
        link = urlparse(row['source_link'])
        require(link.netloc == 'www.chess.com' and
                link.path == f'/analysis/game/{row["game_type"]}/{gid}' and
                parse_qs(link.query).get('move') == [str(ply - 1)],
                f'{account}/{gid}/{ply}: analysis link mismatch')
    return gallery, [receipt(path), receipt(complete_path)]


def placement(classes):
    squares = {}
    for cls in classes:
        pieces = re.findall(r'\b([wb][pnbrqk])\b', cls)
        positions = re.findall(r'\bsquare-([1-8])([1-8])\b', cls)
        require(len(pieces) == len(positions) == 1 and 'piece' in cls.split(),
                f'Unrecognized piece DOM class: {cls}')
        piece, (file, rank) = pieces[0], positions[0]
        sq = chess.square(int(file) - 1, int(rank) - 1)
        require(sq not in squares, 'Overlapping rendered pieces')
        squares[sq] = chess.Piece.from_symbol(piece[1].upper() if piece[0] == 'w' else piece[1])
    board = chess.Board.empty()
    board.set_piece_map(squares)
    return board.board_fen()


def parse_game(raw):
    stream = io.StringIO(raw)
    game = chess.pgn.read_game(stream)
    require(game is not None and not game.errors, 'Invalid source PGN')
    require(chess.pgn.read_game(stream) is None, 'Multiple games in source block')
    require(all(len(node.variations) <= 1 for node in [game, *game.mainline()]),
            'Unexpected source PGN variations')
    return game


def serialized(game):
    return game.accept(chess.pgn.StringExporter(headers=True, variations=False, comments=True))


def load_bank(accounts, needed):
    records = [r for r in json.loads((ROOT / 'ARCHIVES.json').read_text())
               if r['account'].lower() in {a.lower() for a in accounts}]
    if 'nelsi' in accounts:
        records += [dict(r, path=r['file']) for r in
                    json.loads((NELSI / 'FINAL-REPORT.json').read_text())['source_files']]
    bank, receipts, duplicates = {}, [], 0
    for record in records:
        path = WORKSPACE / record['path']
        source = receipt(path)
        require(source['bytes'] == record['bytes'] and source['sha256'] == record['sha256'],
                f'Source hash/size changed: {path}')
        receipts.append(source)
        for block in re.split(r'(?=^\[Event )', path.read_text(), flags=re.M):
            match = re.search(r'^\[Link "https://www.chess.com/game/(?:live|daily)/(\d+)"\]', block, re.M)
            if not match or match[1] not in needed:
                continue
            gid = match[1]
            if gid in bank:
                require(serialized(parse_game(bank[gid][0])) == serialized(parse_game(block)),
                        f'Conflicting original PGNs for game {gid}')
                bank[gid][1].append(source['file'])
                duplicates += 1
            else:
                bank[gid] = [block, [source['file']]]
    missing = sorted(set(needed) - bank.keys())
    if missing:
        write_json('MISSING-GAMES.json', {'accounts': accounts, 'game_ids': missing})
        raise ValueError(f'Missing {len(missing)} original PGNs: {missing[:20]}')
    return bank, receipts, duplicates


def run(accounts=ACCOUNTS, publish=True):
    started = time.monotonic()
    if publish:
        require(tuple(accounts) == ACCOUNTS, 'Final export requires all five accounts')
    galleries, input_receipts, by_game = {}, [receipt(ROOT / 'ARCHIVES.json')], collections.defaultdict(list)
    for account in accounts:
        gallery, sources = load_gallery(account)
        galleries[account] = gallery
        input_receipts.extend(sources)
        for row in gallery['entries']:
            by_game[row['game_id']].append(dict(row, account=account))
    bank, source_receipts, duplicates = load_bank(accounts, by_game)
    outputs, labels, baseline, mismatches = [], [], {}, []
    per_account = {a: {'gallery_displayed': len(galleries[a]['entries']), 'labels': 0,
                       'board_matches': 0, 'games': set(), 'source_categories': {
                           c: displayed_count(v['displayed_count'])
                           for c, v in galleries[a]['category_counts'].items()}}
                   for a in accounts}
    for gid, rows in by_game.items():
        raw, source_files = bank[gid]
        game = parse_game(raw)
        targets = collections.defaultdict(list)
        for row in rows:
            targets[row['ply']].append(row)
        nodes = list(game.mainline())
        require(max(targets) <= len(nodes), f'{gid}: target beyond game end')
        original_headers = dict(game.headers)
        original_nodes = [(n.move.uci(), n.comment, n.starting_comment, set(n.nags)) for n in nodes]
        raw_clocks = re.findall(r'\[%clk [^\]]+\]', raw)
        require(not any(n.nags for n in nodes), f'{gid}: unexpected original classifications')
        board, added_comments = game.board(), {}
        for ply, node in enumerate(nodes, 1):
            require(node.move in board.legal_moves, f'{gid}/{ply}: illegal move')
            before, san, uci = board.fen(), board.san(node.move), node.move.uci()
            mover = game.headers.get('White' if board.turn == chess.WHITE else 'Black', '')
            board.push(node.move)
            comments = []
            for row in targets.get(ply, []):
                account = row['account']
                rendered = placement(row['pieces'])
                if mover.lower() != account.lower() or rendered != board.board_fen():
                    mismatches.append({'account': account, 'game_id': gid, 'ply': ply,
                                       'san': san, 'mover': mover, 'pgn_after': board.board_fen(),
                                       'gallery_after': rendered})
                    continue
                categories = sorted(c for c in row['categories'] if c != 'Brilliant Moves')
                category = '; '.join(categories) if categories else 'Uncategorized'
                comment = (f'Chess.com gallery: Brilliant (!!). Account: {account}. '
                           f'Category: {category}. Captured: {row["captured_at"]}. '
                           f'Source: {row["source_link"]}')
                comments.append(comment)
                labels.append({'account': account, 'game_id': gid, 'ply': ply, 'san': san,
                               'uci': uci, 'category': category, 'source_categories': categories,
                               'fen_before': before, 'fen_after': board.fen(),
                               'date': game.headers.get('Date'), 'game_item': row['game_item'],
                               'source_link': row['source_link'], 'gallery_url': row['gallery_url'],
                               'captured_at': row['captured_at'], 'board_verified': True,
                               'raw_pgn_files': source_files})
                stats = per_account[account]
                stats['labels'] += 1
                stats['board_matches'] += 1
                stats['games'].add(gid)
            if comments:
                added_comments[ply] = ' '.join(comments)
                node.comment = (node.comment + ' ' + added_comments[ply]).strip()
                node.nags.add(chess.pgn.NAG_BRILLIANT_MOVE)
        additions = {
            'Annotator': 'Chess.com Brilliant gallery; source labels copied, not recalculated',
            'BrilliantAccounts': '; '.join(sorted({r['account'] for r in rows})),
            'BrilliantCount': str(len(rows)), 'BrilliantCaptured': '2026-11-06'}
        require(not (set(additions) & set(original_headers)), f'{gid}: source header collision')
        game.headers.update(additions)
        baseline[gid] = {'headers': original_headers, 'nodes': original_nodes,
                         'root_comment': game.comment,
                         'clocks': raw_clocks, 'added_comments': added_comments,
                         'final_fen': board.fen(), 'initial_fen': game.board().fen()}
        outputs.append(game)
    if mismatches:
        write_json('BOARD-MISMATCHES.json', mismatches)
        raise ValueError(f'{len(mismatches)} mover/rendered-board mismatches')
    require(len(labels) == sum(len(g['entries']) for g in galleries.values()), 'Lost gallery labels')
    outputs.sort(key=lambda g: (g.headers.get('UTCDate', g.headers.get('Date', '')),
                               g.headers.get('UTCTime', ''), g.headers['Link']))
    exported = '\n\n'.join(serialized(g) for g in outputs) + '\n'
    # Exhaustively compare every game, every original move/comment/clock and label.
    expected = {(r['account'], r['game_id'], r['ply']): r for r in labels}
    labels_at = collections.defaultdict(list)
    for label in labels:
        labels_at[(label['game_id'], label['ply'])].append(label)
    seen, games_seen, clocks_checked, moves_checked = set(), set(), 0, 0
    stream = io.StringIO(exported)
    while (game := chess.pgn.read_game(stream)) is not None:
        require(not game.errors, 'Export parse error')
        gid = game.headers['Link'].rsplit('/', 1)[1]
        require(gid not in games_seen and gid in baseline, f'{gid}: duplicate/unexpected export game')
        games_seen.add(gid)
        original = baseline[gid]
        require(game.comment == original['root_comment'], f'{gid}: original root comment changed')
        require(all(game.headers[k] == v for k, v in original['headers'].items()),
                f'{gid}: original header altered')
        nodes = list(game.mainline())
        require(len(nodes) == len(original['nodes']), f'{gid}: move count changed')
        board = game.board()
        require(board.fen() == original['initial_fen'], f'{gid}: initial position changed')
        for ply, (node, old) in enumerate(zip(nodes, original['nodes']), 1):
            uci, comment, starting_comment, nags = old
            add = original['added_comments'].get(ply)
            require(node.move.uci() == uci and node.starting_comment == starting_comment,
                    f'{gid}/{ply}: original move/comment changed')
            require(node.comment == ((comment + ' ' + add).strip() if add else comment),
                    f'{gid}/{ply}: original comment changed')
            require(node.nags == (nags | {3} if add else nags), f'{gid}/{ply}: unexpected annotation')
            before, san = board.fen(), board.san(node.move)
            board.push(node.move)
            for label in labels_at.get((gid, ply), []):
                require((before, board.fen(), san, uci) ==
                        (label['fen_before'], label['fen_after'], label['san'], label['uci']),
                        f'{gid}/{ply}: annotation roundtrip changed')
                seen.add((label['account'], gid, ply))
            moves_checked += 1
        require(board.fen() == original['final_fen'], f'{gid}: final position changed')
        clocks = re.findall(r'\[%clk [^\]]+\]', serialized(game))
        require(clocks == original['clocks'], f'{gid}: raw original clock tokens changed')
        clocks_checked += len(clocks)
    require(seen == set(expected) and games_seen == set(by_game), 'Incomplete roundtrip')
    for account, stats in per_account.items():
        require(stats['gallery_displayed'] == stats['labels'] == stats['board_matches'],
                f'{account}: incomplete label validation')
        stats['games'] = len(stats['games'])
        stats['categories'] = dict(collections.Counter(r['category'] for r in labels if r['account'] == account))
    summary = {'accounts': per_account, 'labels': len(labels), 'games': len(outputs),
               'unique_annotated_plies': len(labels_at), 'board_matches': len(labels), 'unmatched': 0,
               'roundtrip_annotation_checks': len(seen), 'roundtrip_game_checks': len(games_seen),
               'roundtrip_original_move_checks': moves_checked, 'raw_clock_tokens_preserved': clocks_checked,
               'duplicate_source_games_verified': duplicates, 'source_files': source_receipts,
               'gallery_and_completion_files': input_receipts,
               'range': 'Chess.com 1 year / time=365, captured 2026-11-06',
               'date_min': min(r['date'] for r in labels), 'date_max': max(r['date'] for r in labels),
               'label_basis': 'Visible Chess.com Brilliant-gallery entries; copied without engine or model analysis',
               'unlabeled_moves': 'Unknown; only copied Brilliant labels receive $3 (!!)',
               'export_validation_seconds': round(time.monotonic() - started, 3), 'published': publish}
    if publish:
        (ROOT / PGN_NAME).write_text(exported)
        labels.sort(key=lambda r: (r['date'], r['game_id'], r['ply'], r['account']))
        write_json('brilliant-moves.json', labels)
        with (ROOT / 'brilliant-moves.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(labels[0]))
            writer.writeheader()
            writer.writerows({k: json.dumps(v) if isinstance(v, list) else v for k, v in r.items()}
                            for r in labels)
        summary['outputs'] = [receipt(ROOT / name) for name in
                              (PGN_NAME, 'brilliant-moves.json', 'brilliant-moves.csv')]
        summary['export_script'] = receipt(Path(__file__).resolve())
        write_json('EXPORT-SUMMARY.json', summary)
    return summary


if __name__ == '__main__':
    try:
        summary = run()
    except Exception as exc:
        write_json('EXPORT-ERROR.json', {'error': str(exc), 'type': type(exc).__name__})
        raise
    print(json.dumps({k: v for k, v in summary.items()
                      if k not in ('source_files', 'gallery_and_completion_files')}, indent=2))
