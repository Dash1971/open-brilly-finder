# Chess.com Brilliant gallery collection: last 12 months

**3,523 Brilliant annotations in 3,161 complete game records**, from the one-year galleries of nelsi, KNVB, hansen, GothamChess and Hikaru, captured on November 6, 2026 (Japan time).

Open **five-accounts-last-12-months-chesscom-brilliants.pgn** in a PGN reader. Every observed Brilliant is marked with standard PGN `$3` (`!!`). Its comment identifies the account, Chess.com category, source game link and capture date. Game details, all original moves, comments and clocks are preserved.

| Account | Brilliant moves | Games |
| --- | ---: | ---: |
| nelsi | 580 | 506 |
| KNVB | 929 | 849 |
| hansen | 541 | 479 |
| GothamChess | 486 | 446 |
| Hikaru | 987 | 881 |
| **Total** | **3,523** | **3,161** |

## Categories

| Source category | Brilliant moves |
| --- | ---: |
| Rook Sacrifice | 1,386 |
| Knight Sacrifice | 974 |
| Bishop Sacrifice | 720 |
| Queen Sacrifice | 360 |
| Uncategorized | 83 |

Categories are copied from Chess.com's named gallery filters. Entries present in All Types but absent from the named filters are marked **Uncategorized**; no category was invented. The Underpromotion filters displayed no entries.

## Source and verification

The date window follows each account's **1 year** gallery selection (`time=365`). The game dates in the combined file run from **November 5, 2025 through November 5, 2026**.

Each gallery entry was matched to its official public PGN using game ID and exact ply, independently cross-checked against the card's move identifier, moving account and full rendered after-position. All **3,523** displayed boards matched the PGN positions. Each game appears once in the combined file, retaining every marked move when a game contains multiple Brilliants.

The completed PGN was parsed again. All **3,161 games**, **3,523 annotations**, and **273,702 original moves and clock comments** passed the round-trip checks. There are **zero unmatched entries**.

These are **Chess.com gallery labels**, not new Game Review results or En Croissant classifications. No engine or model was used to award moves. Other moves are left unclassified; absence of an annotation does not establish a non-Brilliant judgment. The file is not a fully labeled record of every move's quality.

## Files

- `five-accounts-last-12-months-chesscom-brilliants.pgn`: the combined annotated games (about 11 MB).
- `brilliant-moves.csv` and `brilliant-moves.json`: account, category, game/move identifiers, SAN, UCI, before/after FENs and source links for all 3,523 marked moves.
- `EXPORT-SUMMARY.json`: exact counts, source hashes and exhaustive validation results.
- `KNVB/`, `hansen/`, `GothamChess/`, `Hikaru/`: captured gallery evidence and completion records. The separately completed nelsi evidence is in `../nelsi-gallery-pgn-2026-11-06/`.
- `export.py`: the study-local matching/export code, using the existing Python-chess installation.

The four additional accounts took approximately **41 minutes** end to end, including archive preparation, collection and final checks. The separately completed nelsi pilot took about 26 minutes. All collection tabs are closed. Files were written locally; nothing was uploaded or published to an external service, and no application/model/PR/deployment changed.
