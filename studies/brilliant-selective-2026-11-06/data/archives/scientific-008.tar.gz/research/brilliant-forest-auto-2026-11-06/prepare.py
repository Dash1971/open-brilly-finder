"""Freeze this study's all-corpus group folds and finite parameter search."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import hashlib,json,random,sys
from pathlib import Path
sys.path.insert(0,'<temporary-dependencies>/mute-research-plot')
import numpy as np
P=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
write=lambda f,d:f.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
assert not (P/'DATA.npz').exists()
raw=json.loads((P/'corpus/RAW-CORPUS.json').read_text())
master=json.loads((P/'corpus/REPLAY-MASTER.json').read_text())
cases=raw['cases'];base=raw['predictors'];assert len(cases)==6293 and len(base)==75
assert len({c['key'] for c in cases})==len(cases)
# Different plies of a repeated offer retain their verified, context-dependent labels.
# Same exact game/ply source disagreements were excluded by source collection.
assert all(not c.get('fit_excluded',False) for c in cases)
parent={}
def find(k):
 parent.setdefault(k,k)
 if parent[k]!=k:parent[k]=find(parent[k])
 return parent[k]
def union(a,b):
 a,b=find(a),find(b)
 if a!=b:parent[max(a,b)]=min(a,b)
positions={}
for c in cases:
 g=c['game_id'];find(g)
 for alias in c.get('aliases',[]):union(g,alias.rsplit(':',1)[0])
 pos=' '.join(c['fen_before'].split()[:4])
 if pos in positions:union(g,positions[pos])
 else:positions[pos]=g
for g in master['games']:
 if g['cohort']!='user_examples':find(g['game_id'])
assert not {'tjxdTRho','bJPg3bse'}&{c['game_id'] for c in cases}
roots=sorted({find(g) for g in parent});index={g:i for i,g in enumerate(roots)}
groups=np.array([index[find(c['game_id'])] for c in cases]);sizes=np.bincount(groups,minlength=len(roots))
loads=[0,0,0];game_loads=[0,0,0];gf={}
ordered=sorted(range(len(roots)),key=lambda g:(-int(sizes[g]),hashlib.sha256(('auto-forest-folds-v1|'+roots[g]).encode()).hexdigest()))
for g in ordered:
 f=min(range(3),key=lambda f:(loads[f],game_loads[f],f));gf[g]=f;loads[f]+=int(sizes[g]);game_loads[f]+=1
folds=np.array([gf[g] for g in groups]);wins=[c['windows'][w] for c in cases for w in ['current','previous']]
names=base+[n+'__missing' for n in base]
X=np.array([[float(w['features'][n]) if w['features'][n] is not None else np.nan for n in base]+[float(w['features'][n] is None) for n in base] for w in wins])
assert not np.isinf(X).any() and np.nanmin(X)>-1e8
truth=np.array([c['truth'] for c in cases],dtype=bool);eligible=np.array([w['eligible'] for w in wins],dtype=bool)
gates=eligible.reshape(-1,2).all(axis=1)&np.array([c['confidence_sufficient'] and not c['physical_unknown'] for c in cases])
np.savez_compressed(P/'DATA.npz',X=X,truth=truth,eligible=eligible,gates=gates,groups=groups,folds=folds)
rows=[dict(key=c['key'],game_id=c['game_id'],position=' '.join(c['fen_before'].split()[:4]),group=int(groups[i]),fold=int(folds[i]),truth=bool(truth[i]),any_eligible=bool(eligible[2*i:2*i+2].any()),old_training_member=c.get('old_training_member',False)) for i,c in enumerate(cases)]
write(P/'CASES.json',dict(features=names,cases=rows))
fitpos=[{r['position'] for r in rows if r['fold']!=f and r['any_eligible']} for f in range(3)]
exclusions=[]
for g in master['games']:
 if g['cohort']=='user_examples':g['model_fold']='fullfit';continue
 f=gf[index[find(g['game_id'])]];g['model_fold']=f;keep=[]
 for ply in g['scored_plies']:
  pk=' '.join(g['nodes'][ply-1]['fen'].split()[:4])
  if pk in fitpos[f]:
   e=dict(ply=ply,key=g['game_id']+':'+str(ply),reason='before_position_matches_other_fold_training_case');g['scoring_exclusions'].append(e);exclusions.append(e)
  else:keep.append(ply)
 g['scored_plies']=keep
write(P/'REPLAY-MASTER.json',master)
write(P/'SPLIT.json',dict(case_count=len(cases),positive_cases=int(truth.sum()),negative_cases=int((~truth).sum()),original848_present=sum(c.get('old_training_member',False) for c in cases),groups=len(roots),fold_cases=loads,folds=[dict(fold=f,positive=int(truth[folds==f].sum()),negative=int((~truth[folds==f]).sum()),games=sum(g['model_fold']==f for g in master['games'])) for f in range(3)],initial_gate_positive_ceiling=int((truth&gates).sum()),full_game_position_exclusions=exclusions,repeat_label_aliases_retained=raw['quarantine_keys'],interpretation='All observed corpus is development. Whole games and identical fitting positions stay together. Selection uses OOF labels, so later native OOF replay is development CV, not an independent test.'))
configs=[]
def add(c):
 if c not in configs:configs.append(c)
for depth in [8,10,12,16]:
 for leaf in [2,4]:
  for mtry in [12,24]:add(dict(depth=depth,minleaf=leaf,mtry=mtry,cost=1.,fraction=1.,criterion='gini',splitter='best',row_min=1,max_leaves=None))
rng=random.Random(2026110621)
while len(configs)<96:
 add(dict(depth=rng.choice([4,6,8,10,12,16,24]),minleaf=rng.choice([2,4,8,16,32]),mtry=rng.choice([6,12,24,50,150]),cost=rng.choice([.5,1.,2.,5.,10.]),fraction=rng.choice([.6,.8,1.]),criterion=rng.choice(['gini','entropy']),splitter=rng.choice(['best','best','random']),row_min=rng.choice([1,1,4]),max_leaves=rng.choice([None,None,256,1024])))
refs=[dict(id='reference_a',kind='custom',depth=10,minleaf=4,mtry=12,cost=1.,fraction=1.,trees=64),dict(id='reference_b',kind='custom',depth=12,minleaf=4,mtry=12,cost=1.,fraction=1.,trees=64)]
manifest=dict(recipes=[dict(id=f'r{i:03}',kind='compiled',**c) for i,c in enumerate(configs)],references=refs,cutoffs=sorted(set([round(.05*i,3) for i in range(1,10)]+[round(x,3) for x in np.arange(.50,.991,.01)]+[5/6])),scout_trees=32,promoted_trees=128,promote_recipes=12,workers=4,versions=dict(sklearn='1.7.2'),seed=2026110621,data_sha256=sha(P/'DATA.npz'),cases_sha256=sha(P/'CASES.json'),raw_sha256=sha(P/'corpus/RAW-CORPUS.json'),split_sha256=sha(P/'SPLIT.json'),limits=dict(worker_wall_seconds=1200,rss_mib=768,stop_critical=True),method='Compiled CART proposes topology. Native-float64 rerouting, case-distinct postpruning and unweighted bootstrap-window leaf means define exported model. Fixed75+75features and native safety gates; no NN.',promotion='Nondominated layers and normalized coordinate crowding; bestlayer/bestcrowding/recipeID.12distinctrecipes. First32trees preserved when appending96.',shortlist='Saveallpoints. RegionFP<=2*min(reference_aFP,reference_bFP)atfixed.8. Low-errorpoint=maxTPwithFP<=referenceFP. Recallpoint=maxTPwithFP<=2xref. Knee=normalizedTPgain-normalizedFPincrease among strictlyinteriornondominatedpoints. Deduplicate model/cutoff; fewerthan3allowed. Notowneracceptanceoruniversaloptimum.',no_pr_changes=True)
manifest['initial_gate_ceiling_note']='3469/3857=89.94% of positives pass both initial windows. Native confirmation may recover additional cases; parameters do not change gates.'
manifest['repeat_label_note']='Two different verified plies of samecanonicalboard/move retained in samegamefold; sourcequarantineindexdiagnosticonly. Possible omittedhistory/referencevariability, notrelabeled.'
manifest['native_validation']='Use the exact3foldexcluded models for all benchmarkgames. Refit fullweights onlyforownerexamplesandfreshaccountlater. OOFrecipe+cutoffselection makesreplaydevelopmentCV, notindependentvalidation.'
write(P/'MANIFEST.json',manifest)
print(json.dumps(dict(cases=len(cases),positives=int(truth.sum()),negatives=int((~truth).sum()),fold_cases=loads,recipes=len(configs),initial_gate_positive_ceiling=int((truth&gates).sum()),replay_position_exclusions=len(exclusions))))
