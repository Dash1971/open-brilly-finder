// Bounded auto-study replay template: copy to bundles/fold0|fold1|fold2|fullfit/worker.mts.
// Bundle beside that entry. Root replaces inactive finalist imports with unused production aliases.
// Native scheduling/search kernels below are retained from the six-variant increment replay.
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {FullGameClassifier as ProductionScheduler,reviewSource} from '../../native/ui/analyse/src/noSweatFullReview.ts';
import {FullGameClassifier as PR285Scheduler} from '../../native/ui/analyse/src/noSweatFullReview285.ts';
import * as production from '../../native/ui/analyse/src/noSweatClassify.ts';
import * as reference_a from './models/reference_a/ui/analyse/src/noSweatClassify.ts';
import * as reference_b from './models/reference_b/ui/analyse/src/noSweatClassify.ts';
import * as finalist_a from './models/finalist_a/ui/analyse/src/noSweatClassify.ts';
import * as finalist_b from './models/finalist_b/ui/analyse/src/noSweatClassify.ts';
import * as finalist_c from './models/finalist_c/ui/analyse/src/noSweatClassify.ts';
import {SearchSnapshots} from '../../native/ui/analyse/src/noSweatSnapshots.ts';
import {position,legalUcis,terminalScore} from '../../native/ui/analyse/src/noSweatCore.ts';

const root=new URL('../../',import.meta.url),assets=new URL('assets/',root),batch=Number(process.argv[2]);
if(!Number.isInteger(batch)||batch<0||batch>6)throw Error('Unknown replay batch');
const sha=(bytes:any)=>createHash('sha256').update(bytes).digest('hex'),hash=(x:any)=>sha(JSON.stringify(x));
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),clone=<T,>(x:T):T=>structuredClone(x);
const require=(ok:any,message:string)=>{if(!ok)throw Error(message)},need=require;
const profile={depth:12,movetime:500},oldModel='44704ac06378d3f671a4eed959e21959f759c0437c71af1f9119d1081293c0b7';
const bundleName=fileURLToPath(new URL('.',import.meta.url)).split(/[\\/]+/).filter(Boolean).at(-1)!;
const modelFold=batch===6?'fullfit':String(Math.floor(batch/2)),ownerDiagnostic=batch===6;
need(bundleName===(ownerDiagnostic?'fullfit':`fold${modelFold}`),'Batch and static model bundle differ');
const finalistsPinBytes=readFileSync(new URL('FINALISTS-PIN.json',root)),finalistsPin=JSON.parse(finalistsPinBytes.toString());
const references=finalistsPin.refs??finalistsPin.references,finalists=finalistsPin.finalists;
need(Array.isArray(references)&&references.length===2&&Array.isArray(finalists)&&finalists.length<=3,'Invalid finalist/reference pin arrays');
need(same([...references.map((s:any)=>s.id)].sort(),['reference_a','reference_b']),'Both fixed reference recipes are required');
const allowedFinalists=['finalist_a','finalist_b','finalist_c'],specs=[...references,...finalists];
need(finalists.every((s:any)=>allowedFinalists.includes(s.id))&&new Set(specs.map((s:any)=>s.id)).size===specs.length,'Invalid/duplicate learned variant ID');
const apiModules:any={production,pr285:production,reference_a,reference_b,finalist_a,finalist_b,finalist_c};
const variantNames=['production','pr285','reference_a','reference_b',...allowedFinalists.filter(id=>finalists.some((s:any)=>s.id===id))];
const variantModels:any={production:{model_sha256:oldModel,cutoff:5/6},pr285:{model_sha256:oldModel,cutoff:5/6}};
for(const spec of specs){
 const selected=ownerDiagnostic?spec.fullfit:spec.folds?.[modelFold];
 need(selected&&/^[a-f0-9]{64}$/.test(selected.model_sha256)&&Number.isFinite(spec.cutoff)&&spec.cutoff>0&&spec.cutoff<=1,'Invalid model/cutoff pin for '+spec.id);
 if(spec.id.startsWith('reference_'))need(spec.cutoff===0.8,'Reference cutoff changed');
 variantModels[spec.id]={model_sha256:selected.model_sha256,cutoff:spec.cutoff,model_fold:modelFold};
}
const pinsBytes=readFileSync(new URL('BUILD-PINS.json',root)),pins=JSON.parse(pinsBytes.toString());
for(const[path,expected]of Object.entries(pins.files))need(sha(readFileSync(new URL(path,root)))===expected,'Build pin changed: '+path);
need(pins.files['native/ui/analyse/src/noSweatBrilliantForestModel.json']===oldModel,'Production model changed');
for(const spec of specs)need(pins.files[`bundles/${bundleName}/models/${spec.id}/ui/analyse/src/noSweatBrilliantForestModel.json`]===variantModels[spec.id].model_sha256,'Static model pin mismatch: '+spec.id);
need(pins.files['assets/sf_19_smallnet.wasm']==='7e6629d0e1226a0d20c9c2c71c69dd3dccbe260a25f0053d3e5e4e5acea77fbc'&&pins.files['assets/nn-61e7af4bb97d.nnue']==='61e7af4bb97d51eeeb25d322916f86513b5cd3a827ce189c98c6e31946f99e5b','Engine changed');
const inputBytes=readFileSync(new URL(`INPUT-${batch}.json`,root)),input=JSON.parse(inputBytes.toString()),games=input.games;
need(sha(inputBytes)===pins.inputs[String(batch)],'Input changed');
need(Array.isArray(games)&&new Set(games.map((g:any)=>g.game_id)).size===games.length,'Duplicate/invalid game input');
for(const game of games){need(String(game.model_fold)===modelFold,'Game model_fold differs from the batch fold');const scored=game.scored_plies??[];need(Array.isArray(scored)&&new Set(scored).size===scored.length&&scored.every((p:any)=>Number.isInteger(p)&&p>0&&p<game.nodes.length),'Invalid scored-ply mask');}
const dest=new URL(`results-${batch}/`,root);mkdirSync(dest,{recursive:true});
const freeze={batch,scope:ownerDiagnostic?'Full-fit owner diagnostic; excluded from cross-validation scoring':'Frozen fold-trained full native Fast replay',profile,threads:1,hashMB:16,inputSHA:sha(inputBytes),buildPinsSHA:sha(pinsBytes),
 workerSourceSHA:sha(readFileSync(new URL('worker.mts',root))),entrySourceSHA:sha(readFileSync(new URL(`bundles/${bundleName}/worker.mts`,root))),bundleSHA:sha(readFileSync(new URL(import.meta.url))),runtime:{node:process.version,platform:process.platform,arch:process.arch},
 model_fold:modelFold,owner_diagnostic:ownerDiagnostic,variant_names:variantNames,variant_models:variantModels,finalists_pin_sha256:sha(finalistsPinBytes)};
const freezeSHA=hash(freeze),freezeURL=new URL('FREEZE.json',dest);need(!existsSync(freezeURL),'Existing batch must be inspected; no restart');
writeFileSync(freezeURL,JSON.stringify({configuration:freeze,started:new Date().toISOString()},null,2)+'\n');
const started=Date.now();let gameStarted=Date.now(),pressureAt=0;
const guard=()=>{need(Date.now()-started<=1800000&&Date.now()-gameStarted<=180000&&process.memoryUsage().rss<=768*1024**2,'30minute/3minutegame/768MiBcap');
if(Date.now()-pressureAt>2000){pressureAt=Date.now();if(process.platform==='darwin')need(execFileSync('/usr/sbin/sysctl',['-n','kern.memorystatus_vm_pressure_level'],{encoding:'utf8'}).trim()!=='4','Criticalmemorypressure');else need(Number(readFileSync('/proc/meminfo','utf8').match(/^MemAvailable:\s+(\d+)/m)?.[1])>=524288,'Lowmemory')}};
const terminalReview=(fen:string)=>{const score=terminalScore(fen);return score?{current:{depth:99,lines:[{...score,moves:[]}]},terminal:true}:undefined};
type Group={key:string;fens:string[];depth:number;time:number;reviews:any[];reviewSHA:string;source_ply?:number;source_search_indices?:Array<number|null>};
const groupKey=(fens:string[],depth:number,time:number)=>hash({fens,depth,time});
const withQuality=(review:any)=>({...clone(review),quality:`${reviewSource}:${profile.depth}:${profile.movetime}`});
const classificationKey=(input:any)=>hash({positions:input.positions,reviews:input.reviews,move:input.move,confirmation:input.confirmation??null,policy:'mute-brilliant-v5'});

// Reconstruct all source requests, including unlogged terminal calls, before any classification.
function sourceGroups(game:any,original:any){
 require(original.complete&&original.game_id===game.game_id&&same(original.profile,profile),'Wrong/incomplete original result');
 require(same(original.targets,game.source_targets??game.targets),'Original target metadata changed');
 require(original.initial.length===game.nodes.length,'Missing original initial reviews');
 let cursor=0;const searches=original.searches,groups:Group[]=[],cache=new Map<string,Group>();
 for(let i=0;i<game.nodes.length;i++){
  const node=game.nodes[i],terminal=terminalReview(node.fen);
  if(terminal)require(same(original.initial[i],terminal),'Original terminal initial review changed');
  else{const search=searches[cursor++];require(search&&search.fen===node.fen&&search.depth===12&&search.time===500&&same(search.review,original.initial[i]),'Original initial search identity mismatch at '+i)}
 }
 const initialSearchCount=cursor;let budgetUsed=0;const first=new Map<number,any>(),decisionCache=new Map<string,any>();
 const cacheDecision=(decision:any,confirmation?:any[])=>{
  const begin=Math.max(0,decision.ply-2),input:any={positions:game.nodes.slice(begin,decision.ply+1).map((n:any)=>n.fen),
   reviews:original.initial.slice(begin,decision.ply+1).map(withQuality),move:game.nodes[decision.ply].uci,policy:'mute-brilliant-v5'};
  if(confirmation)input.confirmation=confirmation.map(withQuality);
  const inputSHA=classificationKey(input);require(!decisionCache.has(inputSHA)||same(decisionCache.get(inputSHA).result,decision.result),'Conflicting exact original classification inputs');
  decisionCache.set(inputSHA,{ply:decision.ply,confirmation:!!decision.confirmation,result:decision.result,inputSHA});
 };
 for(const decision of original.decisions){
  require(Number.isInteger(decision.ply)&&decision.ply>0&&decision.ply<game.nodes.length,'Invalid original decision ply');
  if(!decision.confirmation){require(!first.has(decision.ply),'Duplicate original first decision');first.set(decision.ply,decision);cacheDecision(decision);continue}
  const initial=first.get(decision.ply);require(initial,'Confirmation lacks original decision');
  const provisional=initial.result.provisional??initial.result.symbol;
  require((provisional==='!'||provisional==='!!')&&initial.result.withheld,'Unexpected source confirmation reason');
  const start=provisional==='!'&&decision.ply>1?decision.ply-2:decision.ply-1;
  const fens=game.nodes.slice(start,decision.ply+1).map((n:any)=>n.fen),reviews:any[]=[],indices:Array<number|null>=[];
  for(const fen of fens){const terminal=terminalReview(fen);if(terminal){reviews.push(terminal);indices.push(null)}
   else{const index=cursor++,search=searches[index];require(search&&search.fen===fen&&search.depth===14&&search.time===500,'Original confirmation search mismatch');
    require(search.reset===(indices.every(i=>i===null)),'Original confirmation session reset mismatch');reviews.push(search.review);indices.push(index)}}
  budgetUsed+=fens.length;require(budgetUsed<=6,'Original confirmation allowance exceeded');
  const key=groupKey(fens,14,500),group={key,fens,depth:14,time:500,reviews,reviewSHA:hash(reviews),source_ply:decision.ply,source_search_indices:indices};
  require(!cache.has(key)||same(cache.get(key)!.reviews,reviews),'Conflicting exact source confirmation groups');
  cache.set(key,group);groups.push(group);cacheDecision(decision,reviews);
 }
 require(cursor===searches.length,'Unconsumed original search records');
 require(first.size===game.nodes.length-1,'Missing original per-move classification');
 return {groups,cache,decisionCache,initialSearchCount,budgetUsed};
}

let engine:any,listener=(s:string)=>{},engineSession:symbol|undefined;
const command=(cmd:string,end:string)=>new Promise<void>((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('UCI startup timeout')),10000);listener=s=>{if(s===end){clearTimeout(timer);resolve()}};engine.uci(cmd)});
async function ensureEngine(){
 if(engine)return;guard();const factory=(await import(new URL('sf_19_smallnet.js',assets).href)).default;
 engine=await factory({wasmMemory:new WebAssembly.Memory({initial:1536,maximum:32767,shared:true}),locateFile:(f:string)=>fileURLToPath(new URL(f,assets)),mainScriptUrlOrBlob:fileURLToPath(new URL('sf_19_smallnet.js',assets))});
 engine.setNnueBuffer(readFileSync(new URL('nn-61e7af4bb97d.nnue',assets)),0);engine.listen=(s:string)=>listener(s);
 await command('uci','uciok');for(const cmd of ['setoption name Threads value 1','setoption name Hash value 16','setoption name UCI_Chess960 value false','setoption name UCI_AnalyseMode value true'])engine.uci(cmd);await command('isready','readyok');
}
async function searchOrdered(fens:string[],depth:number,time:number,session:symbol){
 const reviews:any[]=[],searches:any[]=[];
 for(const fen of fens){guard();const terminal=terminalScore(fen);if(terminal){const review={current:{depth:99,lines:[{...terminal,moves:[]}]},terminal:true};reviews.push(review);searches.push({fen,depth,time,terminal:true,review});continue}
  await ensureEngine();const legal=new Set(legalUcis(fen)),count=Math.min(2,legal.size),snapshots=new SearchSnapshots(legal,count,position(fen).turn==='white');
  const reset=engineSession!==session;if(reset){engine.uci('ucinewgame');engine.uci('setoption name Clear Hash')}engineSession=session;engine.uci('setoption name MultiPV value '+count);await command('isready','readyok');
  const start=Date.now(),review=await new Promise<any>((resolve,reject)=>{const timer=setTimeout(()=>{engine.uci('stop');reject(Error('UCI search timeout'))},time+15000);
   listener=s=>{if(s.startsWith('info '))snapshots.add(s);else if(s.startsWith('bestmove')){clearTimeout(timer);if(!snapshots.completed){reject(Error('Incomplete MultiPV'));return}resolve({current:snapshots.completed,previous:snapshots.previous})}};
   engine.uci('position fen '+fen);engine.uci(`go depth ${depth} movetime ${time}`)});
  reviews.push(review);searches.push({fen,depth,time,reset,elapsed:Date.now()-start,review});guard();
 }
 return {reviews,searches};
}

function readReceipt(path:string,expected:string){const bytes=readFileSync(new URL(path,root));need(sha(bytes)===expected,'Evidencehashchanged');return JSON.parse(bytes.toString())}
function seedAdditional(game:any,record:any,cache:Map<string,any>,decisions:Map<string,any>,variantFilter=['production','pr285']){
 need(same(record.initial?.length,game.nodes.length),'Cached initial review count mismatch');
 for(const g of [...(record.cached_confirmation_groups??[]),...(record.confirmation_groups??[]),...(record.source_confirmation_groups??[]),...(record.pr285?.new_groups??[])]){
  need(g.key===hash({fens:g.fens,depth:g.depth,time:g.time})&&g.reviewSHA===hash(g.reviews),'Invalidcachedgroup');
  need(g.depth===14&&g.time===500&&g.fens.length>=2&&g.fens.length<=3&&g.reviews.length===g.fens.length,'Cached confirmation profile changed');
  need(game.nodes.some((_n:any,start:number)=>same(game.nodes.slice(start,start+g.fens.length).map((n:any)=>n.fen),g.fens)),'Cached group is not an exact current-game node sequence');
  if(cache.has(g.key))need(same(cache.get(g.key).reviews,g.reviews),'Cachedgroupconflict');else cache.set(g.key,g);
 }
 const variants=record.variants?Object.entries(record.variants).filter(([name])=>variantFilter.includes(name)):record.pr285&&variantFilter.includes('pr285')?[['pr285',record.pr285]]:[];
 for(const[name,v]of variants as any){for(const d of v.decisions){
  let confirmation:any;
  if(d.confirmation){const request=v.confirmation_requests.find((r:any)=>r.ply===d.ply);need(request&&cache.has(request.key),'Missingcacheddecisiongroup');
   const group=cache.get(request.key);need(same(request.fens,group.fens)&&request.depth===group.depth&&request.time===group.time&&request.reviewSHA===hash(group.reviews),'Cached request/group identity mismatch');confirmation=group.reviews.map(withQuality)}
  const begin=Math.max(0,d.ply-2),full:any={positions:game.nodes.slice(begin,d.ply+1).map((n:any)=>n.fen),reviews:record.initial.slice(begin,d.ply+1).map(withQuality),move:game.nodes[d.ply].uci};
  if(confirmation)full.confirmation=confirmation;const key=classificationKey(full);need(key===d.inputSHA,'Cacheddecisioninputmismatch');
  if(decisions.has(key))need(same(decisions.get(key),d.result),'Cacheddecisionconflict');else decisions.set(key,d.result);
 }}
}
function verifyCompleteNodes(game:any,record:any,label:string){
 need(record.complete&&record.game_id===game.game_id&&same(record.profile,profile),label+' identity/profile mismatch');
 need(record.initial?.length===game.nodes.length,label+' initial review count mismatch');
 if(record.initial_sha256)need(record.initial_sha256===hash(record.initial),label+' initial review hash mismatch');
 if(record.move_outcomes){
  need(record.move_outcomes.length===game.nodes.length-1,label+' missing complete move identities');
  for(let ply=1;ply<game.nodes.length;ply++){const old=record.move_outcomes[ply-1];need(old.ply===ply&&old.fen_before===game.nodes[ply-1].fen&&old.fen_after===game.nodes[ply].fen&&old.uci===game.nodes[ply].uci&&old.san===game.nodes[ply].san,label+' full-game node identity mismatch')}
 }
}
async function evaluateGame(game:any){
 need(game.original_result_path&&game.original_result_sha256,'Missing pinned original cached evidence');
 const record=readReceipt(game.original_result_path,game.original_result_sha256);verifyCompleteNodes(game,record,'Original');
 let source:any,initialEvidence:any;
 if(record.searches&&Array.isArray(record.outcomes)){source=sourceGroups(game,record);initialEvidence={reviews:record.initial,searches:[],cached:true}}
 else{let k=0;const searches=record.initial_searches??record.searches;
  if(searches?.length){for(let i=0;i<game.nodes.length;i++){const terminal=terminalReview(game.nodes[i].fen);if(terminal){need(same(record.initial[i],terminal),'Terminal evidence changed');const logged=searches[k];if(logged?.fen===game.nodes[i].fen&&logged.terminal===true){need(logged.depth===12&&logged.time===500&&same(logged.review,terminal),'Logged terminal search identity changed');k++}}else{const search=searches[k++];need(search&&search.fen===game.nodes[i].fen&&search.depth===12&&search.time===500&&same(search.review,record.initial[i]),'Initial evidence identity changed')}}need(k===searches.length,'Unconsumed original initial searches')}
  else need(record.initial_sha256===hash(record.initial)&&Array.isArray(record.move_outcomes),'Cached-only original requires complete node and initial-hash receipts');
  initialEvidence={reviews:record.initial,searches:[],cached:true};
 }
 const initial=initialEvidence.reviews,confirmationCache=new Map<string,any>(),variants:any={},createdGroups:any[]=[];
 const forestID=(name:string)=>hash({cache_family:name==='production'||name==='pr285'?'production':'fold_trained',model_sha256:variantModels[name].model_sha256,cutoff:variantModels[name].cutoff});
 const classificationCaches=new Map<string,Map<string,any>>(),materialCaches=new Map<string,Map<string,number>>();
 for(const name of variantNames){const id=forestID(name);if(!classificationCaches.has(id))classificationCaches.set(id,new Map());if(!materialCaches.has(id))materialCaches.set(id,new Map())}
 const oldClassificationCache=classificationCaches.get(forestID('production'))!;
 if(source){for(const[k,g]of source.cache)confirmationCache.set(k,g);for(const[k,d]of source.decisionCache)oldClassificationCache.set(k,d.result)}
 if(record.variants)seedAdditional(game,record,confirmationCache,oldClassificationCache,['production','pr285']);
 let paired:any;if(game.paired_result_path){paired=readReceipt(game.paired_result_path,game.paired_result_sha256);need(paired.complete&&paired.original_result_sha256===game.original_result_sha256,'Invalid paired receipt');seedAdditional(game,{...paired,initial},confirmationCache,oldClassificationCache,['production','pr285'])}
 const replayReceipts:any[]=[];
 const legacyModels:any={old8a:'8a299c942bf71ce2f88df18377210778579f280c07dcc72f9c23c862386453d2','502':'502008557853c5c624acf87c7e2bc20d86a0f8941fb33c212ea4cefb92654d7a'};
 for(const descriptor of game.cached_replays??[]){
  const kind=descriptor.kind??({forest_8a:'old8a',forest_502:'502'} as any)[descriptor.reference_name]??Object.keys(legacyModels).find(id=>legacyModels[id]===descriptor.candidate_model_sha256);
  need(legacyModels[kind],'Unknown optional replay kind');
  if(descriptor.candidate_model_sha256)need(descriptor.candidate_model_sha256===legacyModels[kind],'Optional replay descriptor model mismatch');
  if(descriptor.candidate_cutoff!==undefined)need(descriptor.candidate_cutoff===0.8,'Optional replay descriptor cutoff mismatch');
  const cached=readReceipt(descriptor.result_path,descriptor.result_sha256),cachedFreeze=readReceipt(descriptor.freeze_path,descriptor.freeze_sha256);
  verifyCompleteNodes(game,cached,'Optional replay');need(Array.isArray(cached.move_outcomes),'Optional replay lacks complete move identities');
  need(cached.freeze_sha256===hash(cachedFreeze.configuration),'Optional replay/freeze mismatch');
  need(cachedFreeze.configuration.baseline_model_sha256===oldModel,'Optional replay production forest mismatch');
  need(cachedFreeze.configuration.candidate_model_sha256===legacyModels[kind]&&cachedFreeze.configuration.candidate_cutoff===0.8,'Optional replay legacy model identity mismatch');
  need(same(cached.initial,initial),'Optional replay initial evidence differs');
  if(descriptor.initial_sha256)need(descriptor.initial_sha256===hash(cached.initial),'Optional replay descriptor initial hash mismatch');
  if(descriptor.available_variants)need(Array.isArray(descriptor.available_variants)&&descriptor.available_variants.every((name:string)=>cached.variants?.[name]),'Optional replay descriptor variant missing');
  // Legacy model classifications are deliberately NOT seeded into any new fold-trained cache.
  seedAdditional(game,cached,confirmationCache,oldClassificationCache,['production','pr285']);
  replayReceipts.push({descriptor:{...descriptor,kind},record:cached});
 }
 const preexistingGroups=[...confirmationCache.values()];
 for(const name of variantNames){
  const productionContext=name==='production';
  const Scheduler=productionContext?ProductionScheduler:PR285Scheduler,api=apiModules[name];
  const materialCache=materialCaches.get(forestID(name))!;
  const material=(fen:string)=>{if(!materialCache.has(fen))materialCache.set(fen,api.naiveMaterial(fen));return materialCache.get(fen)!};
  let initialIndex=0,currentPly=0,active:any,confirmationCost=0,cachedClassifications=0,freshClassifications=0;
  const decisions:any[]=[],requests:any[]=[],provisional=new Map<number,string>();
  const scheduler=new Scheduler({search:async(fen:string,signal:AbortSignal,depth:number,time:number,session?:symbol)=>{
   guard();need(!signal.aborted,'Cancelled');
   if(initialIndex<game.nodes.length){const i=initialIndex++;need(fen===game.nodes[i].fen&&depth===12&&time===500,'Initial scheduler request mismatch');return clone(initial[i])}
   if(!active||active.session!==session){
    need(!active||active.index===active.group.fens.length,'Interrupted confirmation group');need(session&&depth===14&&time===500,'Unexpected confirmation profile');
    const start=productionContext?(provisional.get(currentPly)==='!'&&currentPly>1?currentPly-2:currentPly-1):Math.max(0,currentPly-2);
    const fens=game.nodes.slice(start,currentPly+1).map((n:any)=>n.fen);need(fens.length>=2&&fens.length<=3&&fen===fens[0],'Confirmation window mismatch');
    confirmationCost+=fens.length;need(confirmationCost<=6,'Variant native confirmation allowance exceeded');
    const key=hash({fens,depth,time});let group=confirmationCache.get(key),origin='shared_exact_group';
    if(!group){const fresh=await searchOrdered(fens,depth,time,session!);group={key,fens,depth,time,reviews:fresh.reviews,reviewSHA:hash(fresh.reviews),searches:fresh.searches,created_for:name,created_at_ply:currentPly};confirmationCache.set(key,group);createdGroups.push(group);origin='fresh_group'}
    requests.push({ply:currentPly,key,fens,depth,time,origin,reviewSHA:group.reviewSHA});active={session,group,index:0};
   }
   const i=active.index++;need(active.group.fens[i]===fen&&active.group.depth===depth&&active.group.time===time,'Confirmation request order mismatch');return clone(active.group.reviews[i]);
  },classify:async(input:any)=>{
   guard();need(input.move===game.nodes[currentPly].uci&&same(input.positions,game.nodes.slice(Math.max(0,currentPly-2),currentPly+1).map((n:any)=>n.fen)),'Classifier identity mismatch');
   const full={...input,policy:'mute-brilliant-v5'},inputSHA=classificationKey(full);let result:any,origin:string;
   const modelCache=classificationCaches.get(forestID(name))!;
   if(modelCache.has(inputSHA)){result=clone(modelCache.get(inputSHA));origin='exact_model_and_input_cache';cachedClassifications++}
   else{result=api.classify(full,material);origin='native_fresh_classification';freshClassifications++;modelCache.set(inputSHA,clone(result))}
   guard();if(!input.confirmation)provisional.set(currentPly,result.provisional??result.symbol);
   decisions.push({ply:currentPly,confirmation:!!input.confirmation,inputSHA,origin,result});return result;
  }});
  const result=await scheduler.run(game.nodes,new AbortController().signal,()=>true,(done:number,_total:number,phase?:string)=>{if(!phase)currentPly=done+1},profile);
  need(initialIndex===game.nodes.length&&(!active||active.index===active.group.fens.length),'Incomplete variant evidence consumption');
  need(decisions.filter(d=>!d.confirmation).length===game.nodes.length-1,'Missing variant move decisions');
  variants[name]={model:variantModels[name],classification_cache_id:forestID(name),outcomes:[...result],decisions,confirmation_requests:requests,confirmation_cost:confirmationCost,cached_classification_count:cachedClassifications,fresh_classification_count:freshClassifications};
 }
 const maps:any={},last:any={};for(const name of variantNames){maps[name]=new Map(variants[name].outcomes);last[name]=new Map(variants[name].decisions.map((d:any)=>[d.ply,d.result]))}
 if(record&&Array.isArray(record.outcomes))need(same(variants.production.outcomes,record.outcomes),'Productionroundtripchanged');
 if(record?.variants){need(same(variants.production.outcomes,record.variants.production.outcomes),'Magnusproductionroundtripchanged');need(same(variants.pr285.outcomes,record.variants.pr285.outcomes),'MagnusPR285roundtripchanged')}
 if(paired)need(same(variants.pr285.outcomes,paired.outcomes.pr285),'PR285roundtripchanged');
 const plain=(ds:any[])=>ds.map(({ply,confirmation,inputSHA,result}:any)=>({ply,confirmation,inputSHA,result}));
 const replayRoundtrips:any[]=[];
 for(const{descriptor,record:cached}of replayReceipts){
  const checked:string[]=[];
  for(const name of ['production','pr285'])if(cached.variants?.[name]){
   need(same(variants[name].outcomes,cached.variants[name].outcomes),'Optional replay outcome roundtrip changed: '+name);
   need(same(plain(variants[name].decisions),plain(cached.variants[name].decisions)),'Optional replay decision roundtrip changed: '+name);checked.push(name);
  }
  replayRoundtrips.push({...descriptor,checked_variants:checked,legacy_classifications_reused:false});
 }
 const labels=new Set(game.targets.map((t:any)=>t.ply)),moves:any[]=[],scored=new Set<number>(game.scored_plies??[]);
 for(let ply=1;ply<game.nodes.length;ply++){
  const before=game.nodes[ply-1].fen,mover=position(before).turn==='white'?game.white:game.black;
  const outcome:any={};for(const name of variantNames)outcome[name]=maps[name].has(ply)?maps[name].get(ply):null;
  moves.push({game_id:game.game_id,ply,uci:game.nodes[ply].uci,san:game.nodes[ply].san,fen_before:before,fen_after:game.nodes[ply].fen,position_key:before.split(/\s+/).slice(0,4).join(' '),
   mover,scored_player:!ownerDiagnostic&&scored.has(ply),input_scored_player:scored.has(ply),cohort:game.cohort,owner_diagnostic:ownerDiagnostic,model_fold:modelFold,gallery_positive:labels.has(ply),...outcome,changed:variantNames.some(name=>outcome[name]!==outcome.production),
   classification_results:Object.fromEntries(variantNames.map(name=>[name,last[name].get(ply)]))});
 }
 return {variants,outcomes:Object.fromEntries(Object.entries(variants).map(([name,value]:any)=>[name,value.outcomes])),initial,initial_sha256:hash(initial),initial_searches:initialEvidence.searches,
  confirmation_groups:createdGroups,cached_confirmation_groups:preexistingGroups,optional_replay_roundtrips:replayRoundtrips,variant_models:variantModels,model_fold:modelFold,owner_diagnostic:ownerDiagnostic,
  input_game_metadata:Object.fromEntries(Object.entries(game).filter(([key])=>key!=='nodes')),original_result_sha256:game.original_result_sha256,move_outcomes:moves,changed_cases:moves.filter(m=>m.changed),changed_scored_cases:moves.filter(m=>m.changed&&m.scored_player),
  fresh_engine_searches:initialEvidence.searches.filter(s=>!s.terminal).length+createdGroups.reduce((n,g)=>n+g.searches.filter((s:any)=>!s.terminal).length,0)};
}

let done=0,failure:any,searches=0;
try{
 for(const game of games){
  const output=new URL(game.game_id+'.json',dest),gameSHA=hash(game);
  if(existsSync(output)){const saved=JSON.parse(readFileSync(output,'utf8'));need(saved.complete&&saved.input_game_sha256===gameSHA&&saved.freeze_sha256===freezeSHA,'Existing assessment checkpoint requires inspection');done++;searches+=saved.fresh_engine_searches;continue}
  gameStarted=Date.now();guard();const result=await evaluateGame(game);
  writeFileSync(output,JSON.stringify({complete:true,game_id:game.game_id,input_game_sha256:gameSHA,freeze_sha256:freezeSHA,elapsed_ms:Date.now()-gameStarted,profile,cohort:game.cohort,scoring_enabled:!ownerDiagnostic,scored_plies:ownerDiagnostic?[]:game.scored_plies??[],input_scored_plies:game.scored_plies??[],scoring_exclusions:game.scoring_exclusions??[],expected_user_moves:game.expected_user_moves??[],targets:game.targets,...result})+'\n');
  done++;searches+=result.fresh_engine_searches;writeFileSync(new URL('PROGRESS.json',dest),JSON.stringify({done,total:games.length,searches,elapsed_ms:Date.now()-started,rss:process.memoryUsage().rss,at:new Date().toISOString()})+'\n');
  if(done%10===0||done===games.length)console.log(JSON.stringify({batch,done,total:games.length,searches,seconds:Math.round((Date.now()-started)/1000)}));
 }
}catch(error){failure=String(error);console.error(failure)}finally{engine?.uci('quit')}
writeFileSync(new URL('STATE.json',dest),JSON.stringify({complete:!failure&&done===games.length,failure,done,total:games.length,searches,elapsed_ms:Date.now()-started,finished:new Date().toISOString()},null,2)+'\n');process.exit(failure?1:0);
