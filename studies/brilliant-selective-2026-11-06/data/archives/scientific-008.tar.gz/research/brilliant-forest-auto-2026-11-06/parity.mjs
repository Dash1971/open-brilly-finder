import {readFileSync,writeFileSync} from 'node:fs';
const root=new URL('./',import.meta.url),rows=JSON.parse(readFileSync(new URL('PARITY-INPUT.json',root),'utf8')),result={};
for(const id of ['reference_a','reference_b','r009']){
 const models=[0,1,2].map(f=>JSON.parse(readFileSync(new URL(`models/${id}/fold-${f}.json`,root),'utf8')));
 result[id]=rows.map(row=>row.vectors.map(vector=>{
  const m=models[row.fold];let total=0;
  for(const tree of m.trees){let node=tree;while(node.kind==='split'){const v=vector[node.feature_index];node=v===null||Number(v)<=node.threshold?node.left:node.right}total+=node.raw_p}
  return total/m.trees.length;
 }));
}
writeFileSync(new URL('PARITY-NATIVE.json',root),JSON.stringify(result)+'\n');
console.log(JSON.stringify({cases:rows.length,windows:rows.length*2,weight_families:3,engine_calls:0}));
