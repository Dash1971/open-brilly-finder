"""Deterministic study-only successive-halving and tradeoff shortlist."""
import hashlib,json,math,sys
from pathlib import Path
P=Path(__file__).resolve().parent
M=json.loads((P/'MANIFEST.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
phase=sys.argv[1];assert phase in ['promote','finalists']
assert sha(Path(__file__))==json.loads((P/'CODE-PINS.json').read_text())['choose.py']
assert sha(P/'MANIFEST.json')==json.loads((P/'CODE-PINS.json').read_text())['MANIFEST.json']
source='scout' if phase=='promote' else 'extend'
for part in range(4):assert json.loads((P/f'{source}-worker-{part}.json').read_text())['complete']
recipes=M['recipes'] if phase=='promote' else json.loads((P/'PROMOTE.json').read_text())['recipes']
points=[]
for r in recipes:
 points+=json.loads((P/source/r['id']/'points.json').read_text())
valid=[p for p in points if p['TP']>0]
assert valid,'No positive attainable point; do not manufacture winner'
coords=sorted({(r['TP'],r['FP']) for r in valid},key=lambda c:(c[1],-c[0]))
tps=sorted({p[0] for p in coords},reverse=True);rank={v:i+1 for i,v in enumerate(tps)};bit=[-1]*(len(tps)+1);layers={}
for tp,fp in coords:
 i=rank[tp];best=-1
 while i:best=max(best,bit[i]);i-=i&-i
 layer=best+1;layers[(tp,fp)]=layer;i=rank[tp]
 while i<len(bit):bit[i]=max(bit[i],layer);i+=i&-i
crowd={}
for layer in sorted(set(layers.values())):
 items=[c for c in coords if layers[c]==layer];dist={c:0. for c in items}
 for axis in [0,1]:
  ordered=sorted(items,key=lambda c:c[axis]);dist[ordered[0]]=dist[ordered[-1]]=math.inf
  span=ordered[-1][axis]-ordered[0][axis]
  if span:
   for i in range(1,len(ordered)-1):dist[ordered[i]]+=(ordered[i+1][axis]-ordered[i-1][axis])/span
 crowd.update(dist)
for point in points:
 key=(point['TP'],point['FP']);point['pareto_layer']=layers.get(key);point['crowding']=('endpoint' if math.isinf(crowd.get(key,0)) else crowd.get(key,0))
write(P/(source.upper()+'-ALL-POINTS.json'),points)
if phase=='promote':
 scores=[]
 for r in recipes:
  own=[p for p in valid if p['recipe']==r['id']]
  if not own:continue
  layer=min(layers[(p['TP'],p['FP'])] for p in own);distance=max(crowd[(p['TP'],p['FP'])] for p in own if layers[(p['TP'],p['FP'])]==layer)
  scores.append((layer,-distance,r['id']))
 order=[rid for _,_,rid in sorted(scores)][:12];lookup={r['id']:r for r in recipes}
 write(P/'PROMOTE.json',dict(recipes=[lookup[r] for r in order],ranking=[dict(recipe=rid,layer=l,crowding='endpoint' if math.isinf(c) else -c) for l,c,rid in sorted(scores)],all_points_sha256=sha(P/'SCOUT-ALL-POINTS.json'),no_native_test_results_used=True))
 print(json.dumps(dict(promoted=order,recipes_scored=len(recipes),operating_points=len(points))))
else:
 reference_points={r['id']:next(p for p in json.loads((P/'scout'/r['id']/'points.json').read_text()) if p['cutoff']==.8) for r in M['references']}
 budget=min(r['FP'] for r in reference_points.values());limit=2*budget
 # Keep one deterministic representative for each equivalent TP/FP coordinate.
 unique={}
 for r in sorted(valid,key=lambda r:(-r['cutoff'],r['recipe'])):unique.setdefault((r['TP'],r['FP']),r)
 frontier=[r for k,r in unique.items() if layers[k]==0 and r['FP']<=limit]
 eligible=[r for r in unique.values() if r['FP']<=limit]
 assert eligible,'No candidate within frozen low-error search region'
 tie=lambda r:(r['TP'],-r['FP'],r['cutoff'],r['recipe'])
 low= max((r for r in eligible if r['FP']<=budget),key=tie,default=None)
 high=max(eligible,key=tie)
 chosen=[]
 if low:chosen.append(('low_error',low))
 if not chosen or high['recipe']!=low['recipe'] or high['cutoff']!=low['cutoff']:chosen.append(('more_brilliants',high))
 if low and high['TP']>low['TP'] and high['FP']>low['FP']:
  interior=[r for r in frontier if low['TP']<r['TP']<high['TP'] and low['FP']<r['FP']<high['FP']]
  if interior:
   knee=max(interior,key=lambda r:((r['TP']-low['TP'])/(high['TP']-low['TP'])-(r['FP']-low['FP'])/(high['FP']-low['FP']),-r['FP'],r['cutoff'],-int(r['recipe'][1:])))
   if not any(knee['recipe']==r['recipe'] and knee['cutoff']==r['cutoff'] for _,r in chosen):chosen.append(('middle',knee))
 lookup={r['id']:r for r in recipes};jobs=[dict(config=r,trees=64) for r in M['references']]
 for rid in sorted({r['recipe'] for _,r in chosen}):jobs.append(dict(config=lookup[rid],trees=128))
 write(P/'FINALISTS.json',dict(finalists=[dict(id='finalist_'+chr(97+i),role=role,point=r,config=lookup[r['recipe']]) for i,(role,r) in enumerate(chosen)],model_jobs=jobs,reference_points=reference_points,reference_fp_budget=budget,search_region_max_fp=limit,search_region_is_not_owner_acceptance_rule=True,all_points_sha256=sha(P/'EXTEND-ALL-POINTS.json'),native_feedback_used=False,training_and_cutoffs_frozen_before_native=True))
 print(json.dumps(dict(finalists=[dict(role=role,**r) for role,r in chosen],references=reference_points,search_region_max_fp=limit)))
