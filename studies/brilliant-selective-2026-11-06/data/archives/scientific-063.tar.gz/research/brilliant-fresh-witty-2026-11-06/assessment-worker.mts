// Fresh Witty_Alien three-variant assessment. Initial evidence is shared; model results stay separate.
import {readFileSync,writeFileSync,existsSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {FullGameClassifier as ProductionScheduler} from './native/ui/analyse/src/noSweatFullReview.ts';
import {FullGameClassifier as PR285Scheduler} from './native/ui/analyse/src/noSweatFullReview285.ts';
import * as production from './native/ui/analyse/src/noSweatClassify.ts';
import * as selective from './selective-native/ui/analyse/src/noSweatClassify.ts';
import {SearchSnapshots} from './native/ui/analyse/src/noSweatSnapshots.ts';
import {position,legalUcis,terminalScore} from './native/ui/analyse/src/noSweatCore.ts';

const root=new URL('./',import.meta.url),assets=new URL('assets/',root),batch=Number(process.argv[2]);
if(!Number.isInteger(batch)||batch<0||batch>7)throw Error('Unknown assessment batch');
const sha=(bytes:any)=>createHash('sha256').update(bytes).digest('hex'),hash=(x:any)=>sha(JSON.stringify(x));
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),clone=<T,>(x:T):T=>structuredClone(x);
const need=(ok:any,message:string)=>{if(!ok)throw Error(message)};
const profile={depth:12,movetime:500},oldModel='44704ac06378d3f671a4eed959e21959f759c0437c71af1f9119d1081293c0b7';
const sourcePinsBytes=readFileSync(new URL('SOURCE-PINS.json',root)),sourcePins=JSON.parse(sourcePinsBytes.toString());
for(const[path,expected]of Object.entries(sourcePins.files))need(sha(readFileSync(new URL(path,root)))===expected,'Source pin changed: '+path);
const candidatePinBytes=readFileSync(new URL('CANDIDATE-PIN.json',root)),candidatePin=JSON.parse(candidatePinBytes.toString());
need(candidatePin.model_sha256==='1a7150fbe52f440922d94d3ae2af337383d63f370b52d0379aeee22d581d056c'&&candidatePin.cutoff===0.83,'Frozen selective model/cutoff changed');
need(sourcePins.files['selective-native/ui/analyse/src/noSweatBrilliantForestModel.json']===candidatePin.model_sha256,'Selective model pin mismatch');
need(sourcePins.files['native/ui/analyse/src/noSweatBrilliantForestModel.json']===oldModel,'Production model changed');
need(sourcePins.files['native/ui/analyse/src/noSweatFullReview.ts']==='813f2f308cd2a42f683c4271a396795b2abfc786cb3f9667e4ff0a15c66395b3','Production scheduler changed');
need(sourcePins.files['native/ui/analyse/src/noSweatFullReview285.ts']==='410cc155f5b3c3a2311f7c60de86c209b4dc732bff0eabb107cf3f5b69d45ee1','PR285 scheduler changed');
let cutoffChanges=0;
for(const[path,expected]of Object.entries(sourcePins.files))if(path.startsWith('native/')&&!path.endsWith('/noSweatBrilliantForestModel.json')){
 const paired=path.replace(/^native\//,'selective-native/');
 if(path.endsWith('/noSweatClassify.ts')||path.endsWith('/noSweatBrilliantForest.ts')){const text=readFileSync(new URL(path,root),'utf8');cutoffChanges+=(text.match(/>= 5 \/ 6/g)??[]).length;need(readFileSync(new URL(paired,root),'utf8')===text.replace(/>= 5 \/ 6/g,'>= 0.83'),'Selective changed code beyond frozen cutoffs: '+path)}
 else need(sourcePins.files[paired]===expected,'Selective changed runtime code: '+path);
}
need(cutoffChanges===3,'Unexpected number of frozen cutoff changes');
need(sourcePins.files['assets/sf_19_smallnet.wasm']==='7e6629d0e1226a0d20c9c2c71c69dd3dccbe260a25f0053d3e5e4e5acea77fbc'&&sourcePins.files['assets/nn-61e7af4bb97d.nnue']==='61e7af4bb97d51eeeb25d322916f86513b5cd3a827ce189c98c6e31946f99e5b','Engine/network changed');
if(process.argv.includes('--source-preflight')){console.log(JSON.stringify({source_preflight:'PASS',variants:['production','pr285','selective'],candidate_model_sha256:candidatePin.model_sha256,cutoff:candidatePin.cutoff,engine_launched:false}));process.exit(0)}
need(process.argv.includes('--root-go'),'Root browser-closed GO flag required before any engine execution');
const pinsBytes=readFileSync(new URL('BUILD-PINS.json',root)),pins=JSON.parse(pinsBytes.toString());
need(sha(sourcePinsBytes)===pins.source_pins_sha256,'Source-pins receipt changed');
need(sha(readFileSync(new URL(import.meta.url)))===pins.worker_bundle_sha256,'Pinned worker bundle changed');
const exclusionBytes=readFileSync(new URL('EXCLUSIONS.json',root)),exclusions=JSON.parse(exclusionBytes.toString());
need(sha(exclusionBytes)===pins.exclusions_sha256,'Exclusion receipt changed');
need(Array.isArray(exclusions.training_game_ids)&&Array.isArray(exclusions.canonical_before_keys),'Missing frozen exclusions');
const trainingIDs=new Set(exclusions.training_game_ids),trainingPositions=new Set(exclusions.canonical_before_keys);
const inputBytes=readFileSync(new URL(`INPUT-${batch}.json`,root)),input=JSON.parse(inputBytes.toString()),games=input.games;
need(sha(inputBytes)===pins.input_sha256_by_batch[String(batch)],'Assessment batch input changed');
need(input.assessment_only===true&&input.account==='Witty_Alien'&&input.exclusion_sha256===sha(exclusionBytes),'Wrong assessment scope/exclusion binding');
need(new Set(games.map((g:any)=>g.game_id)).size===games.length,'Duplicate assessment games');
for(const game of games){
 need(!trainingIDs.has(game.game_id),'Known game leaked into fresh assessment');
 need([game.white,game.black].some((name:string)=>name.toLowerCase()==='witty_alien'),'Account absent from game');
 for(let i=0;i<game.nodes.length;i++){const node=game.nodes[i];need(node.ply===i&&Object.keys(node).every(k=>['ply','fen','uci','san'].includes(k)),'Imported node annotations/evals/glyphs or index mismatch');}
 const expected:number[]=[];
 for(let ply=1;ply<game.nodes.length;ply++){const before=game.nodes[ply-1].fen,mover=position(before).turn==='white'?game.white:game.black;if(mover.toLowerCase()==='witty_alien'&&!trainingPositions.has(before.split(/\s+/).slice(0,4).join(' ')))expected.push(ply)}
 const scored=game.scored_plies;need(Array.isArray(scored)&&same(scored,expected),'Own-move/overlap scoring mask changed');
 for(const target of game.targets){need(target.ply>0&&target.ply<game.nodes.length&&(!target.uci||target.uci===game.nodes[target.ply].uci)&&(!target.san||target.san===game.nodes[target.ply].san),'Gallery target node identity mismatch');const mover=position(game.nodes[target.ply-1].fen).turn==='white'?game.white:game.black;need(mover.toLowerCase()==='witty_alien','Gallery target belongs to opponent');}
}
const dest=new URL(`assessment-${batch}/`,root);mkdirSync(dest,{recursive:true});
const freeze={batch,scope:'Fresh Witty_Alien gallery-positive-game assessment only',productionRevision:'462af8bff61bfba183aaf9fa87bdb250e8fa447f',pr285Head:'6d2b44a079c8e8eacc313615ce5cb37bbe4ffef4',
 profile,threads:1,hashMB:16,runtime:{node:process.version,platform:process.platform,arch:process.arch},inputSHA:sha(inputBytes),
 bundleSHA:sha(readFileSync(new URL(import.meta.url))),workerSourceSHA:sha(readFileSync(new URL('assessment-worker.mts',root))),buildPinsSHA:sha(pinsBytes),
 oldModelSHA:oldModel,candidateModelSHA:candidatePin.model_sha256,candidateCutoff:candidatePin.cutoff,candidatePinSHA:sha(candidatePinBytes),exclusionsSHA:sha(exclusionBytes),sourcePinsSHA:sha(sourcePinsBytes),
 sourceHashes:sourcePins.files,limits:{process_ms:1800000,game_ms:180000,rss_bytes:768*1024**2}};
const freezeSHA=hash(freeze),freezeURL=new URL('FREEZE.json',dest);
if(existsSync(freezeURL))need(same(JSON.parse(readFileSync(freezeURL,'utf8')).configuration,freeze),'Frozen assessment run changed');
else writeFileSync(freezeURL,JSON.stringify({configuration:freeze,started:new Date().toISOString()},null,2)+'\n');
const started=Date.now();let gameStarted=Date.now(),pressureAt=0;
const guard=()=>{
 need(Date.now()-started<=1800000&&Date.now()-gameStarted<=180000&&process.memoryUsage().rss<=768*1024**2,'30-minute/three-minute-game/768MiB guard');
 if(Date.now()-pressureAt>2000){pressureAt=Date.now();if(process.platform==='darwin')need(execFileSync('/usr/sbin/sysctl',['-n','kern.memorystatus_vm_pressure_level'],{encoding:'utf8'}).trim()!=='4','Critical memory pressure');else{const available=Number(readFileSync('/proc/meminfo','utf8').match(/^MemAvailable:\s+(\d+)/m)?.[1]);need(available>=524288,'Linux available memory below 512MiB')}}
};
let engine:any,listener=(s:string)=>{},engineSession:symbol|undefined;
const command=(cmd:string,end:string)=>new Promise<void>((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('UCI startup timeout')),10000);listener=s=>{if(s===end){clearTimeout(timer);resolve()}};engine.uci(cmd)});
async function ensureEngine(){
 if(engine)return;guard();const factory=(await import(new URL('sf_19_smallnet.js',assets).href)).default;
 engine=await factory({wasmMemory:new WebAssembly.Memory({initial:1536,maximum:32767,shared:true}),locateFile:(f:string)=>fileURLToPath(new URL(f,assets)),mainScriptUrlOrBlob:fileURLToPath(new URL('sf_19_smallnet.js',assets))});
 engine.setNnueBuffer(readFileSync(new URL('nn-61e7af4bb97d.nnue',assets)),0);engine.listen=(s:string)=>listener(s);
 await command('uci','uciok');for(const cmd of ['setoption name Threads value 1','setoption name Hash value 16','setoption name UCI_Chess960 value false','setoption name UCI_AnalyseMode value true'])engine.uci(cmd);await command('isready','readyok');
}
async function searchOrdered(fens:string[],depth:number,time:number,session:symbol){
 const reviews:any[]=[],searches:any[]=[];
 for(const fen of fens){guard();const terminal=terminalScore(fen);if(terminal){const review={current:{depth:99,lines:[{...terminal,moves:[]}]},terminal:true};reviews.push(review);searches.push({fen,depth,time,terminal:true,review});continue}
  await ensureEngine();const legal=new Set(legalUcis(fen)),count=Math.min(2,legal.size),snapshots=new SearchSnapshots(legal,count,position(fen).turn==='white');
  const reset=engineSession!==session;if(reset){engine.uci('ucinewgame');engine.uci('setoption name Clear Hash')}engineSession=session;engine.uci('setoption name MultiPV value '+count);await command('isready','readyok');
  const start=Date.now(),review=await new Promise<any>((resolve,reject)=>{const timer=setTimeout(()=>{engine.uci('stop');reject(Error('UCI search timeout'))},time+15000);
   listener=s=>{if(s.startsWith('info '))snapshots.add(s);else if(s.startsWith('bestmove')){clearTimeout(timer);if(!snapshots.completed){reject(Error('Incomplete MultiPV'));return}resolve({current:snapshots.completed,previous:snapshots.previous})}};
   engine.uci('position fen '+fen);engine.uci(`go depth ${depth} movetime ${time}`)});
  reviews.push(review);searches.push({fen,depth,time,reset,elapsed:Date.now()-start,review});guard();
 }
 return {reviews,searches};
}
const classificationKey=(input:any)=>hash({positions:input.positions,reviews:input.reviews,move:input.move,confirmation:input.confirmation??null,policy:'mute-brilliant-v5'});

async function evaluateGame(game:any){
 const initialEvidence=await searchOrdered(game.nodes.map((n:any)=>n.fen),12,500,Symbol()),initial=initialEvidence.reviews;
 const confirmationCache=new Map<string,any>(),oldClassificationCache=new Map<string,any>(),variants:any={},createdGroups:any[]=[];
 const materialCaches={old:new Map<string,number>(),candidate:new Map<string,number>()};
 for(const name of ['production','pr285','selective']as const){
  const Scheduler=name==='production'?ProductionScheduler:PR285Scheduler,api=name==='selective'?selective:production;
  const materialCache=name==='selective'?materialCaches.candidate:materialCaches.old;
  const material=(fen:string)=>{if(!materialCache.has(fen))materialCache.set(fen,api.naiveMaterial(fen));return materialCache.get(fen)!};
  let initialIndex=0,currentPly=0,active:any,confirmationCost=0,cachedClassifications=0,freshClassifications=0;
  const decisions:any[]=[],requests:any[]=[],provisional=new Map<number,string>();
  const scheduler=new Scheduler({search:async(fen:string,signal:AbortSignal,depth:number,time:number,session?:symbol)=>{
   guard();need(!signal.aborted,'Cancelled');
   if(initialIndex<game.nodes.length){const i=initialIndex++;need(fen===game.nodes[i].fen&&depth===12&&time===500,'Initial scheduler request mismatch');return clone(initial[i])}
   if(!active||active.session!==session){
    need(!active||active.index===active.group.fens.length,'Interrupted confirmation group');need(session&&depth===14&&time===500,'Unexpected confirmation profile');
    const start=name==='production'?(provisional.get(currentPly)==='!'&&currentPly>1?currentPly-2:currentPly-1):Math.max(0,currentPly-2);
    const fens=game.nodes.slice(start,currentPly+1).map((n:any)=>n.fen);need(fens.length>=2&&fens.length<=3&&fen===fens[0],'Confirmation window mismatch');
    confirmationCost+=fens.length;need(confirmationCost<=6,'Variant native confirmation allowance exceeded');
    const key=hash({fens,depth,time});let group=confirmationCache.get(key),origin='shared_exact_group';
    if(!group){const fresh=await searchOrdered(fens,depth,time,session!);group={key,fens,depth,time,reviews:fresh.reviews,reviewSHA:hash(fresh.reviews),searches:fresh.searches,created_for:name,created_at_ply:currentPly};confirmationCache.set(key,group);createdGroups.push(group);origin='fresh_group'}
    requests.push({ply:currentPly,key,fens,depth,time,origin,reviewSHA:group.reviewSHA});active={session,group,index:0};
   }
   const i=active.index++;need(active.group.fens[i]===fen&&active.group.depth===depth&&active.group.time===time,'Confirmation request order mismatch');return clone(active.group.reviews[i]);
  },classify:async(input:any)=>{
   guard();need(input.move===game.nodes[currentPly].uci&&same(input.positions,game.nodes.slice(Math.max(0,currentPly-2),currentPly+1).map((n:any)=>n.fen)),'Classifier identity mismatch');
   const full={...input,policy:'mute-brilliant-v5'},inputSHA=classificationKey(full);let result:any,origin:string;
   if(name!=='selective'&&oldClassificationCache.has(inputSHA)){result=clone(oldClassificationCache.get(inputSHA));origin='old_model_exact_input_cache';cachedClassifications++}
   else{result=api.classify(full,material);origin=name==='selective'?'selective_fresh_classification':'production_fresh_classification';freshClassifications++;if(name!=='selective')oldClassificationCache.set(inputSHA,clone(result))}
   guard();if(!input.confirmation)provisional.set(currentPly,result.provisional??result.symbol);
   decisions.push({ply:currentPly,confirmation:!!input.confirmation,inputSHA,origin,result});return result;
  }});
  const result=await scheduler.run(game.nodes,new AbortController().signal,()=>true,(done:number,_total:number,phase?:string)=>{if(!phase)currentPly=done+1},profile);
  need(initialIndex===game.nodes.length&&(!active||active.index===active.group.fens.length),'Incomplete variant evidence consumption');
  need(decisions.filter(d=>!d.confirmation).length===game.nodes.length-1,'Missing variant move decisions');
  variants[name]={outcomes:[...result],decisions,confirmation_requests:requests,confirmation_cost:confirmationCost,cached_classification_count:cachedClassifications,fresh_classification_count:freshClassifications};
 }
 const maps:any={},last:any={};for(const name of ['production','pr285','selective']){maps[name]=new Map(variants[name].outcomes);last[name]=new Map(variants[name].decisions.map((d:any)=>[d.ply,d.result]))}
 const labels=new Set(game.targets.map((t:any)=>t.ply)),moves:any[]=[],scored=new Set<number>(game.scored_plies);
 for(let ply=1;ply<game.nodes.length;ply++){
  const before=game.nodes[ply-1].fen,mover=position(before).turn==='white'?game.white:game.black;
  const outcome:any={};for(const name of ['production','pr285','selective'])outcome[name]=maps[name].has(ply)?maps[name].get(ply):null;
  moves.push({game_id:game.game_id,ply,uci:game.nodes[ply].uci,san:game.nodes[ply].san,fen_before:before,fen_after:game.nodes[ply].fen,position_key:before.split(/\s+/).slice(0,4).join(' '),
   mover,account_own_move:mover.toLowerCase()==='witty_alien',scored_player:scored.has(ply),position_overlap_excluded:mover.toLowerCase()==='witty_alien'&&trainingPositions.has(before.split(/\s+/).slice(0,4).join(' ')),gallery_positive:labels.has(ply),...outcome,changed:outcome.production!==outcome.pr285||outcome.pr285!==outcome.selective,
   classification_results:{production:last.production.get(ply),pr285:last.pr285.get(ply),selective:last.selective.get(ply)}});
 }
 return {variants,outcomes:Object.fromEntries(Object.entries(variants).map(([name,value]:any)=>[name,value.outcomes])),initial,initial_sha256:hash(initial),initial_searches:initialEvidence.searches,
  confirmation_groups:createdGroups,move_outcomes:moves,changed_cases:moves.filter(m=>m.changed),changed_scored_cases:moves.filter(m=>m.changed&&m.scored_player),
  fresh_engine_searches:initialEvidence.searches.filter(s=>!s.terminal).length+createdGroups.reduce((n,g)=>n+g.searches.filter((s:any)=>!s.terminal).length,0)};
}

let done=0,failure:any,searches=0;
try{
 for(const game of games){
  const output=new URL(game.game_id+'.json',dest),gameSHA=hash(game);
  if(existsSync(output)){const saved=JSON.parse(readFileSync(output,'utf8'));need(saved.complete&&saved.input_game_sha256===gameSHA&&saved.freeze_sha256===freezeSHA,'Existing assessment checkpoint requires inspection');done++;searches+=saved.fresh_engine_searches;continue}
  gameStarted=Date.now();guard();const result=await evaluateGame(game);
  writeFileSync(output,JSON.stringify({complete:true,game_id:game.game_id,input_game_sha256:gameSHA,freeze_sha256:freezeSHA,elapsed_ms:Date.now()-gameStarted,profile,account:input.account,scored_plies:game.scored_plies,scoring_exclusions:game.scoring_exclusions??[],input_game_metadata:Object.fromEntries(Object.entries(game).filter(([key])=>key!=='nodes')),targets:game.targets,...result})+'\n');
  done++;searches+=result.fresh_engine_searches;writeFileSync(new URL('PROGRESS.json',dest),JSON.stringify({done,total:games.length,searches,elapsed_ms:Date.now()-started,rss:process.memoryUsage().rss,at:new Date().toISOString()})+'\n');
  if(done%5===0||done===games.length)console.log(JSON.stringify({batch,done,total:games.length,searches,seconds:Math.round((Date.now()-started)/1000)}));
 }
}catch(error){failure=String(error);console.error(failure)}finally{engine?.uci('quit')}
writeFileSync(new URL('STATE.json',dest),JSON.stringify({complete:!failure&&done===games.length,failure,done,total:games.length,searches,elapsed_ms:Date.now()-started,finished:new Date().toISOString()},null,2)+'\n');process.exit(failure?1:0);
