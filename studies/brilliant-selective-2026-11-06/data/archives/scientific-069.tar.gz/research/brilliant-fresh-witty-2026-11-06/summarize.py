"""Bounded fresh-account recount adapted from the existing external summarizer.

No inference: read frozen inputs and worker symbol maps. Missing or partly written
results produce progress only; integrity mismatches fail rather than being skipped.
"""
import collections
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NAMES = ['production', 'pr285', 'selective']
MODEL = '1a7150fbe52f440922d94d3ae2af337383d63f370b52d0379aeee22d581d056c'
OLD_MODEL = '44704ac06378d3f671a4eed959e21959f759c0437c71af1f9119d1081293c0b7'


def read(path):
    return json.loads(path.read_text())


def optional(path):
    try:
        return read(path)
    except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError):
        return None


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def objsha(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def empty():
    return {n: collections.Counter() for n in NAMES}


def metrics(table):
    result = {}
    for name, counter in table.items():
        c = {k: counter[k] for k in ['TP', 'FN', 'FP', 'TN']}
        p, n = c['TP'] + c['FN'], c['FP'] + c['TN']
        result[name] = dict(**c, positives=p, negatives=n,
            recognition_percent=100*c['TP']/p if p else None,
            false_positive_rate_percent=100*c['FP']/n if n else None)
    return result


def main():
    build = optional(ROOT/'BUILD-PINS.json')
    if not build:
        report = dict(complete=False, reason='Waiting for frozen BUILD-PINS and inputs; no scores read.')
        write(ROOT/'PROGRESS-SUMMARY.json', report)
        print(json.dumps(report))
        return
    sources = read(ROOT/'SOURCE-PINS.json')
    assert sha(ROOT/'SOURCE-PINS.json') == build['source_pins_sha256']
    for path, digest in sources['files'].items():
        assert sha(ROOT/path) == digest, 'Source pin changed: ' + path
    assert sha(ROOT/'assessment-worker.mjs') == build['worker_bundle_sha256']
    candidate = read(ROOT/'CANDIDATE-PIN.json')
    assert candidate['model_sha256'] == MODEL and candidate['cutoff'] == .83
    assert sha(ROOT/'selective-native/ui/analyse/src/noSweatBrilliantForestModel.json') == MODEL
    assert sha(ROOT/'native/ui/analyse/src/noSweatBrilliantForestModel.json') == OLD_MODEL
    assert sha(ROOT/'EXCLUSIONS.json') == build['exclusions_sha256']
    exclusion = read(ROOT/'EXCLUSIONS.json')
    training_ids, positions = set(exclusion['training_game_ids']), set(exclusion['canonical_before_keys'])
    assert len(training_ids) == 3475 and len(positions) == 6189
    inputs, expected, expected_totals = [], set(), collections.Counter()
    for batch in range(8):
        path = ROOT/f'INPUT-{batch}.json'
        assert sha(path) == build['input_sha256_by_batch'][str(batch)]
        inp = read(path)
        assert inp['assessment_only'] and inp['account'] == 'Witty_Alien'
        assert inp['exclusion_sha256'] == sha(ROOT/'EXCLUSIONS.json')
        inputs.append(inp)
        for game in inp['games']:
            gid = game['game_id']
            assert gid not in expected and gid not in training_ids
            expected.add(gid)
            own = [i for i in range(1, len(game['nodes'])) if
                   (game['white'] if game['nodes'][i-1]['fen'].split()[1] == 'w' else game['black']).lower() == 'witty_alien']
            novel = [i for i in own if ' '.join(game['nodes'][i-1]['fen'].split()[:4]) not in positions]
            assert game['scored_plies'] == novel
            labels = {t['ply'] for t in game['targets']}
            assert len(labels) == len(game['targets']) and labels <= set(own)
            expected_totals.update(games=1, all_moves=len(game['nodes'])-1, own_moves=len(own),
                primary_moves=len(novel), primary_positives=len(labels & set(novel)),
                unmasked_positives=len(labels), excluded_moves=len(own)-len(novel))
    assert len(expected) == 200
    tables = {scope: empty() for scope in ['primary', 'unmasked', 'excluded']}
    pairs = {scope: {n: collections.Counter() for n in ['production', 'pr285']} for scope in tables}
    seen, missing, states, failures, rows, games = set(), [], [], [], [], {}
    checked = collections.Counter()
    for batch, inp in enumerate(inputs):
        folder = ROOT/f'assessment-{batch}'
        state = optional(folder/'STATE.json')
        states.append(dict(batch=batch, state=state))
        if state:
            if state.get('failure'):
                failures.append(dict(batch=batch, failure=state['failure']))
            if state.get('complete'):
                assert not state.get('failure') and state['done'] == state['total'] == len(inp['games'])
                assert state['elapsed_ms'] <= 1800000
        freeze_receipt = optional(folder/'FREEZE.json')
        if not freeze_receipt:
            missing.extend(g['game_id'] for g in inp['games'])
            continue
        freeze = freeze_receipt['configuration']
        assert freeze['batch'] == batch and freeze['profile'] == {'depth': 12, 'movetime': 500}
        assert freeze['candidateModelSHA'] == MODEL and freeze['candidateCutoff'] == .83 and freeze['oldModelSHA'] == OLD_MODEL
        for key, path in [('inputSHA', f'INPUT-{batch}.json'), ('bundleSHA', 'assessment-worker.mjs'),
                          ('workerSourceSHA', 'assessment-worker.mts'), ('buildPinsSHA', 'BUILD-PINS.json'),
                          ('candidatePinSHA', 'CANDIDATE-PIN.json'), ('exclusionsSHA', 'EXCLUSIONS.json'),
                          ('sourcePinsSHA', 'SOURCE-PINS.json')]:
            assert freeze[key] == sha(ROOT/path)
        assert freeze['sourceHashes'] == sources['files']
        expected_batch = {g['game_id'] for g in inp['games']}
        actual = {f.stem for f in folder.glob('*.json') if f.stem.isdigit()}
        assert actual <= expected_batch, 'Unknown or wrong-batch game result'
        batch_searches, batch_done = 0, 0
        for game in inp['games']:
            gid = game['game_id']
            d = optional(folder/f'{gid}.json')
            if not d or not d.get('complete'):
                missing.append(gid)
                continue
            assert gid not in seen and d['game_id'] == gid
            assert d['input_game_sha256'] == objsha(game) and d['freeze_sha256'] == objsha(freeze)
            assert d['profile'] == freeze['profile'] and d['account'] == 'Witty_Alien'
            assert d['scored_plies'] == game['scored_plies'] and d['targets'] == game['targets']
            assert d['scoring_exclusions'] == game.get('scoring_exclusions', [])
            assert d['elapsed_ms'] <= 180000 and set(d['variants']) == set(NAMES)
            assert len(d['initial']) == len(game['nodes']) and objsha(d['initial']) == d['initial_sha256']
            assert len(d['initial_searches']) == len(game['nodes'])
            for node, search, review in zip(game['nodes'], d['initial_searches'], d['initial']):
                assert search['fen'] == node['fen'] and search['depth'] == 12 and search['time'] == 500
                assert search['review'] == review
            groups = {g['key']: g for g in d['confirmation_groups']}
            assert len(groups) == len(d['confirmation_groups'])
            for key, group in groups.items():
                assert key == objsha({k: group[k] for k in ['fens', 'depth', 'time']})
                assert group['depth'] == 14 and group['time'] == 500 and group['reviewSHA'] == objsha(group['reviews'])
            maps = {}
            for name, variant in d['variants'].items():
                maps[name] = dict(variant['outcomes'])
                assert len(maps[name]) == len(variant['outcomes'])
                assert variant['confirmation_cost'] == sum(len(q['fens']) for q in variant['confirmation_requests']) <= 6
                for q in variant['confirmation_requests']:
                    group = groups[q['key']]
                    assert all(q[k] == group[k] for k in ['fens', 'depth', 'time', 'reviewSHA'])
                assert sum(not x['confirmation'] for x in variant['decisions']) == len(game['nodes'])-1
                if name == 'selective':
                    assert variant['cached_classification_count'] == 0
                    assert all(x['origin'] == 'selective_fresh_classification' for x in variant['decisions'])
                checked['variant_budget_checks'] += 1
            fresh = sum(not s.get('terminal', False) for s in d['initial_searches']) + sum(
                not s.get('terminal', False) for group in groups.values() for s in group['searches'])
            assert fresh == d['fresh_engine_searches']
            batch_searches += fresh
            checked.update(games=1, fresh_engine_searches=fresh, all_moves=len(game['nodes'])-1)
            seen.add(gid)
            batch_done += 1
            gt = {scope: empty() for scope in tables}
            labels, scored = {t['ply'] for t in game['targets']}, set(game['scored_plies'])
            assert len(d['move_outcomes']) == len(game['nodes'])-1
            for ply, row in enumerate(d['move_outcomes'], 1):
                node, before = game['nodes'][ply], game['nodes'][ply-1]['fen']
                who = game['white'] if before.split()[1] == 'w' else game['black']
                own, truth = who.lower() == 'witty_alien', ply in labels
                assert row['ply'] == ply and row['uci'] == node['uci'] and row['san'] == node['san']
                assert row['fen_before'] == before and row['fen_after'] == node['fen'] and row['mover'] == who
                assert row['scored_player'] == (ply in scored) and row['account_own_move'] == own and row['gallery_positive'] == truth
                assert row['position_overlap_excluded'] == (own and ' '.join(before.split()[:4]) in positions)
                for name in NAMES:
                    assert row[name] == maps[name].get(ply)
                if not own:
                    continue
                scopes = ['unmasked', 'primary' if ply in scored else 'excluded']
                predicted = {name: maps[name].get(ply) == '!!' for name in NAMES}
                checked['own_moves'] += 1
                checked['primary_moves' if ply in scored else 'excluded_moves'] += 1
                rows.append(dict(game_id=gid, ply=ply, san=node['san'], uci=node['uci'], truth=truth,
                    primary=ply in scored, **{n: maps[n].get(ply) for n in NAMES}))
                for scope in scopes:
                    for name, award in predicted.items():
                        key = 'TP' if truth and award else 'FN' if truth else 'FP' if award else 'TN'
                        tables[scope][name][key] += 1
                        gt[scope][name][key] += 1
                    for ref in ['production', 'pr285']:
                        pair = pairs[scope][ref]
                        if predicted['selective'] and not predicted[ref]:
                            pair['genuine_gained' if truth else 'false_awards_added'] += 1
                        if predicted[ref] and not predicted['selective']:
                            pair['genuine_lost' if truth else 'false_awards_removed'] += 1
            games[gid] = {scope: metrics(table) for scope, table in gt.items()}
        if state and state.get('complete') and batch_done == len(inp['games']):
            assert batch_searches == state['searches']
    complete = seen == expected and all(x['state'] and x['state'].get('complete') for x in states) and not failures
    if complete:
        for key in ['games', 'all_moves', 'own_moves', 'primary_moves', 'excluded_moves']:
            assert checked[key] == expected_totals[key]
        assert tables['primary']['selective']['TP'] + tables['primary']['selective']['FN'] == expected_totals['primary_positives']
    paired = {}
    for scope, refs in pairs.items():
        paired[scope] = {}
        for ref, c in refs.items():
            values = {k: c[k] for k in ['genuine_gained', 'genuine_lost', 'false_awards_added', 'false_awards_removed']}
            values.update(net_TP=c['genuine_gained']-c['genuine_lost'], net_FP=c['false_awards_added']-c['false_awards_removed'])
            paired[scope][ref] = values
    report = dict(complete=complete, at=datetime.now(timezone.utc).isoformat(), games_done=len(seen), games_expected=200,
        missing_games=sorted(expected-seen), expected_totals=dict(expected_totals), checked_totals=dict(checked),
        counts={scope: metrics(table) for scope, table in tables.items()}, paired_changes=paired,
        per_account={'Witty_Alien': {scope: metrics(table) for scope, table in tables.items()}},
        workers=states, worker_failures=failures, candidate_model_sha256=MODEL, candidate_cutoff=.83,
        source_hashes={f: sha(ROOT/f) for f in ['BUILD-PINS.json', 'SOURCE-PINS.json', 'CANDIDATE-PIN.json', 'EXCLUSIONS.json', 'summarize.py']},
        notes=['Frozen fresh-account test; no tuning or automatic winner selection.',
               'Primary counts exclude canonical before-position overlap; unmasked and excluded counts are separate.',
               'Only Witty_Alien own moves scored. Gallery absence is the authorized negative convention within gallery-represented games.',
               'FPR is FP/(FP+TN); this is not an estimate for all Chess.com games.'])
    write(ROOT/'PROGRESS-SUMMARY.json', report)
    if complete:
        write(ROOT/'GAME-COUNTS.json', games)
        with (ROOT/'all-own-move-outcomes.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['game_id', 'ply', 'san', 'uci', 'truth', 'primary'] + NAMES)
            writer.writeheader()
            writer.writerows(rows)
        write(ROOT/'RESULTS.json', report)
    print(json.dumps(dict(complete=complete, games_done=len(seen), counts=report['counts'], failures=failures), indent=2))


if __name__ == '__main__':
    main()
