// Bounded source preparation only. Run "select" after full metadata capture, then "input" after verified export.
import {readFileSync,writeFileSync,existsSync}from'node:fs';
import {createHash}from'node:crypto';
import {parsePgn,startingPosition}from'chessops/pgn';
import {makeFen}from'chessops/fen';
import {parseSan,makeSan}from'chessops/san';
import {standardUci,position}from'./native/ui/analyse/src/noSweatCore.ts';
const root=new URL('./',import.meta.url),mode=process.argv[2]??'input';
const sha=(b:any)=>createHash('sha256').update(b).digest('hex'),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),need=(v:any,m:string)=>{if(!v)throw Error(m)};
const read=(name:string)=>JSON.parse(readFileSync(new URL(name,root),'utf8')),write=(name:string,value:any)=>writeFileSync(new URL(name,root),JSON.stringify(value,null,2)+'\n');
const protocolBytes=readFileSync(new URL('PROTOCOL.json',root)),protocol=JSON.parse(protocolBytes.toString()),exclusionBytes=readFileSync(new URL('EXCLUSIONS.json',root)),exclusions=JSON.parse(exclusionBytes.toString());
const trainingIDs:string[]=exclusions.training_game_ids,trainingSet=new Set(trainingIDs),beforeKeys:string[]=exclusions.canonical_before_keys,beforeSet=new Set(beforeKeys);
need(protocol.account==='Witty_Alien'&&protocol.sample_games===200&&trainingSet.size===3475&&beforeSet.size===6189,'Frozen protocol/exclusion counts changed');
const seed='mute-fresh-witty-2026-11-06:';
const fullPath='Witty_Alien/gallery-all.json',selectionPath='SELECTION.json';
function checkFullGallery(full:any){
 need(full.account.toLowerCase()==='witty_alien'&&full.all_types_displayed_count===4411&&full.entries.length===4411,'Full 4411-entry metadata capture is incomplete');
 const keys=new Set<string>();
 for(const r of full.entries){
  need(typeof r.game_id==='string'&&/^\d+$/.test(r.game_id)&&Number.isInteger(r.ply)&&r.ply>0&&r.account.toLowerCase()==='witty_alien','Invalid gallery card identity');
  const item=r.game_item?.match(/^([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})-(\d+)$/i);need(item&&Number(item[2])===r.ply,'Invalid gallery UUID/ply');
  const link=new URL(r.source_link);need(link.hostname==='www.chess.com'&&link.pathname===`/analysis/game/${r.game_type}/${r.game_id}`&&link.searchParams.get('move')===String(r.ply-1),'Invalid gallery link');
  const key=r.game_id+':'+r.ply;need(!keys.has(key),'Duplicate full-gallery move');keys.add(key);need(Array.isArray(r.categories)&&new Set(r.categories).size===r.categories.length,'Invalid category membership');
 }
 const counts:any={};for(const r of full.entries)for(const c of r.categories)if(c!=='Brilliant Moves')counts[c]=(counts[c]??0)+1;
 need(Number(full.category_counts['Brilliant Moves'].displayed_count)===4411,'Wrong full-gallery source count');
 for(const[c,v]of Object.entries(full.category_counts)as any)if(c!=='Brilliant Moves')need((counts[c]??0)===Number(v.displayed_count),'Full category count mismatch: '+c);
 return full;
}

if(mode==='select'){
 const fullBytes=readFileSync(new URL(fullPath,root)),full=checkFullGallery(JSON.parse(fullBytes.toString()));
 need(typeof protocol.capture_start_utc==='string','Protocol lacks frozen capture_start_utc');const upper=Date.parse(protocol.capture_start_utc),lower=upper-365*86400000;need(Number.isFinite(upper),'Invalid capture bound');
 const byGame=new Map<string,any[]>();for(const r of full.entries){const rs=byGame.get(r.game_id)??[];rs.push(r);byGame.set(r.game_id,rs)}
 const archivesBytes=readFileSync(new URL('ARCHIVES.json',root)),archives=JSON.parse(archivesBytes.toString()),bank=new Map<string,any>();
 need(archives.length===13,'Incomplete monthly PGN bank');
 for(const source of archives){const path=new URL('../../'+source.path,root),bytes=readFileSync(path);need(bytes.length===source.bytes&&sha(bytes)===source.sha256,'Archive receipt mismatch: '+source.path);
  for(const block of bytes.toString().split(/(?=^\[Event )/m)){
   const link=block.match(/^\[Link "https:\/\/www\.chess\.com\/game\/(live|daily)\/(\d+)"\]/m);if(!link||!byGame.has(link[2]))continue;
   const date=block.match(/^\[UTCDate "(\d{4}\.\d{2}\.\d{2})"\]/m)?.[1],time=block.match(/^\[UTCTime "(\d{2}:\d{2}:\d{2})"\]/m)?.[1];need(date&&time,'Missing exact PGN UTC date/time: '+link[2]);
   const iso=date!.replaceAll('.','-')+'T'+time+'Z',instant=Date.parse(iso);need(Number.isFinite(instant)&&new Date(instant).toISOString().slice(0,19)+'Z'===iso,'Invalid PGN UTC timestamp');
   need(byGame.get(link[2])!.every(r=>r.game_type===link[1]),'Gallery/PGN namespace mismatch');
   const existing=bank.get(link[2]);if(existing){need(existing.utc_started_at===iso,'Conflicting PGN start time');existing.raw_pgn_files.push(source.path)}else bank.set(link[2],{game_id:link[2],game_type:link[1],utc_started_at:iso,instant,raw_pgn_files:[source.path]});
  }
 }
 const missing=[...byGame.keys()].filter(id=>!bank.has(id));if(missing.length){write('MISSING-GALLERY-PGNS.json',{game_ids:missing});throw Error('Missing official PGNs for '+missing.length+' full-gallery games; no replacements selected')}
 const all=[...bank.values()].map(g=>({...g,gallery_labels:byGame.get(g.game_id)!.length,ranking_sha256:sha(seed+g.game_id),exclusion_reasons:[...(trainingSet.has(g.game_id)?['previously_observed_game_id']:[]),...(g.instant<=lower?['not_strictly_after_365_day_lower_bound']:[]),...(g.instant>upper?['after_frozen_capture_start']:[])]}));
 const eligible=all.filter(g=>!g.exclusion_reasons.length).sort((a,b)=>a.ranking_sha256.localeCompare(b.ranking_sha256)||a.game_id.localeCompare(b.game_id));
 const selected=eligible.slice(0,Math.min(200,eligible.length)),ids=selected.map(g=>g.game_id),idSet=new Set(ids);need(ids.length>0,'No eligible novel games');
 const receipt={scope:'Fixed-hash sample chosen from complete 4411-card metadata before selected-board validation or any model outcomes',account:'Witty_Alien',ranking_seed:seed,capture_start_utc:protocol.capture_start_utc,strict_lower_exclusive_utc:new Date(lower).toISOString(),upper_inclusive_utc:new Date(upper).toISOString(),full_gallery_path:fullPath,full_gallery_sha256:sha(fullBytes),full_gallery_labels:4411,full_gallery_games:byGame.size,protocol_sha256:sha(protocolBytes),exclusions_sha256:sha(exclusionBytes),archives_sha256:sha(archivesBytes),eligible_novel_games:eligible.length,requested_games:200,selected_games:ids.length,selected_game_ids:ids,selected_gallery_labels:full.entries.filter((r:any)=>idSet.has(r.game_id)).length,selected,all_gallery_game_eligibility:all};
 if(existsSync(new URL(selectionPath,root)))need(same(read(selectionPath),receipt),'Existing fixed selection differs; stop without replacing games');else write(selectionPath,receipt);
 const categoryCounts:any={};for(const[c,v]of Object.entries(full.category_counts)as any)categoryCounts[c]={...v,source_displayed_count:Number(v.displayed_count),displayed_count:0,count_scope:'selected_game_ids'};
 const entries=full.entries.filter((r:any)=>idSet.has(r.game_id));for(const c of Object.keys(categoryCounts))categoryCounts[c].displayed_count=c==='Brilliant Moves'?entries.length:entries.filter((r:any)=>r.categories.includes(c)).length;
 const selectedGallery={...full,all_types_displayed_count:entries.length,category_counts:categoryCounts,entries,selection_provenance:{scope:'fixed_hash_game_subset',selected_game_ids:ids,selected_games:ids.length,selected_entries:entries.length,source_full_gallery_path:fullPath,source_full_gallery_sha256:sha(fullBytes),source_full_gallery_displayed_count:4411,selection_receipt_path:selectionPath,selection_receipt_sha256:sha(readFileSync(new URL(selectionPath,root))),boards_require_selected_reverification:true}};
 write('SELECTED-GALLERY.json',selectedGallery);console.log(JSON.stringify({selected_games:ids.length,selected_labels:entries.length,eligible_novel_games:eligible.length,boards_not_yet_declared_complete:true}));
}else if(mode==='input'){
 const selectionBytes=readFileSync(new URL(selectionPath,root)),selection=JSON.parse(selectionBytes.toString());need(selection.protocol_sha256===sha(protocolBytes)&&selection.exclusions_sha256===sha(exclusionBytes),'Frozen selection inputs changed');
 const pgnBytes=readFileSync(new URL('witty-alien-last-12-months-chesscom-brilliants.pgn',root)),labelBytes=readFileSync(new URL('brilliant-moves.json',root)),labels=JSON.parse(labelBytes.toString()),ids=new Set<string>(selection.selected_game_ids),byGame=new Map<string,any[]>();
 for(const r of labels){need(ids.has(r.game_id),'Export contains unselected game');const rs=byGame.get(r.game_id)??[];rs.push(r);byGame.set(r.game_id,rs)}
 need(labels.length===selection.selected_gallery_labels,'Export dropped selected gallery labels');const canonical=(fen:string)=>makeFen(position(fen).toSetup()),games:any[]=[],seen=new Set<string>();
 for(const game of parsePgn(pgnBytes.toString())){
  const id=game.headers.get('Link')?.match(/\/(\d+)$/)?.[1];need(id&&ids.has(id)&&!seen.has(id)&&!trainingSet.has(id),'Unexpected/duplicate/non-novel exported game');seen.add(id!);
  const pos=startingPosition(game.headers).unwrap(),nodes:any[]=[{ply:0,fen:makeFen(pos.toSetup())}];
  for(const node of game.moves.mainline()){const move=parseSan(pos,node.san);need(move,'Illegal PGN move');const san=makeSan(pos,move!),uci=standardUci(pos,move!);pos.play(move!);nodes.push({ply:nodes.length,fen:makeFen(pos.toSetup()),uci,san})}
  const targets=byGame.get(id!)!;for(const r of targets)need(nodes[r.ply]?.uci===r.uci&&nodes[r.ply]?.san===r.san&&canonical(nodes[r.ply-1].fen)===canonical(r.fen_before)&&canonical(nodes[r.ply].fen)===canonical(r.fen_after),'Export target identity mismatch');
  const white=game.headers.get('White')!,black=game.headers.get('Black')!,positive=new Set(targets.map(t=>t.ply)),scored:number[]=[],unmasked:number[]=[],excluded:any[]=[];
  for(let ply=1;ply<nodes.length;ply++){const mover=position(nodes[ply-1].fen).turn==='white'?white:black;if(mover.toLowerCase()!=='witty_alien'){need(!positive.has(ply),'Gallery label belongs to opponent');continue}unmasked.push(ply);const key=nodes[ply-1].fen.trim().split(/\s+/).slice(0,4).join(' ');if(beforeSet.has(key))excluded.push({ply,position_key:key,gallery_positive:positive.has(ply),reason:'previous_development_before_position'});else scored.push(ply)}
  games.push({game_id:id,white,black,date:game.headers.get('Date'),nodes,targets,cohort:'fresh_witty',scored_accounts:['Witty_Alien'],scored_plies:scored,unmasked_scored_plies:unmasked,scoring_exclusions:excluded});
 }
 need(seen.size===ids.size&&games.length===selection.selected_games,'Selected game export incomplete');games.sort((a,b)=>a.game_id.localeCompare(b.game_id));
 const count=(gs:any[])=>{const out={games:gs.length,all_game_moves:0,gallery_brilliants:0,own_moves_unmasked:0,unmasked_gallery_negative_moves:0,excluded_own_moves:0,excluded_gallery_brilliants:0,primary_own_moves:0,primary_gallery_brilliants:0,primary_gallery_negative_moves:0};for(const g of gs){const positives=new Set(g.targets.map((r:any)=>r.ply));out.all_game_moves+=g.nodes.length-1;out.gallery_brilliants+=g.targets.length;out.own_moves_unmasked+=g.unmasked_scored_plies.length;out.unmasked_gallery_negative_moves+=g.unmasked_scored_plies.length-g.targets.length;out.excluded_own_moves+=g.scoring_exclusions.length;out.excluded_gallery_brilliants+=g.scoring_exclusions.filter((r:any)=>r.gallery_positive).length;out.primary_own_moves+=g.scored_plies.length;out.primary_gallery_brilliants+=g.scored_plies.filter((ply:number)=>positives.has(ply)).length;out.primary_gallery_negative_moves+=g.scored_plies.filter((ply:number)=>!positives.has(ply)).length}return out};
 const counts=count(games),common={assessment_only:true,account:'Witty_Alien',scope:'Frozen fixed-hash novel-game sample; clean classifier nodes; primary own-move masks omit prior before-position aliases; opponents unscored',training_game_ids:trainingIDs,canonical_before_keys:beforeKeys,protocol_sha256:sha(protocolBytes),exclusion_sha256:sha(exclusionBytes),selection_sha256:sha(selectionBytes),sources:{pgn_sha256:sha(pgnBytes),gallery_labels_sha256:sha(labelBytes),full_gallery_sha256:selection.full_gallery_sha256},all_external_counts:counts};
 writeFileSync(new URL('INPUT.json',root),JSON.stringify({...common,games})+'\n');const bins=Array.from({length:8},(_,batch)=>({batch,moves:0,games:[]as any[]}));for(const g of [...games].sort((a,b)=>b.nodes.length-a.nodes.length||a.game_id.localeCompare(b.game_id))){const bin=[...bins].sort((a,b)=>a.moves-b.moves||a.batch-b.batch)[0];bin.games.push(g);bin.moves+=g.nodes.length-1}
 const assignments=[];for(const bin of bins){bin.games.sort((a,b)=>a.game_id.localeCompare(b.game_id));const bytes=JSON.stringify({...common,batch:bin.batch,expected_counts:count(bin.games),games:bin.games})+'\n';writeFileSync(new URL(`INPUT-${bin.batch}.json`,root),bytes);assignments.push({batch:bin.batch,suggested_host:bin.batch<4?'Air':bin.batch<6?'Pro':'Mini',counts:count(bin.games),input_sha256:sha(bytes),game_ids:bin.games.map(g=>g.game_id)})}
 write('INPUT-ASSIGNMENTS.json',{counts,assignments});console.log(JSON.stringify({counts,training_game_exclusions:trainingSet.size,before_position_exclusions:beforeSet.size,initial_position_count:counts.all_game_moves+games.length}));
}else throw Error('Use select or input; no engines or model evaluation are supported');
