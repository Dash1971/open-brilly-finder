"""Bounded Witty_Alien external-test gallery export; copies observed labels without analysis.

Run only after Witty_Alien COMPLETE receipt exists. run([...], publish=False)
performs the same source and board checks for completed subsets without exporting.
"""
import collections
import csv
import hashlib
import io
import json
import re
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, '<temporary-dependencies>/brilly-research-deps')
import chess
import chess.pgn

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[2]
STUDY = WORKSPACE / 'research/brilliant-fresh-witty-2026-11-06'
NELSI = WORKSPACE / 'research/nelsi-gallery-pgn-2026-11-06'
ACCOUNTS = ('Witty_Alien',)
PGN_NAME = 'witty-alien-last-12-months-chesscom-brilliants.pgn'


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def receipt(path):
    data = path.read_bytes()
    return {'file': str(path.relative_to(WORKSPACE)),
            'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def displayed_count(value):
    # The pilot saved the site's explicit empty-gallery message verbatim.
    if value == 'Their brilliant moves will appear here':
        return 0
    return int(value)


def selected_subset_sources(gallery):
    """Keep the complete source evidence separate from the fixed game sample."""
    full_path = ROOT / 'Witty_Alien/gallery-all.json'
    selection_path = ROOT / 'SELECTION.json'
    full = json.loads(full_path.read_text())
    selection = json.loads(selection_path.read_text())
    require(full['account'].lower() == 'witty_alien' and
            len(full['entries']) == full['all_types_displayed_count'] == 4411,
            'Incomplete full-gallery metadata source')
    require(receipt(full_path)['sha256'] == selection['full_gallery_sha256'],
            'Full gallery changed after fixed selection')
    require(receipt(ROOT / 'PROTOCOL.json')['sha256'] == selection['protocol_sha256'] and
            receipt(ROOT / 'EXCLUSIONS.json')['sha256'] == selection['exclusions_sha256'] and
            receipt(ROOT / 'ARCHIVES.json')['sha256'] == selection['archives_sha256'],
            'Frozen selection source changed')
    ids = set(selection['selected_game_ids'])
    require(len(ids) == selection['selected_games'] <= 200,
            'Invalid selected game count')
    expected = {(r['game_id'], r['ply']): r for r in full['entries'] if r['game_id'] in ids}
    actual = {(r['game_id'], r['ply']): r for r in gallery['entries']}
    require(len(expected) == selection['selected_gallery_labels'] and set(expected) == set(actual),
            'Filtered gallery must retain every full-gallery label in every selected game')
    require({r['game_id'] for r in gallery['entries']} == ids,
            'Filtered gallery differs from fixed game selection')
    for key, row in actual.items():
        original = expected[key]
        require(row['game_item'] == original['game_item'] and
                row['game_type'] == original['game_type'] and
                set(row['categories']) == set(original['categories']),
                f'Selected gallery source identity/category mismatch: {key}')
    return [receipt(path) for path in
            (full_path, selection_path, ROOT / 'PROTOCOL.json', ROOT / 'EXCLUSIONS.json')]


def load_gallery(account):
    full_path = STUDY / 'Witty_Alien/gallery-all.json'
    board_path = STUDY / 'Witty_Alien/gallery.json'
    selection_path = STUDY / 'SELECTION.json'
    full = json.loads(full_path.read_text())
    selected_boards = json.loads(board_path.read_text())
    original_selection = json.loads(selection_path.read_text())
    require(receipt(full_path)['sha256'] == original_selection['full_gallery_sha256'], 'Frozen full metadata changed')
    require(len(full['entries']) == full['all_types_displayed_count'] == 4411, 'Full metadata count mismatch')
    require(receipt(STUDY / 'PROTOCOL.json')['sha256'] == original_selection['protocol_sha256'] and receipt(STUDY / 'EXCLUSIONS.json')['sha256'] == original_selection['exclusions_sha256'], 'Frozen bounds/exclusions changed')
    ranked = sorted((g for g in original_selection['all_gallery_game_eligibility'] if not g['exclusion_reasons']), key=lambda g: (g['ranking_sha256'], g['game_id']))
    require(len(ranked) == 3546, 'Eligible source game count changed')
    require(all(hashlib.sha256(('mute-fresh-witty-2026-11-06:' + g['game_id']).encode()).hexdigest() == g['ranking_sha256'] for g in ranked), 'Ranking identity mismatch')
    require([g['game_id'] for g in ranked[:200]] == original_selection['selected_game_ids'], 'Original 200 not nested in fixed order')
    ids = {g['game_id'] for g in ranked[:3546]}
    board_map = {(r['game_id'], r['ply']): r for r in selected_boards['entries']}
    entries, seen = [], set()
    for row in full['entries']:
        gid, ply = row['game_id'], row['ply']
        require(isinstance(gid, str) and gid.isdigit() and isinstance(ply, int) and ply > 0 and row['account'].lower() == account.lower(), 'Invalid gallery card')
        item_uuid, suffix = row['game_item'].rsplit('-', 1)
        require(str(uuid.UUID(item_uuid)) == item_uuid.lower() and int(suffix) == ply, 'UUID/ply mismatch')
        u = urlparse(row['source_link'])
        require(u.netloc == 'www.chess.com' and u.path == f'/analysis/game/{row["game_type"]}/{gid}' and parse_qs(u.query).get('move') == [str(ply - 1)], 'Invalid gallery source URL')
        require((gid, ply) not in seen, 'Duplicate gallery key'); seen.add((gid, ply))
        if gid not in ids:
            continue
        merged = dict(row)
        captures = []
        for source_file, evidence in [(full_path, row), (board_path, board_map.get((gid, ply)))]:
            if evidence is None:
                continue
            require(evidence['game_item'] == row['game_item'] and evidence['source_link'] == row['source_link'], 'Merged source identity mismatch')
            if evidence.get('pieces') or evidence.get('arrows'):
                captures.append({'source_file': str(source_file.relative_to(WORKSPACE)), 'captured_at': evidence['captured_at'], 'pieces': evidence.get('pieces', []), 'arrows': evidence.get('arrows', []), 'brilliant_icon': evidence.get('brilliant_icon', False)})
        merged['_evidence_captures'] = captures
        entries.append(merged)
    require({r['game_id'] for r in entries} == ids, 'Lost selected game labels')
    categories = {c: dict(v, source_displayed_count=v['displayed_count'], displayed_count=len(entries) if c == 'Brilliant Moves' else sum(c in r['categories'] for r in entries), count_scope='complete_captured_gallery') for c, v in full['category_counts'].items()}
    gallery = dict(full, entries=entries, all_types_displayed_count=len(entries), category_counts=categories)
    write_json('GALLERY-SOURCE-SUBSET.json', gallery)
    selection = dict(original_selection, requested_games=3546, selected_games=3546, selected_game_ids=[g['game_id'] for g in ranked[:3546]], selected=ranked[:3546], selected_gallery_labels=len(entries), original_200_preserved=True, scope='Complete captured Witty gallery; no sampling or model awards')
    write_json('SELECTION.json', selection)
    return gallery, [receipt(path) for path in (full_path, board_path, selection_path, STUDY / 'PROTOCOL.json', STUDY / 'EXCLUSIONS.json')]


def placement(classes):
    squares = {}
    for cls in classes:
        pieces = re.findall(r'\b([wb][pnbrqk])\b', cls)
        positions = re.findall(r'\bsquare-([1-8])([1-8])\b', cls)
        require(len(pieces) == len(positions) == 1 and 'piece' in cls.split(),
                f'Unrecognized piece DOM class: {cls}')
        piece, (file, rank) = pieces[0], positions[0]
        sq = chess.square(int(file) - 1, int(rank) - 1)
        require(sq not in squares, 'Overlapping rendered pieces')
        squares[sq] = chess.Piece.from_symbol(piece[1].upper() if piece[0] == 'w' else piece[1])
    board = chess.Board.empty()
    board.set_piece_map(squares)
    return board.board_fen()


def parse_game(raw):
    stream = io.StringIO(raw)
    game = chess.pgn.read_game(stream)
    require(game is not None and not game.errors, 'Invalid source PGN')
    require(chess.pgn.read_game(stream) is None, 'Multiple games in source block')
    require(all(len(node.variations) <= 1 for node in [game, *game.mainline()]),
            'Unexpected source PGN variations')
    return game


def serialized(game):
    return game.accept(chess.pgn.StringExporter(headers=True, variations=False, comments=True))


def load_bank(accounts, needed):
    records = [r for r in json.loads((ROOT / 'ARCHIVES.json').read_text())
               if r['account'].lower() in {a.lower() for a in accounts}]
    if 'nelsi' in accounts:
        records += [dict(r, path=r['file']) for r in
                    json.loads((NELSI / 'FINAL-REPORT.json').read_text())['source_files']]
    bank, receipts, duplicates = {}, [], 0
    for record in records:
        path = WORKSPACE / record['path']
        source = receipt(path)
        require(source['bytes'] == record['bytes'] and source['sha256'] == record['sha256'],
                f'Source hash/size changed: {path}')
        receipts.append(source)
        for block in re.split(r'(?=^\[Event )', path.read_text(), flags=re.M):
            match = re.search(r'^\[Link "https://www.chess.com/game/(?:live|daily)/(\d+)"\]', block, re.M)
            if not match or match[1] not in needed:
                continue
            gid = match[1]
            if gid in bank:
                require(serialized(parse_game(bank[gid][0])) == serialized(parse_game(block)),
                        f'Conflicting original PGNs for game {gid}')
                bank[gid][1].append(source['file'])
                duplicates += 1
            else:
                bank[gid] = [block, [source['file']]]
    missing = sorted(set(needed) - bank.keys())
    if missing:
        write_json('MISSING-GAMES.json', {'accounts': accounts, 'game_ids': missing})
        raise ValueError(f'Missing {len(missing)} original PGNs: {missing[:20]}')
    return bank, receipts, duplicates


def run(accounts=ACCOUNTS, publish=True):
    started = time.monotonic()
    if publish:
        require(tuple(accounts) == ACCOUNTS, 'Final export requires the frozen Witty_Alien account')
    galleries, input_receipts, by_game = {}, [receipt(ROOT / 'ARCHIVES.json')], collections.defaultdict(list)
    for account in accounts:
        gallery, sources = load_gallery(account)
        galleries[account] = gallery
        input_receipts.extend(sources)
        for row in gallery['entries']:
            by_game[row['game_id']].append(dict(row, account=account))
    bank, source_receipts, duplicates = load_bank(accounts, by_game)
    outputs, labels, baseline, mismatches = [], [], {}, []
    per_account = {a: {'gallery_displayed': len(galleries[a]['entries']), 'labels': 0,
                       'board_matches': 0, 'games': set(), 'source_categories': {
                           c: displayed_count(v['displayed_count'])
                           for c, v in galleries[a]['category_counts'].items()}}
                   for a in accounts}
    for gid, rows in by_game.items():
        raw, source_files = bank[gid]
        game = parse_game(raw)
        targets = collections.defaultdict(list)
        for row in rows:
            targets[row['ply']].append(row)
        nodes = list(game.mainline())
        require(max(targets) <= len(nodes), f'{gid}: target beyond game end')
        original_headers = dict(game.headers)
        original_nodes = [(n.move.uci(), n.comment, n.starting_comment, set(n.nags)) for n in nodes]
        raw_clocks = re.findall(r'\[%clk [^\]]+\]', raw)
        require(not any(n.nags for n in nodes), f'{gid}: unexpected original classifications')
        board, added_comments = game.board(), {}
        for ply, node in enumerate(nodes, 1):
            require(node.move in board.legal_moves, f'{gid}/{ply}: illegal move')
            before, san, uci = board.fen(), board.san(node.move), node.move.uci()
            mover = game.headers.get('White' if board.turn == chess.WHITE else 'Black', '')
            board.push(node.move)
            comments = []
            for row in targets.get(ply, []):
                account = row['account']
                captures = row['_evidence_captures']
                board_verified = any(c['pieces'] for c in captures)
                arrows_verified = any(c['arrows'] for c in captures)
                board_views = sum(bool(c['pieces']) for c in captures)
                arrow_views = sum(bool(c['arrows']) for c in captures)
                rendered = None
                capture_errors = []
                for capture in captures:
                    if capture['pieces']:
                        rendered = placement(capture['pieces'])
                        if rendered != board.board_fen() or capture['brilliant_icon'] is not True:
                            capture_errors.append('rendered_board_or_icon')
                    for arrow in capture['arrows']:
                        if not re.fullmatch(r'[a-h][1-8][a-h][1-8][qrbn]?', arrow) or arrow[:4] != uci[:4]:
                            capture_errors.append('move_arrow')
                if mover.lower() != account.lower() or capture_errors:
                    mismatches.append({'account': account, 'game_id': gid, 'ply': ply,
                                       'san': san, 'mover': mover, 'pgn_after': board.board_fen(),
                                       'gallery_after': rendered})
                    continue
                categories = sorted(c for c in row['categories'] if c != 'Brilliant Moves')
                category = '; '.join(categories) if categories else 'Uncategorized'
                comment = (f'Chess.com gallery: Brilliant (!!). Account: {account}. '
                           f'Category: {category}. Captured: {row["captured_at"]}. '
                           f'Source: {row["source_link"]}')
                comments.append(comment)
                labels.append({'account': account, 'game_id': gid, 'ply': ply, 'san': san,
                               'uci': uci, 'category': category, 'source_categories': categories,
                               'fen_before': before, 'fen_after': board.fen(),
                               'date': game.headers.get('Date'), 'game_item': row['game_item'],
                               'source_link': row['source_link'], 'gallery_url': row['gallery_url'],
                               'captured_at': row['captured_at'], 'board_verified': board_verified,
                               'arrows_verified': arrows_verified, 'validated_board_views': board_views, 'validated_arrow_views': arrow_views,
                               'evidence_grade': ('rendered_board_and_arrow_exact' if board_verified and arrows_verified else 'rendered_board_exact' if board_verified else 'gallery_link_uuid_ply_mover_legal_pgn_arrow_exact' if arrows_verified else 'gallery_link_uuid_ply_mover_legal_pgn'),
                               'evidence_captures': captures,
                               'raw_pgn_files': source_files})
                stats = per_account[account]
                stats['labels'] += 1
                stats['board_matches'] += int(board_verified)
                stats['games'].add(gid)
            if comments:
                added_comments[ply] = ' '.join(comments)
                node.comment = (node.comment + ' ' + added_comments[ply]).strip()
                node.nags.add(chess.pgn.NAG_BRILLIANT_MOVE)
        additions = {
            'Annotator': 'Chess.com Brilliant gallery; source labels copied, not recalculated',
            'BrilliantAccounts': '; '.join(sorted({r['account'] for r in rows})),
            'BrilliantCount': str(len(rows)), 'BrilliantCaptured': '2026-11-06'}
        additions['BrilliantSelection'] = 'Complete captured 4411-label Brilliant gallery; no model awards'
        require(not (set(additions) & set(original_headers)), f'{gid}: source header collision')
        game.headers.update(additions)
        baseline[gid] = {'headers': original_headers, 'nodes': original_nodes,
                         'root_comment': game.comment,
                         'clocks': raw_clocks, 'added_comments': added_comments,
                         'final_fen': board.fen(), 'initial_fen': game.board().fen()}
        outputs.append(game)
    if mismatches:
        write_json('BOARD-MISMATCHES.json', mismatches)
        raise ValueError(f'{len(mismatches)} mover/rendered-board mismatches')
    require(len(labels) == sum(len(g['entries']) for g in galleries.values()), 'Lost gallery labels')
    outputs.sort(key=lambda g: (g.headers.get('UTCDate', g.headers.get('Date', '')),
                               g.headers.get('UTCTime', ''), g.headers['Link']))
    exported = '\n\n'.join(serialized(g) for g in outputs) + '\n'
    # Exhaustively compare every game, every original move/comment/clock and label.
    expected = {(r['account'], r['game_id'], r['ply']): r for r in labels}
    labels_at = collections.defaultdict(list)
    for label in labels:
        labels_at[(label['game_id'], label['ply'])].append(label)
    seen, games_seen, clocks_checked, moves_checked = set(), set(), 0, 0
    stream = io.StringIO(exported)
    while (game := chess.pgn.read_game(stream)) is not None:
        require(not game.errors, 'Export parse error')
        gid = game.headers['Link'].rsplit('/', 1)[1]
        require(gid not in games_seen and gid in baseline, f'{gid}: duplicate/unexpected export game')
        games_seen.add(gid)
        original = baseline[gid]
        require(game.comment == original['root_comment'], f'{gid}: original root comment changed')
        require(all(game.headers[k] == v for k, v in original['headers'].items()),
                f'{gid}: original header altered')
        nodes = list(game.mainline())
        require(len(nodes) == len(original['nodes']), f'{gid}: move count changed')
        board = game.board()
        require(board.fen() == original['initial_fen'], f'{gid}: initial position changed')
        for ply, (node, old) in enumerate(zip(nodes, original['nodes']), 1):
            uci, comment, starting_comment, nags = old
            add = original['added_comments'].get(ply)
            require(node.move.uci() == uci and node.starting_comment == starting_comment,
                    f'{gid}/{ply}: original move/comment changed')
            require(node.comment == ((comment + ' ' + add).strip() if add else comment),
                    f'{gid}/{ply}: original comment changed')
            require(node.nags == (nags | {3} if add else nags), f'{gid}/{ply}: unexpected annotation')
            before, san = board.fen(), board.san(node.move)
            board.push(node.move)
            for label in labels_at.get((gid, ply), []):
                require((before, board.fen(), san, uci) ==
                        (label['fen_before'], label['fen_after'], label['san'], label['uci']),
                        f'{gid}/{ply}: annotation roundtrip changed')
                seen.add((label['account'], gid, ply))
            moves_checked += 1
        require(board.fen() == original['final_fen'], f'{gid}: final position changed')
        clocks = re.findall(r'\[%clk [^\]]+\]', serialized(game))
        require(clocks == original['clocks'], f'{gid}: raw original clock tokens changed')
        clocks_checked += len(clocks)
    require(seen == set(expected) and games_seen == set(by_game), 'Incomplete roundtrip')
    for account, stats in per_account.items():
        require(stats['gallery_displayed'] == stats['labels'],
                f'{account}: incomplete label validation')
        stats['games'] = len(stats['games'])
        stats['categories'] = dict(collections.Counter(r['category'] for r in labels if r['account'] == account))
    summary = {'accounts': per_account, 'labels': len(labels), 'games': len(outputs),
               'unique_annotated_plies': len(labels_at), 'board_matches': sum(r['board_verified'] for r in labels), 'unmatched': 0,
               'roundtrip_annotation_checks': len(seen), 'roundtrip_game_checks': len(games_seen),
               'roundtrip_original_move_checks': moves_checked, 'raw_clock_tokens_preserved': clocks_checked,
               'duplicate_source_games_verified': duplicates, 'source_files': source_receipts,
               'gallery_and_completion_files': input_receipts,
               'range': 'Chess.com 1 year / time=365, captured 2026-11-06',
               'date_min': min(r['date'] for r in labels), 'date_max': max(r['date'] for r in labels),
               'label_basis': 'Visible Chess.com Brilliant-gallery entries; copied without engine or model analysis',
               'unlabeled_moves': 'Unknown; only copied Brilliant labels receive $3 (!!)',
               'export_validation_seconds': round(time.monotonic() - started, 3), 'published': publish}
    selection = json.loads((ROOT / 'SELECTION.json').read_text())
    summary['selection'] = {key: selection[key] for key in
                            ('full_gallery_labels', 'full_gallery_games', 'selected_games',
                             'selected_gallery_labels', 'ranking_seed', 'capture_start_utc',
                             'strict_lower_exclusive_utc', 'upper_inclusive_utc')}
    summary['evidence_grades'] = dict(collections.Counter(r['evidence_grade'] for r in labels))
    summary['validated_board_views'] = sum(r['validated_board_views'] for r in labels)
    summary['validated_arrow_views'] = sum(r['validated_arrow_views'] for r in labels)
    summary['metadata_only_labels'] = sum(not r['board_verified'] for r in labels)
    if publish:
        (ROOT / PGN_NAME).write_text(exported)
        labels.sort(key=lambda r: (r['date'], r['game_id'], r['ply'], r['account']))
        write_json('brilliant-moves.json', labels)
        with (ROOT / 'brilliant-moves.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(labels[0]))
            writer.writeheader()
            writer.writerows({k: json.dumps(v) if isinstance(v, list) else v for k, v in r.items()}
                            for r in labels)
        summary['outputs'] = [receipt(ROOT / name) for name in
                              (PGN_NAME, 'brilliant-moves.json', 'brilliant-moves.csv')]
        summary['export_script'] = receipt(Path(__file__).resolve())
        write_json('EXPORT-SUMMARY.json', summary)
    return summary


if __name__ == '__main__':
    try:
        summary = run()
    except Exception as exc:
        write_json('EXPORT-ERROR.json', {'error': str(exc), 'type': type(exc).__name__})
        raise
    print(json.dumps({k: v for k, v in summary.items()
                      if k not in ('source_files', 'gallery_and_completion_files')}, indent=2))
