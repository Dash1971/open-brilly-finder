// Capped source-only expansion: first 1000 of frozen order, original 200 objects copied unchanged.
import{readFileSync,writeFileSync}from'node:fs';
import{createHash}from'node:crypto';
import{parsePgn,startingPosition}from'chessops/pgn';
import{makeFen}from'chessops/fen';
import{parseSan,makeSan}from'chessops/san';
import{standardUci,position}from'../native/ui/analyse/src/noSweatCore.ts';
const root=new URL('./',import.meta.url),study=new URL('../',root),sha=(b:any)=>createHash('sha256').update(b).digest('hex'),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),need=(v:any,m:string)=>{if(!v)throw Error(m)};
const read=(name:string,base=root)=>JSON.parse(readFileSync(new URL(name,base),'utf8'));
const originalBytes=readFileSync(new URL('INPUT.json',study)),original=JSON.parse(originalBytes.toString()),oldByID=new Map<string,any>(original.games.map((g:any)=>[g.game_id,g]));need(oldByID.size===200,'Original sample changed');
const exclusionBytes=readFileSync(new URL('EXCLUSIONS.json',study)),exclusions=JSON.parse(exclusionBytes.toString()),training=new Set(exclusions.training_game_ids),beforeSet=new Set(exclusions.canonical_before_keys);
need(training.size===3475&&beforeSet.size===6189,'Frozen exclusions changed');
const selected=read('SELECTION.json'),ids=new Set(selected.selected_game_ids),labels=read('brilliant-moves.json'),byGame=new Map<string,any[]>();need(ids.size===1000&&labels.length===1235,'Capped source counts changed');
for(const row of labels){const rs=byGame.get(row.game_id)??[];rs.push(row);byGame.set(row.game_id,rs)}
const pgnBytes=readFileSync(new URL('witty-alien-1000-game-gallery-brilliants.pgn',root)),canonical=(fen:string)=>makeFen(position(fen).toSetup()),games:any[]=[],reused:any={},seen=new Set<string>();
for(const game of parsePgn(pgnBytes.toString())){
 const id=game.headers.get('Link')?.match(/\/(\d+)$/)?.[1];need(id&&ids.has(id)&&!seen.has(id)&&!training.has(id),'Unexpected, repeated or previously observed game');seen.add(id!);
 const pos=startingPosition(game.headers).unwrap(),nodes:any[]=[{ply:0,fen:makeFen(pos.toSetup())}];
 for(const node of game.moves.mainline()){const move=parseSan(pos,node.san);need(move,'Illegal source SAN');const uci=standardUci(pos,move!),san=makeSan(pos,move!);pos.play(move!);nodes.push({ply:nodes.length,fen:makeFen(pos.toSetup()),uci,san})}
 const targets=byGame.get(id!)!,white=game.headers.get('White')!,black=game.headers.get('Black')!;
 for(const r of targets)need(nodes[r.ply]?.san===r.san&&nodes[r.ply]?.uci===r.uci&&canonical(nodes[r.ply-1].fen)===canonical(r.fen_before)&&canonical(nodes[r.ply].fen)===canonical(r.fen_after),'Label/node identity mismatch');
 const positives=new Set(targets.map(r=>r.ply)),unmasked:number[]=[],scored:number[]=[],excluded:any[]=[];
 for(let ply=1;ply<nodes.length;ply++){const mover=position(nodes[ply-1].fen).turn==='white'?white:black;if(mover.toLowerCase()!=='witty_alien'){need(!positives.has(ply),'Opponent gallery label');continue}unmasked.push(ply);const pk=nodes[ply-1].fen.trim().split(/\s+/).slice(0,4).join(' ');if(beforeSet.has(pk))excluded.push({ply,position_key:pk,gallery_positive:positives.has(ply),reason:'previous_development_before_position'});else scored.push(ply)}
 const record={game_id:id,white,black,date:game.headers.get('Date'),nodes,targets,cohort:'fresh_witty',scored_accounts:['Witty_Alien'],scored_plies:scored,unmasked_scored_plies:unmasked,scoring_exclusions:excluded};
 const old=oldByID.get(id!);
 if(old){need(same(old.nodes,nodes)&&old.white===white&&old.black===black&&same(old.scored_plies,scored)&&same(old.unmasked_scored_plies,unmasked)&&same(old.scoring_exclusions,excluded),'Original sample game identity/masks changed');
  need(old.targets.length===targets.length&&old.targets.every((t:any)=>targets.some((r:any)=>r.ply===t.ply&&r.san===t.san&&r.uci===t.uci)),'Original sample labels changed');
  games.push(old);reused[id!]=sha(JSON.stringify(old));
 }else games.push(record);
}
need(games.length===1000&&Object.keys(reused).length===200&&games.filter(g=>!oldByID.has(g.game_id)).length===800,'Capped expansion game counts changed');
games.sort((a,b)=>a.game_id.localeCompare(b.game_id));
const counts={games:1000,all_game_moves:0,gallery_brilliants:0,own_moves_unmasked:0,unmasked_gallery_negative_moves:0,excluded_own_moves:0,excluded_gallery_brilliants:0,primary_own_moves:0,primary_gallery_brilliants:0,primary_gallery_negative_moves:0};
for(const g of games){const positives=new Set(g.targets.map((r:any)=>r.ply));counts.all_game_moves+=g.nodes.length-1;counts.gallery_brilliants+=g.targets.length;counts.own_moves_unmasked+=g.unmasked_scored_plies.length;counts.unmasked_gallery_negative_moves+=g.unmasked_scored_plies.length-g.targets.length;counts.excluded_own_moves+=g.scoring_exclusions.length;counts.excluded_gallery_brilliants+=g.scoring_exclusions.filter((r:any)=>r.gallery_positive).length;counts.primary_own_moves+=g.scored_plies.length;counts.primary_gallery_brilliants+=g.scored_plies.filter((p:number)=>positives.has(p)).length;counts.primary_gallery_negative_moves+=g.scored_plies.filter((p:number)=>!positives.has(p)).length}
const evidence=read('EXPORT-SUMMARY.json');need(counts.all_game_moves===62992&&counts.gallery_brilliants===1235,'Export/input move counts disagree');
const master={assessment_only:true,account:'Witty_Alien',scope:'Authorized 1000 total games, first1000 of same frozen SHA ranking; original200 nested and byte-identical at game-object level; only800 added. No model tuning or source collection.',exclusion_sha256:sha(exclusionBytes),protocol_sha256:sha(readFileSync(new URL('PROTOCOL.json',study))),selection_sha256:sha(readFileSync(new URL('SELECTION.json',root))),training_game_ids:exclusions.training_game_ids,canonical_before_keys:exclusions.canonical_before_keys,all_external_counts:counts,original_200_input_sha256:sha(originalBytes),original_200_game_hashes:reused,evidence_grade_counts:evidence.evidence_grades,sources:{pgn_sha256:sha(pgnBytes),labels_sha256:sha(readFileSync(new URL('brilliant-moves.json',root))),frozen_full_gallery_sha256:selected.full_gallery_sha256,original_selection_sha256:sha(readFileSync(new URL('SELECTION.json',study)))},games};
writeFileSync(new URL('MASTER.json',root),JSON.stringify(master)+'\n');
const check=read('MASTER.json');need(Object.entries(reused).every(([id,digest])=>sha(JSON.stringify(check.games.find((g:any)=>g.game_id===id)))===digest),'Original sample game-object JSON hash mismatch');
const report={complete:true,scope_games:1000,reused_original_sample_games:200,new_games:800,counts,evidence_grades:evidence.evidence_grades,validated_board_views:evidence.validated_board_views,validated_arrow_views:evidence.validated_arrow_views,original_200_input_sha256_before:sha(originalBytes),original_200_input_sha256_after:sha(readFileSync(new URL('INPUT.json',study))),original_200_game_hashes_all_exact:true,master_sha256:sha(readFileSync(new URL('MASTER.json',root))),no_engines_no_fit:true};
need(report.original_200_input_sha256_before===report.original_200_input_sha256_after,'Original INPUT file changed');writeFileSync(new URL('PREPARATION-SUMMARY.json',root),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
