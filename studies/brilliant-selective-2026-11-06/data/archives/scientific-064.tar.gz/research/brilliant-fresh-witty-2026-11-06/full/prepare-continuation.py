"""One fixed 800-game continuation preparation; no scheduling or engine launch."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math, os, shutil

FULL = Path(__file__).resolve().parent
ROOT = FULL.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
js_hash = lambda value: hashlib.sha256(json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
read = lambda p: json.loads(p.read_text())
write = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
rank = lambda gid: hashlib.sha256(('mute-fresh-witty-2026-11-06:' + gid).encode()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat()
MASTER_SHA = '29148ad23d8446a7e688e3cf20473bf83a14387700e612c8a009fbcc2ec6957c'
CAPS = [80, 80, 80, 80, 35, 35, 25, 25]
HOSTS = ['Air'] * 4 + ['Pro'] * 2 + ['Mini'] * 2

assert sha(FULL / 'MASTER.json') == MASTER_SHA, 'Full master changed'
master = read(FULL / 'MASTER.json')
games = master['games']
assert len(games) == len({g['game_id'] for g in games}) == 1000
selection = read(FULL / 'SELECTION.json')
eligible = [g['game_id'] for g in selection['all_gallery_game_eligibility'] if not g['exclusion_reasons']]
expected_ids = sorted(eligible, key=rank)[:1000]
assert selection['selected_game_ids'] == expected_ids
assert {g['game_id'] for g in games} == set(expected_ids)
by_id = {g['game_id']: g for g in games}
build = read(ROOT / 'BUILD-PINS.json')
assert sha(ROOT / 'SOURCE-PINS.json') == build['source_pins_sha256']
assert sha(ROOT / 'assessment-worker.mjs') == build['worker_bundle_sha256']
assert sha(ROOT / 'EXCLUSIONS.json') == build['exclusions_sha256']
assert master['assessment_only'] and master['account'] == 'Witty_Alien'
assert master['exclusion_sha256'] == build['exclusions_sha256']
exclusions = read(ROOT / 'EXCLUSIONS.json')
known_games = set(exclusions['training_game_ids'])
known_positions = set(exclusions['canonical_before_keys'])

# Preserve and verify every original input and completed result; do not read metrics for allocation.
original = {}; original_receipts = []; original_files = {}
for batch in range(8):
    path = ROOT / f'INPUT-{batch}.json'
    assert sha(path) == build['input_sha256_by_batch'][str(batch)]
    original_files[str(path.relative_to(ROOT))] = sha(path)
    freeze_path = ROOT / f'assessment-{batch}' / 'FREEZE.json'
    freeze = read(freeze_path)
    original_files[str(freeze_path.relative_to(ROOT))] = sha(freeze_path)
    for game in read(path)['games']:
        gid = game['game_id']; assert gid not in original
        original[gid] = game
        assert js_hash(game) == js_hash(by_id[gid]), 'Original 200 object changed: ' + gid
        result_path = ROOT / f'assessment-{batch}' / f'{gid}.json'
        result = read(result_path)
        assert result['complete'] and result['input_game_sha256'] == js_hash(game)
        assert result['freeze_sha256'] == js_hash(freeze['configuration'])
        original_receipts.append(dict(game_id=gid, input_game_sha256=js_hash(game),
            result_file=str(result_path.relative_to(ROOT)), result_sha256=sha(result_path),
            freeze_file=str(freeze_path.relative_to(ROOT)), freeze_sha256=sha(freeze_path)))
assert len(original) == 200 and set(original) == set(expected_ids[:200])
remaining = [by_id[gid] for gid in expected_ids if gid not in original]
assert len(remaining) == 800 and not {g['game_id'] for g in remaining} & set(original)
for game in remaining:
    assert game['game_id'] not in known_games
    own = []
    for ply in range(1, len(game['nodes'])):
        fen = game['nodes'][ply - 1]['fen']
        mover = game['white'] if fen.split()[1] == 'w' else game['black']
        if mover.lower() == 'witty_alien' and ' '.join(fen.split()[:4]) not in known_positions:
            own.append(ply)
    assert game['scored_plies'] == own, 'Own-move/overlap mask mismatch'

segments = [FULL / 'segment-00', FULL / 'segment-01']
assert all(not p.exists() for p in segments), 'Continuation segment already exists; never overwrite'
assert not (FULL / 'CONTINUATION-FREEZE.json').exists()
protocol = FULL / 'VALIDATION-PROTOCOL.json'
plan = dict(frozen_at_utc=now(), scope='Fixed continuation to 1,000 total games; retain original 200 and add exactly 800.',
    master_sha256=MASTER_SHA, full_protocol_sha256=sha(protocol), original_games=200, remaining_games=800,
    order='Original frozen SHA256 ranking; no result-dependent selection or replacement.',
    capacities=CAPS, host_by_batch=HOSTS, limits='Unchanged worker: 30 minutes/batch, 3 minutes/game, 768 MiB, critical-pressure stop.',
    admissions='Root controls launches; pause new admissions on warning pressure. No automatic launcher exists here.',
    original_files_sha256=original_files, original_result_receipts=original_receipts,
    source_pins_sha256=build['source_pins_sha256'], worker_bundle_sha256=build['worker_bundle_sha256'],
    worker_source_sha256=sha(ROOT / 'assessment-worker.mts'), exclusions_sha256=build['exclusions_sha256'])
write(FULL / 'CONTINUATION-PLAN.json', plan)
plan_sha = sha(FULL / 'CONTINUATION-PLAN.json')
receipts = []; all_assigned = []; cursor = 0
for segment_number, segment in enumerate(segments):
    total = min(sum(CAPS), len(remaining) - cursor)
    numerators = [total * cap for cap in CAPS]
    quotas = [n // sum(CAPS) for n in numerators]
    extras = total - sum(quotas)
    for i in sorted(range(8), key=lambda i: (-(numerators[i] % sum(CAPS)), i))[:extras]:
        quotas[i] += 1
    assert sum(quotas) == total and all(q <= cap for q, cap in zip(quotas, CAPS))
    segment.mkdir()
    for name in ['assessment-worker.mjs', 'assessment-worker.mts', 'SOURCE-PINS.json', 'CANDIDATE-PIN.json', 'PROTOCOL.json', 'EXCLUSIONS.json']:
        shutil.copyfile(ROOT / name, segment / name)
        assert sha(segment / name) == sha(ROOT / name)
    shutil.copyfile(protocol, segment / 'CONTINUATION-PROTOCOL.json')
    for name in ['native', 'selective-native', 'assets']:
        link = os.path.relpath(ROOT / name, segment)
        assert link == '../../' + name
        (segment / name).symlink_to(link, target_is_directory=True)
    inputs = {}; assignments = []
    for batch, quota in enumerate(quotas):
        chosen = remaining[cursor:cursor + quota]; cursor += quota
        ids = [g['game_id'] for g in chosen]; all_assigned.extend(ids)
        value = dict(assessment_only=True, account='Witty_Alien', exclusion_sha256=build['exclusions_sha256'],
            scope='Unchanged three-way continuation; all original games preserved outside these queues.',
            full_master_sha256=MASTER_SHA, continuation_plan_sha256=plan_sha,
            segment=segment_number, batch=batch, games=chosen,
            expected_counts=dict(games=len(chosen), full_moves=sum(len(g['nodes'])-1 for g in chosen),
                gallery_labels=sum(len(g['targets']) for g in chosen), primary_moves=sum(len(g['scored_plies']) for g in chosen)))
        write(segment / f'INPUT-{batch}.json', value)
        inputs[str(batch)] = sha(segment / f'INPUT-{batch}.json')
        assignments.append(dict(batch=batch, host=HOSTS[batch], games=len(chosen), maximum_games=CAPS[batch], game_ids=ids,
            command=f'node assessment-worker.mjs {batch} --root-go'))
    pins = dict(frozen_at=now(), source_pins_sha256=build['source_pins_sha256'], worker_bundle_sha256=build['worker_bundle_sha256'],
        exclusions_sha256=build['exclusions_sha256'], input_sha256_by_batch=inputs,
        continuation_plan_sha256=plan_sha, full_master_sha256=MASTER_SHA,
        continuation_protocol_sha256=sha(protocol), no_retune=True, no_pr_changes=True)
    write(segment / 'BUILD-PINS.json', pins)
    write(segment / 'ASSIGNMENTS.json', dict(segment=segment_number, quotas=quotas, assignments=assignments))
    receipts.append(dict(segment=segment.name, games=total, quotas=quotas,
        build_pins_sha256=sha(segment / 'BUILD-PINS.json'), assignments_sha256=sha(segment / 'ASSIGNMENTS.json'),
        input_sha256_by_batch=inputs, relative_links={name:os.readlink(segment/name) for name in ['native','selective-native','assets']}))
assert cursor == len(all_assigned) == len(set(all_assigned)) == 800
assert set(all_assigned) == {g['game_id'] for g in remaining}
assert not set(all_assigned) & set(original)
freeze = dict(frozen_at_utc=now(), master_sha256=MASTER_SHA, protocol_sha256=sha(protocol), plan_sha256=plan_sha,
    preparation_source_sha256=sha(Path(__file__)), original200_preserved=True, original_receipts=200,
    new_games=800, total_combined_games=1000, duplicate_or_original_assignments=0,
    all_game_objects_and_masks_unchanged=True, model_profile_source_unchanged=True,
    launch_status='Prepared only; root GO required. No engines launched by preparation.', segments=receipts)
write(FULL / 'CONTINUATION-FREEZE.json', freeze)
print(json.dumps(dict(freeze_sha256=sha(FULL/'CONTINUATION-FREEZE.json'), segments=receipts), indent=2))
